/*
  # Add customer_data column to leads table

  1. Changes
    - Add `customer_data` column to store customer information separately
    - This allows better querying and organization of customer vs lead data

  2. Notes
    - Column is nullable since not all leads will have customer data
    - Uses JSONB for efficient storage and querying
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'leads' AND column_name = 'customer_data'
  ) THEN
    ALTER TABLE leads ADD COLUMN customer_data JSONB;
  END IF;
END $$;