/*
  # Add phone number and store assignments to users table

  1. New Columns
    - `phone_number` (text, optional) - User's phone number for SMS notifications
    - `assigned_stores` (text array, optional) - List of stores this user is assigned to

  2. Purpose
    - Enable store-based SMS notifications
    - Allow users to be assigned to specific stores
    - Support phone number storage for SMS integration

  3. Changes
    - Add phone_number column to users table
    - Add assigned_stores column to users table
    - Both columns are optional and nullable
*/

-- Add phone number column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'phone_number'
  ) THEN
    ALTER TABLE users ADD COLUMN phone_number text;
  END IF;
END $$;

-- Add assigned stores column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'assigned_stores'
  ) THEN
    ALTER TABLE users ADD COLUMN assigned_stores text[];
  END IF;
END $$;