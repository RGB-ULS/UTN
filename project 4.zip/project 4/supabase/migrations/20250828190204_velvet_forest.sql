/*
  # Create users table for sales representatives

  1. New Tables
    - `users`
      - `id` (text, primary key)
      - `email` (text, unique, not null)
      - `name` (text, not null)
      - `active` (boolean, default true)
      - `created_at` (timestamp, default now())

  2. Security
    - Enable RLS on `users` table
    - Add policy for public read access (needed for form dropdowns)
    - Add policy for authenticated access for admin operations
*/

CREATE TABLE IF NOT EXISTS users (
  id text PRIMARY KEY,
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Allow public read access to active users (needed for form dropdowns)
CREATE POLICY "Allow public read access to active users"
  ON users
  FOR SELECT
  TO public
  USING (active = true);

-- Allow full access for admin operations (you can restrict this further if needed)
CREATE POLICY "Allow all operations for admin"
  ON users
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);