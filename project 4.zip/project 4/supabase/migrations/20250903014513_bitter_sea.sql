/*
  # Add needs_password column to users table

  1. Schema Changes
    - Add `needs_password` column to `users` table (boolean, default true)
    - Add `password` column to `users` table (text, nullable)

  2. Data Updates
    - Set existing users to need passwords by default
    - Users without passwords will be flagged as needing passwords

  3. Security
    - No RLS changes needed (existing policies remain)
*/

-- Add the needs_password column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'needs_password'
  ) THEN
    ALTER TABLE users ADD COLUMN needs_password boolean DEFAULT true;
  END IF;
END $$;

-- Add the password column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'password'
  ) THEN
    ALTER TABLE users ADD COLUMN password text;
  END IF;
END $$;

-- Update existing users to need passwords if they don't have one
UPDATE users 
SET needs_password = true 
WHERE password IS NULL OR password = '';

-- Update users who have passwords to not need them
UPDATE users 
SET needs_password = false 
WHERE password IS NOT NULL AND password != '';