import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface WebhookPayload {
  imageUrl?: string;
  image?: string;
  licensePlate?: string;
  license_plate?: string;
  store?: string;
  time?: string;
  leadType?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { 
        status: 405, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Parse the webhook payload
    const payload: WebhookPayload = await req.json()
    console.log('Received webhook payload:', payload)

    // Generate unique lead ID
    const leadId = `lead_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

    // Transform webhook data to lead format
    const leadData = {
      image: payload.imageUrl || payload.image || '',
      licensePlate: payload.licensePlate || payload.license_plate || '',
      store: payload.store || '',
      time: payload.time || new Date().toISOString(),
      leadType: 'Customer' // Default to Customer
    }

    // Store the lead in the database
    const { data, error } = await supabaseClient
      .from('leads')
      .insert({
        id: leadId,
        data: leadData,
        completed: false
      })
      .select()
      .single()

    if (error) {
      console.error('Database error:', error)
      return new Response(
        JSON.stringify({ 
          error: 'Failed to store lead', 
          details: error.message 
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    console.log('Lead stored successfully:', data)

    // Generate shareable link
    const shareableLink = `${req.headers.get('origin') || 'https://lead-management-form-ozjc.bolt.host'}/complete-lead/${leadId}`

    return new Response(
      JSON.stringify({
        success: true,
        leadId: leadId,
        shareableLink: shareableLink,
        message: 'Lead stored successfully'
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )

  } catch (error) {
    console.error('Webhook processing error:', error)
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        details: error.message 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})