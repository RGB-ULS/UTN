// Simple webhook handler for client-side processing
// This simulates a webhook endpoint for testing purposes

(function() {
  'use strict';

  // Function to handle webhook data
  function handleWebhookData(data) {
    try {
      console.log('Webhook received:', data);
      
      // Transform the webhook data to match our form structure
      const formData = {
        image: data.imageUrl || data.image || '',
        licensePlate: data.licensePlate || data.license_plate || '',
        store: data.store || '',
        time: data.time || new Date().toISOString(),
        leadType: '' // Always start blank so user can choose
      };

      // Store webhook data in sessionStorage for the form to pick up
      sessionStorage.setItem('webhookData', JSON.stringify(formData));
      
      // Log the webhook for monitoring
      const log = {
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        payload: data,
        status: 'success'
      };
      
      const existingLogs = JSON.parse(localStorage.getItem('webhookLogs') || '[]');
      const updatedLogs = [log, ...existingLogs].slice(0, 100);
      localStorage.setItem('webhookLogs', JSON.stringify(updatedLogs));
      
      return { success: true, message: 'Webhook processed successfully' };
    } catch (error) {
      console.error('Error processing webhook data:', error);
      
      // Log the error
      const errorLog = {
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        payload: data,
        status: 'error',
        error: error.message
      };
      
      const existingLogs = JSON.parse(localStorage.getItem('webhookLogs') || '[]');
      const updatedLogs = [errorLog, ...existingLogs].slice(0, 100);
      localStorage.setItem('webhookLogs', JSON.stringify(updatedLogs));
      
      return { success: false, error: 'Invalid webhook data' };
    }
  }

  // Expose webhook handler globally for testing
  window.handleWebhook = handleWebhookData;
  
  // If this script is loaded via fetch/ajax, handle the request
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { handleWebhookData };
  }
})();