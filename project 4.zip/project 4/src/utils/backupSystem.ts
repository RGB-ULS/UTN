// Backup and Recovery System for Leads
import { StoredLead } from '../types';
import { supabase } from '../lib/supabase';

const BACKUP_KEY = 'leadsBackup';
const AUTO_BACKUP_KEY = 'autoBackups';

export interface BackupData {
  id: string;
  timestamp: string;
  leads: StoredLead[];
  count: number;
  description: string;
}

// Create manual backup
export const createBackup = async (description: string = 'Manual backup'): Promise<string> => {
  try {
    // Get all leads from database
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false });

    let leads: StoredLead[] = [];
    
    if (data && !error) {
      leads = data.map(item => ({
        id: item.id,
        data: item.data,
        customerData: item.customer_data,
        createdAt: item.created_at,
        completed: item.completed,
        completedAt: item.completed_at
      }));
    } else {
      // Fallback to localStorage
      const stored = localStorage.getItem('storedLeads');
      leads = stored ? JSON.parse(stored) : [];
    }

    const backup: BackupData = {
      id: `backup_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      leads,
      count: leads.length,
      description
    };

    // Store backup in localStorage
    const existingBackups = getBackups();
    const updatedBackups = [backup, ...existingBackups].slice(0, 10); // Keep only last 10 backups
    localStorage.setItem(BACKUP_KEY, JSON.stringify(updatedBackups));

    console.log(`Backup created: ${backup.count} leads backed up`);
    return backup.id;
  } catch (error) {
    console.error('Error creating backup:', error);
    throw error;
  }
};

// Get all backups
export const getBackups = (): BackupData[] => {
  try {
    const stored = localStorage.getItem(BACKUP_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading backups:', error);
    return [];
  }
};

// Restore from backup
export const restoreFromBackup = async (backupId: string): Promise<boolean> => {
  try {
    const backups = getBackups();
    const backup = backups.find(b => b.id === backupId);
    
    if (!backup) {
      throw new Error('Backup not found');
    }

    console.log(`Restoring ${backup.count} leads from backup: ${backup.description}`);

    // Restore to database
    for (const lead of backup.leads) {
      try {
        const { error } = await supabase
          .from('leads')
          .upsert({
            id: lead.id,
            data: lead.data,
            customer_data: lead.customerData,
            created_at: lead.createdAt,
            completed: lead.completed,
            completed_at: lead.completedAt
          });

        if (error) {
          console.error(`Error restoring lead ${lead.id}:`, error);
        }
      } catch (error) {
        console.error(`Error restoring lead ${lead.id}:`, error);
      }
    }

    // Also restore to localStorage as backup
    localStorage.setItem('storedLeads', JSON.stringify(backup.leads));

    console.log(`Restore completed: ${backup.count} leads restored`);
    return true;
  } catch (error) {
    console.error('Error restoring backup:', error);
    return false;
  }
};

// Auto-backup system (runs periodically)
export const createAutoBackup = async (): Promise<void> => {
  try {
    const now = new Date();
    const description = `Auto backup - ${now.toLocaleString()}`;
    
    await createBackup(description);
    
    // Track auto-backup frequency
    const autoBackups = JSON.parse(localStorage.getItem(AUTO_BACKUP_KEY) || '[]');
    autoBackups.push(now.toISOString());
    
    // Keep only last 24 hours of auto-backup timestamps
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentBackups = autoBackups.filter((timestamp: string) => new Date(timestamp) > oneDayAgo);
    
    localStorage.setItem(AUTO_BACKUP_KEY, JSON.stringify(recentBackups));
  } catch (error) {
    console.error('Error creating auto backup:', error);
  }
};

// Check for successful submissions in localStorage (potential recovery source)
export const getSuccessfulSubmissions = (): any[] => {
  try {
    const stored = localStorage.getItem('successfulSubmissions');
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading successful submissions:', error);
    return [];
  }
};

// Check for failed submissions in localStorage (potential recovery source)
export const getFailedSubmissions = (): any[] => {
  try {
    const stored = localStorage.getItem('failedSubmissions');
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading failed submissions:', error);
    return [];
  }
};

// Export all data for manual recovery
export const exportAllData = (): string => {
  const data = {
    backups: getBackups(),
    successfulSubmissions: getSuccessfulSubmissions(),
    failedSubmissions: getFailedSubmissions(),
    webhookLogs: JSON.parse(localStorage.getItem('webhookLogs') || '[]'),
    exportedAt: new Date().toISOString()
  };
  
  return JSON.stringify(data, null, 2);
};

// Delete old backups
export const cleanupOldBackups = (): void => {
  try {
    const backups = getBackups();
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    
    const recentBackups = backups.filter(backup => new Date(backup.timestamp) > oneWeekAgo);
    
    localStorage.setItem(BACKUP_KEY, JSON.stringify(recentBackups));
    console.log(`Cleaned up old backups. Kept ${recentBackups.length} recent backups.`);
  } catch (error) {
    console.error('Error cleaning up backups:', error);
  }
};