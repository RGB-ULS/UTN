import { User } from '../types';
import { supabase } from '../lib/supabase';

const USERS_STORAGE_KEY = 'managedUsers';

// Generate unique user ID
export const generateUserId = (): string => {
  return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
};

// Get all users
export const getUsers = async (): Promise<User[]> => {
  try {
    console.log('Getting users from database...');
    
    // Try to get from Supabase database first
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && !error) {
      console.log('Retrieved users from database:', data);
      // Also sync to localStorage as backup
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(data));
      return data;
    }

    console.warn('Database query failed, falling back to localStorage:', error);
    
    // Fallback to localStorage
    const stored = localStorage.getItem(USERS_STORAGE_KEY);
    const users = stored ? JSON.parse(stored) : [];
    console.log('Retrieved users from localStorage:', users);
    return users;
  } catch (error) {
    console.error('Error loading users:', error);
    
    // Final fallback to localStorage
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (localError) {
      console.error('LocalStorage also failed:', localError);
      return [];
    }
  }
};

// Get active users only
export const getActiveUsers = async (): Promise<User[]> => {
  const allUsers = await getUsers();
  const activeUsers = allUsers.filter(user => user.active);
  console.log('Active users:', activeUsers);
  return activeUsers;
};

// Get users who need passwords
export const getUsersNeedingPasswords = async (): Promise<User[]> => {
  const allUsers = await getUsers();
  const usersNeedingPasswords = allUsers.filter(user => user.active && user.needs_password);
  console.log('Users needing passwords:', usersNeedingPasswords);
  return usersNeedingPasswords;
};

// Set password for multiple users (bulk operation)
export const setBulkPasswords = async (userIds: string[], password: string): Promise<{ success: string[]; errors: { userId: string; error: string }[] }> => {
  const results = {
    success: [] as string[],
    errors: [] as { userId: string; error: string }[]
  };

  for (const userId of userIds) {
    try {
      await setUserPassword(userId, password);
      results.success.push(userId);
    } catch (error) {
      results.errors.push({ userId, error: error.message });
    }
  }

  return results;
};

// Set user password
export const setUserPassword = async (userId: string, password: string): Promise<User> => {
  try {
    const updates = {
      password: password,
      needs_password: false
    };

    // Try to update in Supabase database first
    const { data, error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', userId)
      .select()
      .single();

    if (data && !error) {
      console.log('User password updated in database:', data);
      return data;
    }

    console.warn('Database update failed, using localStorage:', error);
    
    // Fallback to localStorage
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '[]');
    const userIndex = users.findIndex((user: User) => user.id === userId);
    
    if (userIndex === -1) {
      throw new Error('User not found');
    }

    const updatedUser = {
      ...users[userIndex],
      ...updates
    };

    users[userIndex] = updatedUser;
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    
    return updatedUser;
  } catch (error) {
    console.error('Error setting user password:', error);
    throw error;
  }
};

// Add new user
export const addUser = async (email: string, name: string, password?: string): Promise<User> => {
  try {
    const newUser: User = {
      id: generateUserId(),
      email: email.toLowerCase().trim(),
      name: name.trim(),
      active: true,
      created_at: new Date().toISOString(),
      password: password || '1234',
      needs_password: false,
      phone_number: '',
      assigned_stores: []
    };

    // Try to add to Supabase database first
    const { data, error } = await supabase
      .from('users')
      .insert(newUser)
      .select()
      .single();

    if (data && !error) {
      console.log('User added to database:', data);
      // Also add to localStorage as backup
      const users = await getUsers();
      return data;
    }

    console.warn('Database insert failed, using localStorage:', error);
    
    // Fallback to localStorage
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '[]');
    
    // Check if user already exists
    const existingUser = users.find((user: User) => user.email.toLowerCase() === email.toLowerCase());
    if (existingUser) {
      throw new Error('User with this email already exists');
    }

    const updatedUsers = [...users, newUser];
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updatedUsers));
    
    return newUser;
  } catch (error) {
    // Handle Supabase duplicate key error
    if (error.code === '23505' || error.message.includes('duplicate key value violates unique constraint')) {
      throw new Error('User with this email already exists');
    }
    // Handle other known duplicate errors
    if (error.message.includes('already exists')) {
      throw new Error('User with this email already exists');
    }
    throw error;
  }
};

// Update user
export const updateUser = async (userId: string, updates: Partial<Omit<User, 'id' | 'created_at'>>): Promise<User> => {
  try {
    // Try to update in Supabase database first
    const { data, error } = await supabase
      .from('users')
      .update({
        email: updates.email ? updates.email.toLowerCase().trim() : undefined,
        name: updates.name ? updates.name.trim() : undefined,
        active: updates.active,
        password: updates.password,
        needs_password: updates.needs_password,
        phone_number: updates.phone_number,
        assigned_stores: updates.assigned_stores
      })
      .eq('id', userId)
      .select()
      .single();

    if (data && !error) {
      console.log('User updated in database:', data);
      return data;
    }

    console.warn('Database update failed, using localStorage:', error);
    
    // Fallback to localStorage
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '[]');
    const userIndex = users.findIndex((user: User) => user.id === userId);
    
    if (userIndex === -1) {
      throw new Error('User not found');
    }

    // Check for email conflicts if email is being updated
    if (updates.email) {
      const emailConflict = users.find((user: User) => 
        user.id !== userId && 
        user.email.toLowerCase() === updates.email!.toLowerCase()
      );
      if (emailConflict) {
        throw new Error('Another user with this email already exists');
      }
    }

    const updatedUser = {
      ...users[userIndex],
      ...updates,
      email: updates.email ? updates.email.toLowerCase().trim() : users[userIndex].email,
      name: updates.name ? updates.name.trim() : users[userIndex].name
    };

    users[userIndex] = updatedUser;
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    
    return updatedUser;
  } catch (error) {
    // Handle Supabase duplicate key error
    if (error.code === '23505' || error.message.includes('duplicate key value violates unique constraint')) {
      throw new Error('Another user with this email already exists');
    }
    // Handle other known duplicate errors
    if (error.message.includes('already exists')) {
      throw new Error('Another user with this email already exists');
    }
    throw error;
  }
};

// Delete user
export const deleteUser = async (userId: string): Promise<void> => {
  try {
    // Try to delete from Supabase database first
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', userId);

    if (!error) {
      console.log('User deleted from database');
      return;
    }

    console.warn('Database delete failed, using localStorage:', error);
    
    // Fallback to localStorage
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '[]');
    const filteredUsers = users.filter((user: User) => user.id !== userId);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(filteredUsers));
  } catch (error) {
    console.error('Error deleting user:', error);
    throw error;
  }
};

// Import users from CSV data
export const importUsersFromCSV = async (csvData: string): Promise<{ success: number; errors: string[] }> => {
  const lines = csvData.trim().split('\n');
  const errors: string[] = [];
  let successCount = 0;

  // Skip header row if it exists
  const dataLines = lines[0].toLowerCase().includes('email') || lines[0].toLowerCase().includes('name') 
    ? lines.slice(1) 
    : lines;

  for (let index = 0; index < dataLines.length; index++) {
    const line = dataLines[index];
    const lineNumber = index + (lines.length - dataLines.length) + 1;
    
    try {
      const fields = line.split(',').map(field => field.trim().replace(/"/g, ''));
      const [email, name, phoneNumber, assignedStores] = fields;
      
      if (!email || !name) {
        errors.push(`Line ${lineNumber}: Missing email or name`);
        continue;
      }

      if (!isValidEmail(email)) {
        errors.push(`Line ${lineNumber}: Invalid email format - ${email}`);
        continue;
      }

      // Check if user already exists
      const existingUsers = await getUsers();
      const existingUser = existingUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (existingUser) {
        // Update existing user
        const updates: Partial<User> = {
          name: name.trim(),
          active: true // Reactivate if importing
        };
        
        if (phoneNumber) updates.phone_number = phoneNumber;
        if (assignedStores) {
          updates.assigned_stores = assignedStores.split(';').map(s => s.trim()).filter(Boolean);
        }
        
        await updateUser(existingUser.id, updates);
        console.log(`Updated existing user: ${email}`);
      } else {
        // Create new user
        const user = await addUser(email, name);
        
        // Update with additional fields if provided
        if (phoneNumber || assignedStores) {
          const updates: Partial<User> = {};
          if (phoneNumber) updates.phone_number = phoneNumber;
          if (assignedStores) {
            updates.assigned_stores = assignedStores.split(';').map(s => s.trim()).filter(Boolean);
          }
          await updateUser(user.id, updates);
        }
        console.log(`Created new user: ${email}`);
      }
      
      successCount++;
    } catch (error) {
      errors.push(`Line ${lineNumber}: ${error.message}`);
    }
  }

  return { success: successCount, errors };
};

// Authenticate sales rep
export const authenticateSalesRep = async (email: string, password?: string): Promise<{ success: boolean; user?: User; error?: string }> => {
  try {
    const users = await getUsers();
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.active);
    
    if (!user) {
      return { success: false, error: 'Email not found or user is inactive' };
    }

    // Check password if provided and user has a password set
    if (password && user.password) {
      if (user.password !== password) {
        return { success: false, error: 'Invalid password' };
      }
    } else if (password && !user.password) {
      return { success: false, error: 'No password set for this user' };
    }

    return { success: true, user };
  } catch (error) {
    return { success: false, error: 'Authentication failed' };
  }
};


// Validate email format
const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Clear all users
export const clearAllUsers = async (): Promise<void> => {
  try {
    // Try to clear from Supabase database first
    const { error } = await supabase
      .from('users')
      .delete()
      .neq('id', ''); // Delete all records

    if (!error) {
      console.log('All users cleared from database');
    } else {
      console.warn('Database clear failed:', error);
    }
  } catch (error) {
    console.error('Error clearing users from database:', error);
  }

  // Always clear localStorage as well
  localStorage.removeItem(USERS_STORAGE_KEY);
};

// Get users by store
export const getUsersByStore = async (store: string): Promise<User[]> => {
  const allUsers = await getActiveUsers();
  return allUsers.filter(user => 
    user.assigned_stores && 
    user.assigned_stores.includes(store) &&
    user.phone_number && 
    user.phone_number.trim() !== ''
  );
};

// Get all unique stores from users
export const getStoresFromUsers = async (): Promise<string[]> => {
  const allUsers = await getUsers();
  const stores = new Set<string>();
  
  allUsers.forEach(user => {
    if (user.assigned_stores) {
      user.assigned_stores.forEach(store => stores.add(store));
    }
  });
  
  return Array.from(stores).sort();
};

// Export users to CSV format
export const exportUsersToCSV = async (): Promise<string> => {
  const users = await getUsers();
  const csvHeader = 'Email,Name,Phone Number,Assigned Stores,Active,Created At\n';
  const csvRows = users.map(user => 
    `"${user.email}","${user.name}","${user.phone_number || ''}","${(user.assigned_stores || []).join('; ')}","${user.active}","${new Date(user.created_at).toLocaleString()}"`
  ).join('\n');
  
  return csvHeader + csvRows;
};