import { StoredLead, LeadData, WebhookLog } from '../types';
import { supabase } from '../lib/supabase';
import { createAutoBackup } from './backupSystem';

const LEADS_STORAGE_KEY = 'storedLeads';
const LOGS_STORAGE_KEY = 'webhookLogs';

// Lead Storage Functions
export const generateLeadId = (): string => {
  return 'lead_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
};

export const storeLead = async (leadData: LeadData): Promise<string> => {
  const leadId = generateLeadId();
  
  // Ensure leadType is set, default to 'Customer' if not provided
  const processedLeadData = {
    ...leadData,
    leadType: leadData.leadType || 'Customer'
  };
  
  try {
    // Store in Supabase database
    const { error } = await supabase
      .from('leads')
      .insert({
        id: leadId,
        data: processedLeadData,
        completed: false
      });

    if (error) {
      console.error('Error storing lead in database:', error);
      // Fallback to localStorage
      storeLeadLocally(leadId, processedLeadData);
    }
  } catch (error) {
    console.error('Error connecting to database:', error);
    // Fallback to localStorage
    storeLeadLocally(leadId, processedLeadData);
  }
  
  return leadId;
};

const storeLeadLocally = (leadId: string, leadData: LeadData): void => {
  const storedLead: StoredLead = {
    id: leadId,
    data: leadData,
    createdAt: new Date().toISOString(),
    completed: false
  };

  const existingLeads = getStoredLeads();
  const updatedLeads = [...existingLeads, storedLead];
  localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(updatedLeads));
};

export const getStoredLead = async (leadId: string): Promise<StoredLead | null> => {
  try {
    // First try to get from Supabase database
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .eq('id', leadId)
      .single();

    if (data && !error) {
      return {
        id: data.id,
        data: data.data,
        createdAt: data.created_at,
        completed: data.completed,
        completedAt: data.completed_at
      };
    }
  } catch (error) {
    console.error('Error fetching from database:', error);
  }

  // Fallback to localStorage
  const leads = getStoredLeads();
  return leads.find(lead => lead.id === leadId) || null;
};

export const getStoredLeads = (): StoredLead[] => {
  try {
    const stored = localStorage.getItem(LEADS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading stored leads:', error);
    return [];
  }
};

export const markLeadCompleted = async (leadId: string): Promise<void> => {
  try {
    // Try to update in Supabase database first
    const { error } = await supabase
      .from('leads')
      .update({ 
        completed: true, 
        completed_at: new Date().toISOString() 
      })
      .eq('id', leadId);

    if (!error) {
      console.log('Lead marked as completed in database:', leadId);
      return; // Successfully updated in database
    }
    
    console.warn('Database update failed, using localStorage fallback:', error);
  } catch (error) {
    console.error('Error updating database:', error);
  }

  // Fallback to localStorage
  const leads = getStoredLeads();
  const updatedLeads = leads.map(lead => 
    lead.id === leadId 
      ? { ...lead, completed: true, completedAt: new Date().toISOString() }
      : lead
  );
  localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(updatedLeads));
  console.log('Lead marked as completed in localStorage:', leadId);
};

export const generateShareableLink = (leadId: string): string => {
  const baseUrl = window.location.origin;
  return `${baseUrl}/complete-lead/${leadId}`;
};

// Function to store webhook data in database
export const storeWebhookLead = async (webhookData: any): Promise<string> => {
  const leadId = generateLeadId();
  
  const leadData: LeadData = {
    image: webhookData.imageUrl || webhookData.image || '',
    licensePlate: webhookData.licensePlate || webhookData.license_plate || '',
    store: webhookData.store || '',
    time: webhookData.time || new Date().toISOString(),
    leadType: 'Customer' // Default to Customer
  };

  try {
    const { error } = await supabase
      .from('leads')
      .insert({
        id: leadId,
        data: leadData,
        completed: false
      });

    if (error) {
      console.error('Error storing webhook lead:', error);
      // Store locally as fallback
      storeLeadLocally(leadId, leadData);
    }

    // Log the webhook
    logWebhook(webhookData, 'success');
    
    return leadId;
  } catch (error) {
    console.error('Error processing webhook:', error);
    logWebhook(webhookData, 'error', error.message);
    
    // Store locally as fallback
    storeLeadLocally(leadId, leadData);
    return leadId;
  }
};

// Webhook Log Functions
export const logWebhook = (payload: any, status: 'success' | 'error', error?: string): void => {
  const log: WebhookLog = {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    payload,
    status,
    error
  };

  const existingLogs = getWebhookLogs();
  const updatedLogs = [log, ...existingLogs].slice(0, 100); // Keep only last 100 logs
  
  localStorage.setItem(LOGS_STORAGE_KEY, JSON.stringify(updatedLogs));
};

export const getWebhookLogs = (): WebhookLog[] => {
  try {
    const stored = localStorage.getItem(LOGS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading webhook logs:', error);
    return [];
  }
};

export const clearWebhookLogs = (): void => {
  localStorage.removeItem(LOGS_STORAGE_KEY);
};

// Function to clear all leads from both database and localStorage
export const clearAllLeads = async (leadIds?: string[]): Promise<void> => {
  // Create backup before clearing
  try {
    const { createBackup } = await import('./backupSystem');
    const backupDescription = leadIds 
      ? `Pre-deletion backup (${leadIds.length} filtered leads) - ${new Date().toLocaleString()}`
      : `Pre-deletion backup (all leads) - ${new Date().toLocaleString()}`;
    await createBackup(backupDescription);
    console.log('Backup created before clearing leads');
  } catch (error) {
    console.error('Failed to create backup before clearing:', error);
  }

  try {
    if (leadIds && leadIds.length > 0) {
      // Delete only specific leads
      const { error } = await supabase
        .from('leads')
        .delete()
        .in('id', leadIds);
      
      if (error) {
        console.error('Error clearing filtered leads from database:', error);
      } else {
        console.log(`Successfully cleared ${leadIds.length} filtered leads from database`);
      }
      
      // Also clear from localStorage
      const allLeads = getStoredLeads();
      const remainingLeads = allLeads.filter(lead => !leadIds.includes(lead.id));
      localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(remainingLeads));
      console.log(`Cleared ${leadIds.length} filtered leads from localStorage`);
    } else {
      // Delete all records (original behavior)
      const { error } = await supabase
        .from('leads')
        .delete()
        .neq('id', ''); // Delete all records (neq with empty string matches all)

      if (error) {
        console.error('Error clearing all leads from database:', error);
      } else {
        console.log('Successfully cleared all leads from database');
      }
      
      // Always clear localStorage as well
      localStorage.removeItem(LEADS_STORAGE_KEY);
      console.log('Cleared all leads from localStorage');
    }
  } catch (error) {
    console.error('Error connecting to database:', error);
    
    // Fallback to localStorage only
    if (leadIds && leadIds.length > 0) {
      const allLeads = getStoredLeads();
      const remainingLeads = allLeads.filter(lead => !leadIds.includes(lead.id));
      localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(remainingLeads));
    } else {
      localStorage.removeItem(LEADS_STORAGE_KEY);
    }
  }
};

// Function to get all leads (for admin dashboard)
export const getAllLeads = async (): Promise<StoredLead[]> => {
  try {
    // Try to get from Supabase database first
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false });

    if (data && !error) {
      console.log('Retrieved leads from database:', data.length, 'leads');
      const mappedLeads = data.map(item => {
        // Validate each lead item
        if (!item || !item.id || !item.data || !item.created_at) {
          console.warn('Invalid lead item from database:', item);
          return null;
        }
        
        return {
        id: item.id,
        data: item.data,
        customerData: item.customer_data,
        createdAt: item.created_at,
        completed: item.completed,
        completedAt: item.completed_at
        };
      }).filter(lead => lead !== null); // Remove null entries
      
      console.log(`Mapped ${mappedLeads.length} valid leads from ${data.length} database records`);
      return mappedLeads;
    }
    
    console.warn('Database query failed, using localStorage fallback:', error);
  } catch (error) {
    console.error('Error fetching from database:', error);
  }

  // Fallback to localStorage
  console.log('Using localStorage fallback for leads');
  const localLeads = getStoredLeads();
  console.log(`Retrieved ${localLeads.length} leads from localStorage`);
  return localLeads;
};

// Separate function for auto-backup that can be called independently
export const performAutoBackupIfNeeded = async (): Promise<void> => {
  const lastAutoBackup = localStorage.getItem('lastAutoBackup');
  const now = Date.now();
  const oneHour = 60 * 60 * 1000;
  
  if (!lastAutoBackup || (now - parseInt(lastAutoBackup)) > oneHour) {
    try {
      const { createAutoBackup } = await import('./backupSystem');
      await createAutoBackup();
      localStorage.setItem('lastAutoBackup', now.toString());
      console.log('Auto-backup completed');
    } catch (error) {
      console.error('Auto-backup failed:', error);
    }
  }
};