/**
 * Converts a Google Drive sharing URL to a direct image URL
 * @param url - Google Drive sharing URL
 * @returns Direct image URL or original URL if not a Google Drive link
 */
export const convertGoogleDriveUrl = (url: string): string => {
  if (!url) return url;
  
  // Check if it's a Google Drive sharing URL (handles multiple formats)
  const driveRegex = /https:\/\/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)(?:\/view)?(?:\?usp=(?:sharing|drivesdk|drive_link))?/;
  const match = url.match(driveRegex);
  
  if (match && match[1]) {
    const fileId = match[1];
    // Try multiple Google Drive direct access methods
    return `https://drive.google.com/uc?export=download&id=${fileId}`;
  }
  
  // If it's already a direct Google Drive URL, return as is  
  if (url.includes('drive.google.com/uc?export=')) {
    return url;
  }
  
  // Return original URL if not a Google Drive link
  return url;
};

/**
 * Gets multiple possible URLs for a Google Drive image
 * @param url - Original Google Drive URL
 * @returns Array of possible URLs to try
 */
export const getGoogleDriveImageUrls = (url: string): string[] => {
  if (!url) return [url];
  
  const driveRegex = /https:\/\/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)(?:\/view)?(?:\?usp=(?:sharing|drivesdk|drive_link))?/;
  const match = url.match(driveRegex);
  
  if (match && match[1]) {
    const fileId = match[1];
    return [
      `https://drive.google.com/uc?export=download&id=${fileId}`,
      `https://drive.google.com/uc?export=view&id=${fileId}`,
      `https://drive.google.com/thumbnail?id=${fileId}&sz=w400`,
      url // Original URL as last resort
    ];
  }
  
  return [url];
};

/**
 * Validates if an image URL is accessible
 * @param url - Image URL to validate
 * @returns Promise that resolves to true if image is accessible
 */
export const validateImageUrl = (url: string): Promise<boolean> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(true);
    img.onerror = () => resolve(false);
    img.src = url;
  });
};