import { NotificationRule, NotificationLayer, NotificationRecipient, NotificationLog, StoredLead } from '../types';
import { sendLeadNotificationSMS } from '../services/aloware';

const NOTIFICATION_RULES_KEY = 'customNotificationRules';
const NOTIFICATION_LOGS_KEY = 'customNotificationLogs';
const NOTIFICATION_TRACKING_KEY = 'notificationTracking';

// Generate unique IDs
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Get all notification rules
export const getNotificationRules = (): NotificationRule[] => {
  try {
    const stored = localStorage.getItem(NOTIFICATION_RULES_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading notification rules:', error);
    return [];
  }
};

// Save notification rules
export const saveNotificationRules = (rules: NotificationRule[]): void => {
  try {
    localStorage.setItem(NOTIFICATION_RULES_KEY, JSON.stringify(rules));
  } catch (error) {
    console.error('Error saving notification rules:', error);
  }
};

// Add or update notification rule
export const saveNotificationRule = (rule: NotificationRule): void => {
  const rules = getNotificationRules();
  const existingIndex = rules.findIndex(r => r.id === rule.id);
  
  if (existingIndex >= 0) {
    rules[existingIndex] = { ...rule, updatedAt: new Date().toISOString() };
  } else {
    rules.push({ ...rule, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
  }
  
  saveNotificationRules(rules);
};

// Delete notification rule
export const deleteNotificationRule = (ruleId: string): void => {
  const rules = getNotificationRules();
  const filteredRules = rules.filter(r => r.id !== ruleId);
  saveNotificationRules(filteredRules);
};

// Get notification logs
export const getNotificationLogs = (): NotificationLog[] => {
  try {
    const stored = localStorage.getItem(NOTIFICATION_LOGS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading notification logs:', error);
    return [];
  }
};

// Add notification log
export const addNotificationLog = (log: NotificationLog): void => {
  try {
    const logs = getNotificationLogs();
    logs.unshift(log); // Add to beginning
    
    // Keep only last 1000 logs
    const trimmedLogs = logs.slice(0, 1000);
    localStorage.setItem(NOTIFICATION_LOGS_KEY, JSON.stringify(trimmedLogs));
  } catch (error) {
    console.error('Error saving notification log:', error);
  }
};

// Clear notification logs
export const clearNotificationLogs = (): void => {
  localStorage.removeItem(NOTIFICATION_LOGS_KEY);
};

// Notification tracking to prevent duplicates
interface NotificationTracking {
  [leadId: string]: {
    [ruleId: string]: {
      [layerId: string]: string; // timestamp when sent
    };
  };
}

export const getNotificationTracking = (): NotificationTracking => {
  try {
    const stored = localStorage.getItem(NOTIFICATION_TRACKING_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch (error) {
    console.error('Error loading notification tracking:', error);
    return {};
  }
};

export const markNotificationSent = (leadId: string, ruleId: string, layerId: string): void => {
  try {
    const tracking = getNotificationTracking();
    
    if (!tracking[leadId]) tracking[leadId] = {};
    if (!tracking[leadId][ruleId]) tracking[leadId][ruleId] = {};
    
    tracking[leadId][ruleId][layerId] = new Date().toISOString();
    
    localStorage.setItem(NOTIFICATION_TRACKING_KEY, JSON.stringify(tracking));
  } catch (error) {
    console.error('Error marking notification as sent:', error);
  }
};

export const hasNotificationBeenSent = (leadId: string, ruleId: string, layerId: string): boolean => {
  try {
    const tracking = getNotificationTracking();
    return !!(tracking[leadId]?.['ruleId']?.[layerId]);
  } catch (error) {
    console.error('Error checking notification status:', error);
    return false;
  }
};

// Check if lead matches conditions
export const leadMatchesConditions = (lead: StoredLead, conditions?: NotificationLayer['conditions']): boolean => {
  if (!conditions) return true;
  
  // Check store filter
  if (conditions.stores && conditions.stores.length > 0) {
    if (!conditions.stores.includes(lead.data.store || '')) {
      return false;
    }
  }
  
  // Check lead type filter
  if (conditions.leadTypes && conditions.leadTypes.length > 0) {
    const leadType = lead.data.leadType || 'Customer';
    if (!conditions.leadTypes.includes(leadType)) {
      return false;
    }
  }
  
  // Check market filter
  if (conditions.markets && conditions.markets.length > 0) {
    const market = getMarketFromStore(lead.data.store || '');
    if (!conditions.markets.includes(market)) {
      return false;
    }
  }
  
  return true;
};

// Helper function to determine market from store
const getMarketFromStore = (store: string): string => {
  if (!store) return 'Unknown';
  const upperStore = store.toUpperCase();
  
  if (upperStore.startsWith('TX ') || upperStore.startsWith('TX_') || upperStore === 'TX') return 'Texas';
  if (upperStore.startsWith('CA ') || upperStore.startsWith('CA_') || upperStore === 'CA') return 'California';
  if (upperStore.startsWith('VA ') || upperStore.startsWith('VA_') || upperStore === 'VA') return 'Virginia';
  
  if (upperStore.includes('TX')) return 'Texas';
  if (upperStore.includes('VA')) return 'Virginia';
  if (upperStore.includes('CA')) return 'California';
  
  return 'Other';
};

// Send notification via SMS
export const sendCustomNotification = async (
  lead: StoredLead,
  layer: NotificationLayer,
  recipient: NotificationRecipient,
  ruleId: string
): Promise<{ success: boolean; message: string; error?: string }> => {
  try {
    // Replace placeholders in message
    const message = layer.message
      .replace('{licensePlate}', lead.data.licensePlate || 'N/A')
      .replace('{store}', lead.data.store || 'N/A')
      .replace('{leadType}', lead.data.leadType || 'Customer')
      .replace('{time}', lead.data.time ? new Date(lead.data.time).toLocaleString() : 'N/A')
      .replace('{ageMinutes}', Math.floor((Date.now() - new Date(lead.createdAt).getTime()) / (1000 * 60)).toString())
      .replace('{completionLink}', `${window.location.origin}/complete-lead/${lead.id}`);

    if (recipient.type === 'phone') {
      const result = await sendLeadNotificationSMS(recipient.value, {
        id: lead.id,
        licensePlate: lead.data.licensePlate || '',
        store: lead.data.store || '',
        time: lead.data.time || lead.createdAt
      });
      
      // Log the notification
      const log: NotificationLog = {
        id: generateId(),
        ruleId,
        layerId: layer.id,
        leadId: lead.id,
        recipient,
        status: result.success ? 'sent' : 'failed',
        sentAt: new Date().toISOString(),
        error: result.error
      };
      
      addNotificationLog(log);
      
      if (result.success) {
        markNotificationSent(lead.id, ruleId, layer.id);
      }
      
      return result;
    } else if (recipient.type === 'email') {
      // Email notifications would be implemented here
      console.log('Email notification not yet implemented:', recipient.value, message);
      return { success: false, message: 'Email notifications not yet implemented' };
    } else if (recipient.type === 'webhook') {
      // Webhook notifications would be implemented here
      console.log('Webhook notification not yet implemented:', recipient.value, message);
      return { success: false, message: 'Webhook notifications not yet implemented' };
    }
    
    return { success: false, message: 'Unknown recipient type' };
  } catch (error) {
    console.error('Error sending custom notification:', error);
    return { success: false, message: 'Failed to send notification', error: error.message };
  }
};

// Process all notification rules for leads
export const processCustomNotifications = async (leads: StoredLead[]): Promise<void> => {
  const rules = getNotificationRules().filter(rule => rule.enabled);
  
  if (rules.length === 0) {
    console.log('No enabled notification rules found');
    return;
  }
  
  console.log(`Processing ${rules.length} notification rules for ${leads.length} leads`);
  
  for (const rule of rules) {
    for (const lead of leads) {
      // Skip completed leads
      if (lead.completed) continue;
      
      const leadAgeMinutes = Math.floor((Date.now() - new Date(lead.createdAt).getTime()) / (1000 * 60));
      
      for (const layer of rule.layers) {
        // Check if enough time has passed
        if (leadAgeMinutes < layer.delayMinutes) continue;
        
        // Check if notification already sent
        if (hasNotificationBeenSent(lead.id, rule.id, layer.id)) continue;
        
        // Check if lead matches conditions
        if (!leadMatchesConditions(lead, layer.conditions)) continue;
        
        console.log(`Sending notification for lead ${lead.id} via rule ${rule.name} layer ${layer.id}`);
        
        // Send to all recipients in this layer
        for (const recipient of layer.recipients) {
          try {
            await sendCustomNotification(lead, layer, recipient, rule.id);
            
            // Add small delay between notifications
            await new Promise(resolve => setTimeout(resolve, 1000));
          } catch (error) {
            console.error(`Error sending notification to ${recipient.value}:`, error);
          }
        }
      }
    }
  }
};

// Clear all notification tracking (for testing)
export const clearNotificationTracking = (): void => {
  localStorage.removeItem(NOTIFICATION_TRACKING_KEY);
  console.log('Notification tracking cleared');
};