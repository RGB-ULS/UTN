import { StoredLead } from '../types';

export interface WebhookNotification {
  type: 'lead_overdue';
  leadId: string;
  licensePlate: string;
  store: string;
  createdAt: string;
  minutesOverdue: number;
  shareableLink: string;
}

export interface WebhookConfig {
  managerWebhookUrl: string;
  overdueThresholdMinutes: number;
  enabled: boolean;
  monitoringStartTime?: string;
}

// Default configuration - can be customized
const DEFAULT_CONFIG: WebhookConfig = {
  managerWebhookUrl: '', // Set this to your manager notification webhook URL
  overdueThresholdMinutes: 45,
  enabled: false, // Enable when webhook URL is configured
  monitoringStartTime: undefined
};

// Get webhook configuration from localStorage or use defaults
export const getWebhookConfig = (): WebhookConfig => {
  try {
    const stored = localStorage.getItem('webhookConfig');
    if (stored) {
      const parsedConfig = JSON.parse(stored);
      console.log('Loaded webhook config from localStorage:', parsedConfig);
      return { ...DEFAULT_CONFIG, ...parsedConfig };
    }
  } catch (error) {
    console.error('Error loading webhook config:', error);
  }
  console.log('Using default webhook config:', DEFAULT_CONFIG);
  return DEFAULT_CONFIG;
};

// Save webhook configuration
export const saveWebhookConfig = (config: WebhookConfig): void => {
  try {
    console.log('Saving webhook config:', config);
    localStorage.setItem('webhookConfig', JSON.stringify(config));
    
    // Verify it was saved correctly
    const saved = localStorage.getItem('webhookConfig');
    const parsed = saved ? JSON.parse(saved) : null;
    console.log('Webhook config saved and verified:', parsed);
  } catch (error) {
    console.error('Error saving webhook config:', error);
  }
};

// Check if a lead is overdue
export const isLeadOverdue = (lead: StoredLead, thresholdMinutes: number = 45): boolean => {
  if (lead.completed) return false;
  
  const createdTime = new Date(lead.createdAt).getTime();
  const currentTime = new Date().getTime();
  const minutesElapsed = (currentTime - createdTime) / (1000 * 60);
  
  return minutesElapsed > thresholdMinutes;
};

// Get minutes elapsed since lead creation
export const getMinutesElapsed = (lead: StoredLead): number => {
  const createdTime = new Date(lead.createdAt).getTime();
  const currentTime = new Date().getTime();
  return Math.floor((currentTime - createdTime) / (1000 * 60));
};

// Send webhook notification for overdue lead
export const sendOverdueLeadNotification = async (lead: StoredLead, config: WebhookConfig): Promise<boolean> => {
  // EMERGENCY STOP - Check at the very beginning
  if (isEmergencyStopActive()) {
    console.log('🛑 EMERGENCY STOP ACTIVE - Blocking individual notification send');
    return false;
  }
  
  if (!config.enabled || !config.managerWebhookUrl) {
    console.log('Webhook notifications disabled or URL not configured');
    return false;
  }

  // Validate lead data before sending
  if (!lead || !lead.id || !lead.data) {
    console.error('Invalid lead data for webhook notification:', lead);
    return false;
  }

  // Ensure required lead fields exist
  if (!lead.data.licensePlate && !lead.data.store) {
    console.error('Lead missing required data (licensePlate or store):', lead);
    return false;
  }

  const minutesOverdue = getMinutesElapsed(lead);
  const shareableLink = `${window.location.origin}/complete-lead/${lead.id}`;

  const notification: WebhookNotification = {
    type: 'lead_overdue',
    leadId: lead.id,
    licensePlate: lead.data.licensePlate || '',
    store: lead.data.store || 'N/A',
    createdAt: lead.createdAt,
    minutesOverdue,
    shareableLink
  };

  // Validate notification payload
  if (!notification.leadId || (!notification.licensePlate && !notification.store)) {
    console.error('Invalid notification payload:', notification);
    return false;
  }

  try {
    console.log('Sending overdue lead notification:', notification);
    
    // Final emergency stop check before actual send
    if (isEmergencyStopActive()) {
      console.log('🛑 EMERGENCY STOP - Blocking webhook send at last moment');
      return false;
    }
    
    // Try different approaches for webhook delivery
    let response;
    let success = false;
    
    try {
      // First try with CORS mode
      response = await fetch(config.managerWebhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(notification),
        mode: 'cors'
      });
      
      if (response.ok) {
        success = true;
        console.log('Webhook sent successfully with CORS mode');
      }
    } catch (corsError) {
      console.log('CORS mode failed, trying no-cors mode:', corsError);
      
      try {
        // Try with no-cors mode
        response = await fetch(config.managerWebhookUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(notification),
          mode: 'no-cors'
        });
        
        // With no-cors, we can't read response but no error means likely success
        success = true;
        console.log('Webhook sent with no-cors mode (response unreadable but likely successful)');
      } catch (noCorsError) {
        console.error('Both CORS and no-cors modes failed:', noCorsError);
        success = false;
      }
    }

    if (success) {
      console.log('Overdue lead notification sent successfully');
      
      // Mark this lead as notified to avoid duplicate notifications
      markLeadAsNotified(lead.id);
      return true;
    } else {
      console.error('Failed to send overdue lead notification');
      return false;
    }
  } catch (error) {
    console.error('Error sending overdue lead notification:', error);
    return false;
  }
};

// Track which leads have been notified to avoid duplicates
const NOTIFIED_LEADS_KEY = 'notifiedOverdueLeads';

export const markLeadAsNotified = (leadId: string): void => {
  try {
    const notified = getNotifiedLeads();
    const timestamp = new Date().toISOString();
    notified[leadId] = timestamp;
    
    // Clean up old notifications (older than 24 hours)
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    Object.keys(notified).forEach(id => {
      if (notified[id] < oneDayAgo) {
        delete notified[id];
      }
    });
    
    localStorage.setItem(NOTIFIED_LEADS_KEY, JSON.stringify(notified));
  } catch (error) {
    console.error('Error marking lead as notified:', error);
  }
};

export const hasBeenNotified = (leadId: string): boolean => {
  try {
    const notified = getNotifiedLeads();
    return leadId in notified;
  } catch (error) {
    console.error('Error checking notification status:', error);
    return false;
  }
};

const getNotifiedLeads = (): Record<string, string> => {
  try {
    const stored = localStorage.getItem(NOTIFIED_LEADS_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch (error) {
    console.error('Error loading notified leads:', error);
    return {};
  }
};

// Check all leads and send notifications for overdue ones
export const checkAndNotifyOverdueLeads = async (leads: StoredLead[]): Promise<void> => {
  // EMERGENCY STOP - FIRST AND MOST IMPORTANT CHECK
  if (isEmergencyStopActive()) {
    console.log('🛑🛑🛑 EMERGENCY STOP ACTIVE - BLOCKING ALL WEBHOOK OPERATIONS 🛑🛑🛑');
    return;
  }
  
  const config = getWebhookConfig();
  console.log('Using webhook config for notifications:', config);
  
  // Double check emergency stop after loading config
  if (isEmergencyStopActive()) {
    console.log('🛑 EMERGENCY STOP STILL ACTIVE AFTER CONFIG LOAD - ABORTING');
    return;
  }
  
  if (!config.enabled) {
    console.log('Webhook notifications are disabled. Config enabled:', config.enabled);
    return;
  }
  
  if (!config.managerWebhookUrl) {
    console.log('No webhook URL configured. URL:', config.managerWebhookUrl);
    return;
  }

  // Validate leads array
  if (!Array.isArray(leads)) {
    console.error('Invalid leads array provided to checkAndNotifyOverdueLeads:', leads);
    return;
  }

  // Filter out invalid leads
  const validLeads = leads.filter(lead => {
    if (!lead || !lead.id || !lead.data || !lead.createdAt) {
      console.warn('Filtering out invalid lead:', lead);
      return false;
    }
    return true;
  });

  console.log(`Filtered leads: ${leads.length} total, ${validLeads.length} valid`);

  // Only check leads created after monitoring was enabled
  let leadsToCheck = validLeads;
  if (config.monitoringStartTime) {
    const monitoringStart = new Date(config.monitoringStartTime).getTime();
    leadsToCheck = validLeads.filter(lead => {
      const leadCreatedTime = new Date(lead.createdAt).getTime();
      return leadCreatedTime >= monitoringStart;
    });
    console.log(`Filtering leads: ${validLeads.length} valid, ${leadsToCheck.length} created after monitoring started (${new Date(config.monitoringStartTime).toLocaleString()})`);
  }

  console.log('Checking for overdue leads...');
  console.log(`Using threshold: ${config.overdueThresholdMinutes} minutes (from config)`);
  console.log(`Total leads to check: ${leadsToCheck.length}`);
  
  const overdueLeads = leadsToCheck.filter(lead => 
    !lead.completed && 
    isLeadOverdue(lead, config.overdueThresholdMinutes) &&
    !hasBeenNotified(lead.id)
  );

  console.log(`Found ${overdueLeads.length} overdue leads that haven't been notified yet (threshold: ${config.overdueThresholdMinutes} minutes)`);
  
  if (overdueLeads.length === 0) {
    console.log('No new overdue leads to notify');
    return;
  }

  for (const lead of overdueLeads) {
    // Check emergency stop before each notification
    if (isEmergencyStopActive()) {
      console.log('🛑 EMERGENCY STOP DETECTED DURING NOTIFICATION LOOP - STOPPING');
      return;
    }
    
    // Double-check lead validity before processing
    if (!lead || !lead.id || !lead.data) {
      console.error('Skipping invalid lead in notification loop:', lead);
      continue;
    }

    const minutesElapsed = getMinutesElapsed(lead);
    console.log(`Processing lead ${lead.id}: ${minutesElapsed} minutes old (${minutesElapsed - config.overdueThresholdMinutes} minutes overdue)`);
    console.log(`Lead data:`, {
      id: lead.id,
      licensePlate: lead.data.licensePlate,
      store: lead.data.store,
      createdAt: lead.createdAt
    });
    
    const success = await sendOverdueLeadNotification(lead, config);
    if (!success) {
      console.error(`Failed to send notification for lead ${lead.id}`);
    }
    
    // Add a small delay between notifications to avoid overwhelming the webhook endpoint
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  console.log('Finished processing overdue leads');
};

// Clear all notification tracking (useful for testing)
export const clearNotificationHistory = (): void => {
  localStorage.removeItem(NOTIFIED_LEADS_KEY);
  console.log('Notification history cleared');
};

// Emergency stop - disable all webhook functionality immediately
export const emergencyStopWebhooks = (): void => {
  console.log('🚨🚨🚨 EMERGENCY WEBHOOK STOP ACTIVATED 🚨🚨🚨');
  
  // Disable webhooks immediately
  const config = getWebhookConfig();
  config.enabled = false;
  saveWebhookConfig(config);
  console.log('✅ Webhook config disabled and saved');
  
  // Clear notification history so nothing gets sent
  clearNotificationHistory();
  console.log('✅ Notification history cleared');
  
  // Set emergency stop flag
  const stopTime = new Date().toISOString();
  localStorage.setItem('webhookEmergencyStop', stopTime);
  console.log('✅ Emergency stop flag set:', stopTime);
  
  // Also set a backup flag
  localStorage.setItem('webhookEmergencyStopBackup', stopTime);
  
  console.log('✅✅✅ ALL WEBHOOK NOTIFICATIONS STOPPED AND CLEARED ✅✅✅');
};

// Check if emergency stop is active
export const isEmergencyStopActive = (): boolean => {
  const stopFlag = localStorage.getItem('webhookEmergencyStop') !== null;
  const backupFlag = localStorage.getItem('webhookEmergencyStopBackup') !== null;
  const isActive = stopFlag || backupFlag;
  
  if (isActive) {
    console.log('🛑 Emergency stop check: ACTIVE');
  }
  
  return isActive;
};

// Clear emergency stop
export const clearEmergencyStop = (): void => {
  localStorage.removeItem('webhookEmergencyStop');
  localStorage.removeItem('webhookEmergencyStopBackup');
  console.log('✅ Emergency stop cleared (both flags removed)');
};

// Enhanced check function with emergency stop protection
export const safeCheckAndNotifyOverdueLeads = async (leads: StoredLead[]): Promise<void> => {
  // TRIPLE EMERGENCY STOP CHECK
  console.log('🔍 SAFE CHECK: Verifying emergency stop status...');
  if (isEmergencyStopActive()) {
    console.log('🛑🛑🛑 SAFE CHECK: EMERGENCY STOP ACTIVE - BLOCKING ALL OPERATIONS 🛑🛑🛑');
    return;
  }
  
  // Second check
  if (isEmergencyStopActive()) {
    console.log('🛑 SAFE CHECK: Emergency stop confirmed - skipping webhook notifications');
    return;
  }
  
  console.log('✅ SAFE CHECK: No emergency stop detected, proceeding...');
  return checkAndNotifyOverdueLeads(leads);
};