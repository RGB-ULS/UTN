import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart3, 
  Users, 
  Settings, 
  Database, 
  Bell, 
  MessageSquare,
  MapPin,
  Shield,
  LogOut,
  Home
} from 'lucide-react';
import AdminLogin from './AdminLogin';
import UserManagement from './UserManagement';
import WebhookSettings from './WebhookSettings';
import BackupRecovery from './BackupRecovery';
import AlowareSMSTest from './AlowareSMSTest';
import CustomNotifications from './CustomNotifications';
import StoreNotifications from './StoreNotifications';
import { getAllLeads, clearAllLeads } from '../utils/storage';
import { getWebhookLogs, clearWebhookLogs } from '../utils/storage';
import { StoredLead, WebhookLog } from '../types';

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'webhooks' | 'sms' | 'notifications' | 'stores' | 'backup'>('overview');
  const [leads, setLeads] = useState<StoredLead[]>([]);
  const [webhookLogs, setWebhookLogs] = useState<WebhookLog[]>([]);
  const [loading, setLoading] = useState(false);

  // Check authentication on component mount
  useEffect(() => {
    // Always start unauthenticated - force login
    setIsAuthenticated(false);
    sessionStorage.removeItem('adminAuthenticated');
  }, []);

  React.useEffect(() => {
    if (isAuthenticated) {
      loadData();
    }
  }, [isAuthenticated]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [leadsData, logsData] = await Promise.all([
        getAllLeads(),
        Promise.resolve(getWebhookLogs())
      ]);
      setLeads(leadsData);
      setWebhookLogs(logsData);
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    sessionStorage.removeItem('adminAuthenticated');
    setIsAuthenticated(false);
    navigate('/');
  };

  const handleClearAllLeads = async () => {
    if (window.confirm('Are you sure you want to clear all leads? This action cannot be undone.')) {
      await clearAllLeads();
      await loadData();
    }
  };

  const handleClearWebhookLogs = () => {
    if (window.confirm('Are you sure you want to clear all webhook logs?')) {
      clearWebhookLogs();
      setWebhookLogs([]);
    }
  };

  if (!isAuthenticated) {
    return <AdminLogin onLogin={handleLogin} />;
  }

  const completedLeads = leads.filter(lead => lead.completed);
  const pendingLeads = leads.filter(lead => !lead.completed);
  const recentLogs = webhookLogs.slice(0, 10);

  return (
    <div className="min-h-screen ulrich-gradient-light py-6 sm:py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="ulrich-card rounded-xl shadow-lg mb-6 sm:mb-8">
          <div className="p-4 sm:p-6 border-b border-gray-200">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <img 
                  src="/ulrich-logo.png"
                  alt="Ulrich - Built for You. Made for Life." 
                  className="h-12 sm:h-16 mb-2"
                />
                <h1 className="text-xl sm:text-2xl font-bold" style={{ color: '#435B75' }}>Admin Dashboard</h1>
                <p className="text-gray-600 mt-1 text-sm sm:text-base">Manage your lead system and settings</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                <button
                  onClick={() => navigate('/')}
                  className="btn-ulrich-secondary py-2 px-4 rounded-lg font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center text-sm min-h-[44px]"
                  style={{ '--tw-ring-color': '#435B75' }}
                >
                  <Home className="w-4 h-4 mr-2 flex-shrink-0" />
                  Homepage
                </button>
                <button
                  onClick={() => navigate('/admin/management')}
                  className="btn-ulrich-primary py-2 px-4 rounded-lg font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center text-sm min-h-[44px]"
                  style={{ '--tw-ring-color': '#B8906B' }}
                >
                  <BarChart3 className="w-4 h-4 mr-2 flex-shrink-0" />
                  Management Dashboard
                </button>
                <button
                  onClick={handleLogout}
                  className="bg-red-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center text-sm min-h-[44px]"
                >
                  <LogOut className="w-4 h-4 mr-2 flex-shrink-0" />
                  Logout
                </button>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-gray-200 overflow-x-auto scrollbar-hide">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-4 sm:px-6 py-3 font-medium text-xs sm:text-sm border-b-2 transition-colors whitespace-nowrap flex items-center ${
                activeTab === 'overview'
                  ? 'text-white'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
              style={activeTab === 'overview' ? { borderColor: '#B8906B', color: '#B8906B' } : {}}
            >
              <BarChart3 className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Overview
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`px-4 sm:px-6 py-3 font-medium text-xs sm:text-sm border-b-2 transition-colors whitespace-nowrap flex items-center ${
                activeTab === 'users'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Users className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              User Management
            </button>
            <button
              onClick={() => setActiveTab('webhooks')}
              className={`px-4 sm:px-6 py-3 font-medium text-xs sm:text-sm border-b-2 transition-colors whitespace-nowrap flex items-center ${
                activeTab === 'webhooks'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Bell className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Webhook Settings
            </button>
            <button
              onClick={() => setActiveTab('sms')}
              className={`px-4 sm:px-6 py-3 font-medium text-xs sm:text-sm border-b-2 transition-colors whitespace-nowrap flex items-center ${
                activeTab === 'sms'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <MessageSquare className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              SMS Testing
            </button>
            <button
              onClick={() => setActiveTab('notifications')}
              className={`px-4 sm:px-6 py-3 font-medium text-xs sm:text-sm border-b-2 transition-colors whitespace-nowrap flex items-center ${
                activeTab === 'notifications'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Bell className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Custom Notifications
            </button>
            <button
              onClick={() => setActiveTab('stores')}
              className={`px-4 sm:px-6 py-3 font-medium text-xs sm:text-sm border-b-2 transition-colors whitespace-nowrap flex items-center ${
                activeTab === 'stores'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <MapPin className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Store Notifications
            </button>
            <button
              onClick={() => setActiveTab('backup')}
              className={`px-4 sm:px-6 py-3 font-medium text-xs sm:text-sm border-b-2 transition-colors whitespace-nowrap flex items-center ${
                activeTab === 'backup'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Database className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Backup & Recovery
            </button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-4 sm:space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
              <div className="ulrich-card rounded-xl shadow-lg p-4 sm:p-6">
                <div className="flex items-center">
                  <div className="p-1 sm:p-2 rounded-lg" style={{ backgroundColor: 'rgba(184, 144, 107, 0.1)' }}>
                    <BarChart3 className="w-4 h-4 sm:w-6 sm:h-6" style={{ color: '#B8906B' }} />
                  </div>
                  <div className="ml-2 sm:ml-4">
                    <p className="text-xs sm:text-sm font-medium text-gray-600">Total Leads</p>
                    <p className="text-lg sm:text-2xl font-bold" style={{ color: '#435B75' }}>{leads.length}</p>
                  </div>
                </div>
              </div>

              <div className="ulrich-card rounded-xl shadow-lg p-4 sm:p-6">
                <div className="flex items-center">
                  <div className="p-1 sm:p-2 rounded-lg" style={{ backgroundColor: 'rgba(116, 139, 137, 0.1)' }}>
                    <Shield className="w-4 h-4 sm:w-6 sm:h-6" style={{ color: '#748B89' }} />
                  </div>
                  <div className="ml-2 sm:ml-4">
                    <p className="text-xs sm:text-sm font-medium text-gray-600">Completed</p>
                    <p className="text-lg sm:text-2xl font-bold" style={{ color: '#435B75' }}>{completedLeads.length}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
                <div className="flex items-center">
                  <div className="p-1 sm:p-2 bg-orange-100 rounded-lg">
                    <Settings className="w-4 h-4 sm:w-6 sm:h-6 text-orange-600" />
                  </div>
                  <div className="ml-2 sm:ml-4">
                    <p className="text-xs sm:text-sm font-medium text-gray-600">Pending</p>
                    <p className="text-lg sm:text-2xl font-bold text-gray-900">{pendingLeads.length}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
                <div className="flex items-center">
                  <div className="p-1 sm:p-2 bg-purple-100 rounded-lg">
                    <Bell className="w-4 h-4 sm:w-6 sm:h-6 text-purple-600" />
                  </div>
                  <div className="ml-2 sm:ml-4">
                    <p className="text-xs sm:text-sm font-medium text-gray-600">Webhook Logs</p>
                    <p className="text-lg sm:text-2xl font-bold text-gray-900">{webhookLogs.length}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              {/* Recent Leads */}
              <div className="bg-white rounded-xl shadow-lg">
                <div className="p-4 sm:p-6 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base sm:text-lg font-semibold text-gray-900">Recent Leads</h3>
                    <button
                      onClick={handleClearAllLeads}
                      className="text-red-600 hover:text-red-700 text-xs sm:text-sm font-medium"
                    >
                      Clear All
                    </button>
                  </div>
                </div>
                <div className="p-4 sm:p-6">
                  {loading ? (
                    <div className="text-center py-3 sm:py-4">
                      <div className="animate-spin rounded-full h-6 w-6 sm:h-8 sm:w-8 border-b-2 border-blue-600 mx-auto"></div>
                    </div>
                  ) : leads.length === 0 ? (
                    <p className="text-gray-500 text-center py-3 sm:py-4 text-sm">No leads yet</p>
                  ) : (
                    <div className="space-y-2 sm:space-y-3">
                      {leads.slice(0, 5).map((lead) => (
                        <div key={lead.id} className="flex items-center justify-between p-2 sm:p-3 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900 text-sm sm:text-base">
                              {lead.data.licensePlate || 'No License'}
                            </p>
                            <p className="text-xs sm:text-sm text-gray-600">
                              {lead.data.store} • {new Date(lead.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full flex-shrink-0 ${
                            lead.completed 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-orange-100 text-orange-800'
                          }`}>
                            {lead.completed ? 'Complete' : 'Pending'}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Recent Webhook Logs */}
              <div className="bg-white rounded-xl shadow-lg">
                <div className="p-4 sm:p-6 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base sm:text-lg font-semibold text-gray-900">Webhook Activity</h3>
                    <button
                      onClick={handleClearWebhookLogs}
                      className="text-red-600 hover:text-red-700 text-xs sm:text-sm font-medium"
                    >
                      Clear Logs
                    </button>
                  </div>
                </div>
                <div className="p-4 sm:p-6">
                  {recentLogs.length === 0 ? (
                    <p className="text-gray-500 text-center py-3 sm:py-4 text-sm">No webhook activity</p>
                  ) : (
                    <div className="space-y-2 sm:space-y-3">
                      {recentLogs.map((log) => (
                        <div key={log.id} className="flex items-center justify-between p-2 sm:p-3 bg-gray-50 rounded-lg">
                          <div>
                            <p className="text-xs sm:text-sm text-gray-900">
                              {new Date(log.timestamp).toLocaleString()}
                            </p>
                            <p className="text-xs text-gray-600">
                              {log.payload?.licensePlate || 'Unknown'} • {log.payload?.store || 'Unknown Store'}
                            </p>
                          </div>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full flex-shrink-0 ${
                            log.status === 'success' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {log.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'users' && <UserManagement />}
        {activeTab === 'webhooks' && <WebhookSettings />}
        {activeTab === 'sms' && <AlowareSMSTest />}
        {activeTab === 'notifications' && <CustomNotifications />}
        {activeTab === 'stores' && <StoreNotifications />}
        {activeTab === 'backup' && <BackupRecovery />}
      </div>
    </div>
  );
};

export default AdminDashboard;