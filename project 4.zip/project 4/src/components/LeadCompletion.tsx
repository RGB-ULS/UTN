import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AlertCircle, User, Mail, Phone, MapPin, Users, UserCheck, FileText } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getStoredLead, markLeadCompleted } from '../utils/storage';
import { StoredLead, CustomerData } from '../types';
import { validateEmail, validatePhoneNumber, formatPhoneNumber, validateZipCode } from '../utils/validation';
import { submitToGoogleSheets } from '../services/googleSheets';
import { getGoogleDriveImageUrls } from '../utils/imageUtils';
import { getActiveUsers } from '../utils/userManagement';

const LeadCompletion: React.FC = () => {
  const { leadId } = useParams<{ leadId: string }>();
  const navigate = useNavigate();
  
  const [storedLead, setStoredLead] = useState<StoredLead | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [customerData, setCustomerData] = useState<CustomerData>({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    zipCode: '',
    notes: ''
  });
  
  const [leadType, setLeadType] = useState<string>('');
  const [isNotCustomer, setIsNotCustomer] = useState(false);
  const [repEmail, setRepEmail] = useState<string>('');
  const [availableUsers, setAvailableUsers] = useState<any[]>([]);
  const [validationErrors, setValidationErrors] = useState<Partial<CustomerData> & { leadType?: string; repEmail?: string; notes?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [usersLoaded, setUsersLoaded] = useState(false);

  // Image loading state
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Load available users
  useEffect(() => {
    const loadUsers = async () => {
      try {
        const users = await getActiveUsers();
        console.log('Loading users in LeadCompletion:', users);
        setAvailableUsers(users);
        
        // Auto-select sales rep if logged in
        const sessionRepEmail = sessionStorage.getItem('salesRepEmail');
        if (sessionRepEmail && users.some(user => user.email === sessionRepEmail)) {
          setRepEmail(sessionRepEmail);
        }
        
        setUsersLoaded(true);
      } catch (error) {
        console.error('Error loading users:', error);
        setUsersLoaded(true);
      }
    };

    // Load users immediately
    loadUsers();
  }, []);

  useEffect(() => {
    if (!leadId) {
      setError('Invalid lead ID');
      setLoading(false);
      return;
    }

    const fetchLead = async () => {
      try {
        console.log('Fetching lead from localStorage:', leadId);
        
        const lead = await getStoredLead(leadId);
        if (lead) {
          console.log('Found lead:', lead);
          
          if (lead.completed) {
            setError('This lead has already been completed');
            setLoading(false);
            return;
          }
          
          setStoredLead(lead);
          setLoading(false);
          
          // Set up image URLs if image exists
          if (lead.data.image) {
            const urls = getGoogleDriveImageUrls(lead.data.image);
            setImageUrls(urls);
          }
          
          return;
        }

        console.error('Lead not found:', leadId);
        setError('Lead not found. The lead ID may be incorrect or the lead may have been deleted.');
        setLoading(false);
      } catch (error) {
        console.error('Error fetching lead:', error);
        setError(`Unable to load lead: ${error.message || 'Unknown error'}. Please check your connection and try again.`);
        setLoading(false);
      }
    };
    
    fetchLead();
  }, [leadId]);

  const handleImageError = () => {
    if (currentImageIndex < imageUrls.length - 1) {
      setCurrentImageIndex(prev => prev + 1);
    } else {
      setImageLoaded(false);
    }
  };

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<CustomerData> & { leadType?: string; repEmail?: string; notes?: string } = {};

    // If "Not a customer" is checked, they must select a lead type
    if (isNotCustomer && !leadType) {
      newErrors.leadType = 'Please select a lead type';
    }
    
    // If "Not a customer" is checked, notes are required
    if (isNotCustomer && !customerData.notes?.trim()) {
      newErrors.notes = 'Notes are required for non-customer leads';
    }
    
    // Rep email is always required
    if (!repEmail.trim()) {
      newErrors.repEmail = 'Sales representative email is required';
    }

    // Only validate customer data if it's a customer (checkbox not checked)
    if (!isNotCustomer) {
      if (!customerData.firstName.trim()) {
        newErrors.firstName = 'First name is required';
      }

      if (!customerData.lastName.trim()) {
        newErrors.lastName = 'Last name is required';
      }

      if (!customerData.email.trim()) {
        newErrors.email = 'Email is required';
      } else if (!validateEmail(customerData.email)) {
        newErrors.email = 'Please enter a valid email address';
      }

      if (!customerData.phoneNumber.trim()) {
        newErrors.phoneNumber = 'Phone number is required';
      } else if (!validatePhoneNumber(customerData.phoneNumber)) {
        newErrors.phoneNumber = 'Please enter a valid US phone number';
      }

      if (!customerData.zipCode.trim()) {
        newErrors.zipCode = 'Zip code is required';
      } else if (!validateZipCode(customerData.zipCode)) {
        newErrors.zipCode = 'Please enter a valid US zip code';
      }
    }

    setValidationErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNotCustomerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const checked = e.target.checked;
    setIsNotCustomer(checked);
    
    if (!checked) {
      // If unchecking "Not a customer", reset to customer mode
      setLeadType('');
    } else {
      // If checking "Not a customer", clear customer validation errors
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.firstName;
        delete newErrors.lastName;
        delete newErrors.email;
        delete newErrors.phoneNumber;
        delete newErrors.zipCode;
        return newErrors;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !storedLead) {
      return;
    }

    setIsSubmitting(true);

    try {
      const submissionData = {
        ...storedLead.data,
        leadType: isNotCustomer ? leadType : 'Customer',
        repEmail,
        notes: customerData.notes?.trim() || undefined,
        customerData: !isNotCustomer ? {
          ...customerData,
          phoneNumber: formatPhoneNumber(customerData.phoneNumber)
        } : undefined
      };

      console.log('Submitting lead completion with data:', submissionData);

      // Update the lead in the database with the final lead type and customer data
      try {
        // Mark as completed in database
        const { error: updateError } = await supabase
          .from('leads')
          .update({
            data: {
              ...storedLead.data,
              leadType: submissionData.leadType
            },
            customer_data: submissionData.customerData,
            completed: true,
            completed_at: new Date().toISOString()
          })
          .eq('id', storedLead.id);

        if (updateError) {
          console.error('Error updating lead in database:', updateError);
        } else {
          console.log('Lead updated in database successfully');
        }
      } catch (dbError) {
        console.error('Database update failed:', dbError);
      }

      // Also mark as completed in localStorage as fallback
      await markLeadCompleted(storedLead.id);

      const success = await submitToGoogleSheets(submissionData);
      
      if (success) {
        navigate('/lead-completed');
      } else {
        setError('Failed to submit to Google Sheets. Please try again.');
      }
    } catch (error) {
      console.error('Error submitting lead completion:', error);
      setError('An error occurred while submitting. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCustomerData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear error when user starts typing
    if (validationErrors[name as keyof CustomerData]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const handleLeadTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setLeadType(value);

    // Clear validation errors when lead type changes
    if ((validationErrors as any).leadType) {
      setValidationErrors(prev => ({
        ...prev,
        leadType: undefined
      }));
    }
  };

  const handleRepEmailChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setRepEmail(value);

    // Auto-fill from session if sales rep is logged in
    if (!value) {
      const sessionRepEmail = sessionStorage.getItem('salesRepEmail');
      if (sessionRepEmail) {
        setRepEmail(sessionRepEmail);
      }
    }

    // Clear validation errors when rep email changes
    if ((validationErrors as any).repEmail) {
      setValidationErrors(prev => ({
        ...prev,
        repEmail: undefined
      }));
    }
  };

  const isCustomerLead = !isNotCustomer;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading lead information...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-pink-50 to-rose-50 flex items-center justify-center px-4">
        <div className="max-w-md mx-auto text-center">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-6">
              <AlertCircle className="w-8 h-8 text-red-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Unable to Load Lead</h1>
            <p className="text-gray-600 mb-6">{error}</p>
            <div className="space-y-3">
              <button
                onClick={() => navigate('/')}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Go to Homepage
              </button>
              {error.includes('browser session') && (
                <p className="text-sm text-gray-500">
                  Shareable links only work during the same browser session. 
                  For persistent links, webhook integration is required.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!storedLead) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-6 sm:py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto w-full">
        <div className="text-center mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Complete Lead Information</h1>
          <p className="text-sm sm:text-base text-gray-600 px-4">Please add customer details to complete this lead</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-4 sm:p-8 space-y-4 sm:space-y-6">
          {/* Lead Information Summary */}
          <div className="bg-gray-50 rounded-lg p-4 sm:p-6">
            <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Lead Details</h3>
            
            {/* Image */}
            {storedLead.data.image && imageUrls.length > 0 && (
              <div className="mb-3 sm:mb-4">
               <p className="text-sm font-medium text-gray-700 mb-2">Image:</p>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 sm:p-4">
                  {imageLoaded || currentImageIndex < imageUrls.length ? (
                    <img 
                      src={imageUrls[currentImageIndex]} 
                      alt="Lead Image" 
                      className="max-w-full h-auto max-h-32 sm:max-h-48 mx-auto rounded-lg shadow-md"
                      onError={handleImageError}
                      onLoad={handleImageLoad}
                      style={{ display: imageLoaded ? 'block' : 'none' }}
                    />
                  ) : null}
                  
                  {!imageLoaded && currentImageIndex >= imageUrls.length && (
                    <div className="text-center text-gray-500 py-4 sm:py-8">
                      <div className="text-2xl sm:text-4xl mb-2">📷</div>
                      <p className="text-sm sm:text-base">Image could not be loaded</p>
                      <p className="text-xs mt-1 sm:mt-2">Google Drive image may require public access</p>
                    </div>
                  )}
                  
                  <details className="mt-2">
                    <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-700">
                      Show image URLs (trying {currentImageIndex + 1} of {imageUrls.length})
                    </summary>
                    <div className="mt-2 space-y-2">
                      <p className="text-xs text-gray-400 break-all bg-gray-50 p-2 rounded">
                        <strong>Original:</strong> {storedLead.data.image}
                      </p>
                      {imageUrls.map((url, index) => (
                        <p key={index} className={`text-xs break-all p-2 rounded ${
                          index === currentImageIndex ? 'bg-blue-50 text-blue-700' : 'bg-gray-50 text-gray-400'
                        }`}>
                          <strong>URL {index + 1}:</strong> {url}
                          {index === currentImageIndex && ' (current)'}
                        </p>
                      ))}
                    </div>
                  </details>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 text-xs sm:text-sm">
              <div>
                <p className="font-medium text-gray-700">License Plate:</p>
                <p className="text-gray-900">{storedLead.data.licensePlate}</p>
              </div>
              <div>
                <p className="font-medium text-gray-700">Store:</p>
                <p className="text-gray-900">{storedLead.data.store}</p>
              </div>
              <div>
                <p className="font-medium text-gray-700">Time:</p>
                <p className="text-gray-900">{new Date(storedLead.data.time).toLocaleString()}</p>
              </div>
              <div>
                <p className="font-medium text-gray-700">Lead Type:</p>
                <p className="text-gray-900">{isNotCustomer ? (leadType || 'Not yet selected') : 'Customer'}</p>
              </div>
            </div>
          </div>

          {/* Customer Form */}
          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
            {/* Initial Lot Greeting Guidelines */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 sm:p-6">
              <h3 className="text-base sm:text-lg font-semibold text-blue-900 mb-3 sm:mb-4">Greeting Guidelines</h3>
              <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm text-blue-800">
                <p className="font-medium text-xs sm:text-sm">
                  A strong greeting sets the tone for their visit and helps us deliver the best experience possible.
                </p>
                
                <div className="space-y-3 sm:space-y-4">
                  <div>
                    <p className="font-semibold text-blue-900 text-xs sm:text-sm">Step 1: Warm & Welcome</p>
                    <p className="text-xs sm:text-sm"><strong>Example:</strong> Smile and wave, "Hi, welcome to Ulrich! What brings you in today?"</p>
                  </div>
                  
                  <div>
                    <p className="font-semibold text-blue-900 text-xs sm:text-sm">Step 2: State Your Role</p>
                    <p className="text-xs sm:text-sm"><strong>Example:</strong> "Hi, I'm [Your Name], and you are? My role is to guide you through the process."</p>
                  </div>
                  
                  <div>
                    <p className="font-semibold text-blue-900 text-xs sm:text-sm">Step 3: Determine the Right Starting Point</p>
                    <p className="text-xs sm:text-sm"><strong>Example:</strong> "Let me show you where to start" or "Let's step over here to get started."</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Sales Representative */}
            <div className="space-y-2 sm:space-y-2">
              <label htmlFor="repEmail" className="flex items-center text-sm font-semibold text-gray-700">
                <UserCheck className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                Sales Representative *
              </label>
              <select
                id="repEmail"
                name="repEmail"
                value={repEmail}
                onChange={handleRepEmailChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                  (validationErrors as any).repEmail ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Select Sales Representative</option>
                {availableUsers.map((user) => (
                  <option key={user.id} value={user.email}>
                    {user.name} ({user.email})
                  </option>
                ))}
              </select>
              {(validationErrors as any).repEmail && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{(validationErrors as any).repEmail}</p>
              )}
              {usersLoaded && availableUsers.length === 0 && (
                <p className="text-amber-600 text-xs sm:text-sm mt-1">
                  No sales representatives configured. Please contact your administrator.
                </p>
              )}
              {!usersLoaded && (
                <p className="text-blue-600 text-xs sm:text-sm mt-1">
                  Loading sales representatives...
                </p>
              )}
            </div>

            {/* Customer Information Section */}
            <div className="space-y-3 sm:space-y-4">
              <h3 className="text-base sm:text-lg font-semibold text-gray-900">
                Customer Information
              </h3>

              {/* First Name */}
              <div className="space-y-2 sm:space-y-2">
                <label htmlFor="firstName" className="flex items-center text-sm font-semibold text-gray-700">
                  <User className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                  First Name {isCustomerLead && '*'}
                </label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  value={customerData.firstName}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                    validationErrors.firstName ? 'border-red-500' : 'border-gray-300'
                  } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                  placeholder="Enter first name"
                  disabled={!isCustomerLead}
                />
                {validationErrors.firstName && (
                  <p className="text-red-500 text-xs sm:text-sm mt-1">{validationErrors.firstName}</p>
                )}
              </div>

              {/* Last Name */}
              <div className="space-y-2 sm:space-y-2">
                <label htmlFor="lastName" className="flex items-center text-sm font-semibold text-gray-700">
                  <User className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                  Last Name {isCustomerLead && '*'}
                </label>
                <input
                  type="text"
                  id="lastName"
                  name="lastName"
                  value={customerData.lastName}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                    validationErrors.lastName ? 'border-red-500' : 'border-gray-300'
                  } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                  placeholder="Enter last name"
                  disabled={!isCustomerLead}
                />
                {validationErrors.lastName && (
                  <p className="text-red-500 text-xs sm:text-sm mt-1">{validationErrors.lastName}</p>
                )}
              </div>

              {/* Email */}
              <div className="space-y-2 sm:space-y-2">
                <label htmlFor="email" className="flex items-center text-sm font-semibold text-gray-700">
                  <Mail className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                  Email Address {isCustomerLead && '*'}
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={customerData.email}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                    validationErrors.email ? 'border-red-500' : 'border-gray-300'
                  } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                  placeholder="customer@example.com"
                  disabled={!isCustomerLead}
                />
                {validationErrors.email && (
                  <p className="text-red-500 text-xs sm:text-sm mt-1">{validationErrors.email}</p>
                )}
              </div>

              {/* Phone Number */}
              <div className="space-y-2 sm:space-y-2">
                <label htmlFor="phoneNumber" className="flex items-center text-sm font-semibold text-gray-700">
                  <Phone className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                  Phone Number {isCustomerLead && '*'}
                </label>
                <input
                  type="tel"
                  id="phoneNumber"
                  name="phoneNumber"
                  value={customerData.phoneNumber}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                    validationErrors.phoneNumber ? 'border-red-500' : 'border-gray-300'
                  } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                  placeholder="(555) 123-4567"
                  disabled={!isCustomerLead}
                />
                {validationErrors.phoneNumber && (
                  <p className="text-red-500 text-xs sm:text-sm mt-1">{validationErrors.phoneNumber}</p>
                )}
              </div>

              {/* Zip Code */}
              <div className="space-y-2 sm:space-y-2">
                <label htmlFor="zipCode" className="flex items-center text-sm font-semibold text-gray-700">
                  <MapPin className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                  Zip Code {isCustomerLead && '*'}
                </label>
                <input
                  type="text"
                  id="zipCode"
                  name="zipCode"
                  value={customerData.zipCode}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                    validationErrors.zipCode ? 'border-red-500' : 'border-gray-300'
                  } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                  placeholder="12345"
                  disabled={!isCustomerLead}
                />
                {validationErrors.zipCode && (
                  <p className="text-red-500 text-xs sm:text-sm mt-1">{validationErrors.zipCode}</p>
                )}
              </div>
            </div>

            {/* Lead Type Selection - Moved to Bottom */}
            <div className="border-t pt-4 sm:pt-6 space-y-3 sm:space-y-4">
              <h3 className="text-base sm:text-lg font-semibold text-gray-900">Lead Classification</h3>
              
              {/* Not a Customer Checkbox */}
              <div className="space-y-2 sm:space-y-2">
                <label className="flex items-center text-sm font-semibold text-gray-700">
                  <input
                    type="checkbox"
                    checked={isNotCustomer}
                    onChange={handleNotCustomerChange}
                    className="mr-3 h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded flex-shrink-0"
                  />
                  Not a customer
                </label>
                <p className="text-xs text-gray-500 ml-8">
                  Check this box if this lead is an employee, vendor, or other non-customer
                </p>
              </div>

              {/* Lead Type Dropdown (only shown when "Not a customer" is checked) */}
              {isNotCustomer && (
                <div className="space-y-2 sm:space-y-2">
                  <label htmlFor="leadType" className="flex items-center text-sm font-semibold text-gray-700">
                    <Users className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                    Lead Type *
                  </label>
                  <select
                    id="leadType"
                    name="leadType"
                    value={leadType}
                    onChange={handleLeadTypeChange}
                    className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                      (validationErrors as any).leadType ? 'border-red-500' : 'border-gray-300'
                    }`}
                    required
                  >
                    <option value="">Select Lead Type</option>
                    <option value="Employee">Employee</option>
                    <option value="Vendor / Other">Vendor / Other</option>
                  </select>
                  {(validationErrors as any).leadType && (
                    <p className="text-red-500 text-xs sm:text-sm mt-1">{(validationErrors as any).leadType}</p>
                  )}
                </div>
              )}

              {/* Customer Lead Type Indicator */}
              {!isNotCustomer && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 sm:p-4">
                  <div className="flex items-center">
                    <Users className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600 mr-2 flex-shrink-0" />
                    <span className="font-medium text-blue-900 text-sm sm:text-base">Lead Type: Customer</span>
                  </div>
                  <p className="text-xs sm:text-sm text-blue-700 mt-1">
                    All customer information fields above are required
                  </p>
                </div>
              )}

              {/* Non-Customer Information */}
              {isNotCustomer && leadType && (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 sm:p-4">
                  <div className="flex items-center">
                    <Users className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600 mr-2 flex-shrink-0" />
                    <span className="font-medium text-gray-900 text-sm sm:text-base">Lead Type: {leadType}</span>
                  </div>
                  <p className="text-xs sm:text-sm text-gray-600 mt-1">
                    Customer information above is optional for {leadType === 'Vendor / Other' ? 'vendor/other' : leadType.toLowerCase()} leads
                  </p>
                </div>
              )}
            </div>

            {/* Notes Field - Always shown at bottom */}
            <div className="space-y-2 sm:space-y-2">
              <label htmlFor="notes" className="flex items-center text-sm font-semibold text-gray-700">
                <FileText className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                Notes {isNotCustomer ? '*' : ''}
              </label>
              <textarea
                id="notes"
                name="notes"
                value={customerData.notes || ''}
                onChange={(e) => setCustomerData(prev => ({ ...prev, notes: e.target.value }))}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-y min-h-[48px] text-base ${
                  validationErrors.notes ? 'border-red-500' : 'border-gray-300'
                }`}
                rows={2}
                placeholder={
                  isNotCustomer
                    ? "Please provide details about this lead (required for non-customer leads)"
                    : "Optional notes about this lead or customer interaction"
                }
              />
              {validationErrors.notes && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{validationErrors.notes}</p>
              )}
              {isNotCustomer && (
                <p className="text-xs sm:text-sm text-blue-600">
                  Notes are required for non-customer leads
                </p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 px-6 rounded-lg font-semibold hover:from-green-700 hover:to-emerald-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-base min-h-[52px]"
            >
              {isSubmitting ? (
                <span className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-4 w-4 sm:h-5 sm:w-5 border-b-2 border-white mr-2"></div>
                  Submitting Lead...
                </span>
              ) : (
                'Complete & Submit Lead'
              )}
            </button>
            {sessionStorage.getItem('salesRepEmail') && (
              <p className="text-xs sm:text-sm text-blue-600 mt-1">
                Auto-selected: You are logged in as {sessionStorage.getItem('salesRepName')}
              </p>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default LeadCompletion;