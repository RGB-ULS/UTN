import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Save, X, Bell, Clock, Users, MessageSquare, Phone, Mail, Webhook, AlertCircle, Check, Copy, TestTube } from 'lucide-react';
import { NotificationRule, NotificationLayer, NotificationRecipient, StoredLead } from '../types';
import { 
  getNotificationRules, 
  saveNotificationRule, 
  deleteNotificationRule, 
  generateId,
  getNotificationLogs,
  clearNotificationLogs,
  clearNotificationTracking,
  processCustomNotifications
} from '../utils/customNotifications';
import { getAllLeads } from '../utils/storage';

const CustomNotifications: React.FC = () => {
  const [rules, setRules] = useState<NotificationRule[]>([]);
  const [editingRule, setEditingRule] = useState<NotificationRule | null>(null);
  const [showRuleForm, setShowRuleForm] = useState(false);
  const [availableStores, setAvailableStores] = useState<string[]>([]);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Form state
  const [formRule, setFormRule] = useState<NotificationRule>({
    id: '',
    name: '',
    enabled: true,
    layers: [],
    createdAt: '',
    updatedAt: ''
  });

  useEffect(() => {
    loadRules();
    loadStores();
  }, []);

  const loadRules = () => {
    const loadedRules = getNotificationRules();
    setRules(loadedRules);
  };

  const loadStores = async () => {
    try {
      const leads = await getAllLeads();
      const stores = Array.from(new Set(leads.map(lead => lead.data.store).filter(Boolean))).sort();
      setAvailableStores(stores);
    } catch (error) {
      console.error('Error loading stores:', error);
    }
  };

  const handleNewRule = () => {
    setFormRule({
      id: generateId(),
      name: '',
      enabled: true,
      layers: [{
        id: generateId(),
        delayMinutes: 0,
        recipients: [],
        message: '🚗 New lead at {store} - License: {licensePlate} - {ageMinutes} minutes old. Complete: {completionLink}',
        conditions: {}
      }],
      createdAt: '',
      updatedAt: ''
    });
    setEditingRule(null);
    setShowRuleForm(true);
  };

  const handleEditRule = (rule: NotificationRule) => {
    setFormRule({ ...rule });
    setEditingRule(rule);
    setShowRuleForm(true);
  };

  const handleSaveRule = () => {
    if (!formRule.name.trim()) {
      alert('Please enter a rule name');
      return;
    }

    if (formRule.layers.length === 0) {
      alert('Please add at least one notification layer');
      return;
    }

    // Validate layers
    for (const layer of formRule.layers) {
      if (layer.recipients.length === 0) {
        alert('Each layer must have at least one recipient');
        return;
      }
      if (!layer.message.trim()) {
        alert('Each layer must have a message');
        return;
      }
    }

    saveNotificationRule(formRule);
    loadRules();
    setShowRuleForm(false);
    setFormRule({
      id: '',
      name: '',
      enabled: true,
      layers: [],
      createdAt: '',
      updatedAt: ''
    });
  };

  const handleDeleteRule = (ruleId: string) => {
    if (window.confirm('Are you sure you want to delete this notification rule?')) {
      deleteNotificationRule(ruleId);
      loadRules();
    }
  };

  const handleToggleRule = (ruleId: string) => {
    const rule = rules.find(r => r.id === ruleId);
    if (rule) {
      const updatedRule = { ...rule, enabled: !rule.enabled };
      saveNotificationRule(updatedRule);
      loadRules();
    }
  };

  const handleAddLayer = () => {
    const newLayer: NotificationLayer = {
      id: generateId(),
      delayMinutes: Math.max(...formRule.layers.map(l => l.delayMinutes), 0) + 15,
      recipients: [],
      message: '⚠️ Lead at {store} still pending after {ageMinutes} minutes - License: {licensePlate}. Complete: {completionLink}',
      conditions: {}
    };

    setFormRule({
      ...formRule,
      layers: [...formRule.layers, newLayer]
    });
  };

  const handleRemoveLayer = (layerId: string) => {
    setFormRule({
      ...formRule,
      layers: formRule.layers.filter(l => l.id !== layerId)
    });
  };

  const handleUpdateLayer = (layerId: string, updates: Partial<NotificationLayer>) => {
    setFormRule({
      ...formRule,
      layers: formRule.layers.map(layer => 
        layer.id === layerId ? { ...layer, ...updates } : layer
      )
    });
  };

  const handleAddRecipient = (layerId: string) => {
    const newRecipient: NotificationRecipient = {
      type: 'phone',
      value: '',
      name: ''
    };

    handleUpdateLayer(layerId, {
      recipients: [...(formRule.layers.find(l => l.id === layerId)?.recipients || []), newRecipient]
    });
  };

  const handleUpdateRecipient = (layerId: string, recipientIndex: number, updates: Partial<NotificationRecipient>) => {
    const layer = formRule.layers.find(l => l.id === layerId);
    if (layer) {
      const updatedRecipients = layer.recipients.map((recipient, index) =>
        index === recipientIndex ? { ...recipient, ...updates } : recipient
      );
      handleUpdateLayer(layerId, { recipients: updatedRecipients });
    }
  };

  const handleRemoveRecipient = (layerId: string, recipientIndex: number) => {
    const layer = formRule.layers.find(l => l.id === layerId);
    if (layer) {
      const updatedRecipients = layer.recipients.filter((_, index) => index !== recipientIndex);
      handleUpdateLayer(layerId, { recipients: updatedRecipients });
    }
  };

  const handleTestNotifications = async () => {
    setIsProcessing(true);
    setTestResult(null);

    try {
      const leads = await getAllLeads();
      const incompleteLeads = leads.filter(lead => !lead.completed);
      
      console.log(`Testing notifications for ${incompleteLeads.length} incomplete leads`);
      await processCustomNotifications(incompleteLeads);
      
      setTestResult({
        success: true,
        message: `Processed notifications for ${incompleteLeads.length} leads. Check logs for details.`
      });
    } catch (error) {
      console.error('Error testing notifications:', error);
      setTestResult({
        success: false,
        message: `Error testing notifications: ${error.message}`
      });
    } finally {
      setIsProcessing(false);
      setTimeout(() => setTestResult(null), 5000);
    }
  };

  const handleClearTracking = () => {
    if (window.confirm('This will allow all notifications to be sent again. Are you sure?')) {
      clearNotificationTracking();
      setTestResult({
        success: true,
        message: 'Notification tracking cleared. All notifications can be sent again.'
      });
      setTimeout(() => setTestResult(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <MessageSquare className="w-6 h-6 text-blue-600 mr-3" />
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Custom Text Notifications</h2>
                <p className="text-sm text-gray-600 mt-1">
                  Set up multi-layered SMS notifications based on lead age and conditions
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleTestNotifications}
                disabled={isProcessing}
                className="bg-orange-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 transition-all duration-200 flex items-center disabled:opacity-50"
              >
                {isProcessing ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <TestTube className="w-4 h-4 mr-2" />
                )}
                Test All Rules
              </button>
              <button
                onClick={handleClearTracking}
                className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
              >
                <X className="w-4 h-4 mr-2" />
                Clear Tracking
              </button>
              <button
                onClick={handleNewRule}
                className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Rule
              </button>
            </div>
          </div>
        </div>

        {/* Test Result */}
        {testResult && (
          <div className={`p-4 ${
            testResult.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
          } border-l-4`}>
            <div className="flex items-center">
              {testResult.success ? (
                <Check className="w-5 h-5 text-green-600 mr-2" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
              )}
              <span className={`text-sm font-medium ${
                testResult.success ? 'text-green-800' : 'text-red-800'
              }`}>
                {testResult.message}
              </span>
            </div>
          </div>
        )}

        {/* Rules List */}
        <div className="p-6">
          {rules.length === 0 ? (
            <div className="text-center py-12">
              <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Notification Rules</h3>
              <p className="text-gray-600 mb-4">Create your first notification rule to get started.</p>
              <button
                onClick={handleNewRule}
                className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
              >
                Create First Rule
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {rules.map((rule) => (
                <div key={rule.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-3 ${rule.enabled ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                      <h3 className="text-lg font-semibold text-gray-900">{rule.name}</h3>
                      <span className="ml-2 px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                        {rule.layers.length} layer{rule.layers.length !== 1 ? 's' : ''}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleToggleRule(rule.id)}
                        className={`px-3 py-1 text-xs font-medium rounded-full ${
                          rule.enabled 
                            ? 'bg-green-100 text-green-800 hover:bg-green-200' 
                            : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                        }`}
                      >
                        {rule.enabled ? 'Enabled' : 'Disabled'}
                      </button>
                      <button
                        onClick={() => handleEditRule(rule)}
                        className="text-blue-600 hover:text-blue-700 p-1"
                        title="Edit rule"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteRule(rule.id)}
                        className="text-red-600 hover:text-red-700 p-1"
                        title="Delete rule"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {rule.layers.map((layer, index) => (
                      <div key={layer.id} className="bg-gray-50 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 text-gray-500 mr-2" />
                            <span className="text-sm font-medium text-gray-700">
                              Layer {index + 1}: After {layer.delayMinutes} minutes
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Users className="w-4 h-4 text-gray-500 mr-1" />
                            <span className="text-sm text-gray-600">
                              {layer.recipients.length} recipient{layer.recipients.length !== 1 ? 's' : ''}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 truncate">{layer.message}</p>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-3 text-xs text-gray-500">
                    Created: {new Date(rule.createdAt).toLocaleString()}
                    {rule.updatedAt !== rule.createdAt && (
                      <span> • Updated: {new Date(rule.updatedAt).toLocaleString()}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Rule Form Modal */}
      {showRuleForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">
                  {editingRule ? 'Edit Notification Rule' : 'Create Notification Rule'}
                </h3>
                <button
                  onClick={() => setShowRuleForm(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Rule Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Rule Name *
                </label>
                <input
                  type="text"
                  value={formRule.name}
                  onChange={(e) => setFormRule({ ...formRule, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Escalating Lead Notifications"
                />
              </div>

              {/* Enabled Toggle */}
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="enabled"
                  checked={formRule.enabled}
                  onChange={(e) => setFormRule({ ...formRule, enabled: e.target.checked })}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="enabled" className="ml-2 text-sm font-medium text-gray-700">
                  Enable this rule
                </label>
              </div>

              {/* Notification Layers */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-gray-900">Notification Layers</h4>
                  <button
                    onClick={handleAddLayer}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Layer
                  </button>
                </div>

                {formRule.layers.map((layer, layerIndex) => (
                  <div key={layer.id} className="border border-gray-200 rounded-lg p-4 mb-4">
                    <div className="flex items-center justify-between mb-4">
                      <h5 className="text-md font-semibold text-gray-800">
                        Layer {layerIndex + 1}
                      </h5>
                      {formRule.layers.length > 1 && (
                        <button
                          onClick={() => handleRemoveLayer(layer.id)}
                          className="text-red-600 hover:text-red-700 p-1"
                          title="Remove layer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Delay Minutes */}
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Send after (minutes) *
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={layer.delayMinutes}
                        onChange={(e) => handleUpdateLayer(layer.id, { delayMinutes: parseInt(e.target.value) || 0 })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        0 = immediately, 15 = after 15 minutes, etc.
                      </p>
                    </div>

                    {/* Message */}
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Message Template *
                      </label>
                      <textarea
                        value={layer.message}
                        onChange={(e) => handleUpdateLayer(layer.id, { message: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={3}
                        placeholder="Your message here..."
                      />
                      <div className="text-xs text-gray-500 mt-1">
                        Available placeholders: {'{licensePlate}'}, {'{store}'}, {'{leadType}'}, {'{time}'}, {'{ageMinutes}'}, {'{completionLink}'}
                      </div>
                    </div>

                    {/* Recipients */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Recipients *
                        </label>
                        <button
                          onClick={() => handleAddRecipient(layer.id)}
                          className="bg-green-600 text-white py-1 px-3 rounded text-sm font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
                        >
                          <Plus className="w-3 h-3 mr-1" />
                          Add Recipient
                        </button>
                      </div>

                      {layer.recipients.map((recipient, recipientIndex) => (
                        <div key={recipientIndex} className="flex items-center space-x-2 mb-2">
                          <select
                            value={recipient.type}
                            onChange={(e) => handleUpdateRecipient(layer.id, recipientIndex, { type: e.target.value as any })}
                            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          >
                            <option value="phone">Phone</option>
                            <option value="email">Email</option>
                            <option value="webhook">Webhook</option>
                          </select>
                          <input
                            type="text"
                            value={recipient.value}
                            onChange={(e) => handleUpdateRecipient(layer.id, recipientIndex, { value: e.target.value })}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder={
                              recipient.type === 'phone' ? '+1234567890' :
                              recipient.type === 'email' ? 'user@example.com' :
                              'https://webhook.url'
                            }
                          />
                          <input
                            type="text"
                            value={recipient.name || ''}
                            onChange={(e) => handleUpdateRecipient(layer.id, recipientIndex, { name: e.target.value })}
                            className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="Name (optional)"
                          />
                          <button
                            onClick={() => handleRemoveRecipient(layer.id, recipientIndex)}
                            className="text-red-600 hover:text-red-700 p-1"
                            title="Remove recipient"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}

                      {layer.recipients.length === 0 && (
                        <p className="text-sm text-gray-500 italic">No recipients added yet</p>
                      )}
                    </div>

                    {/* Conditions */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Conditions (optional)
                      </label>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs text-gray-600 mb-1">Stores</label>
                          <select
                            multiple
                            value={layer.conditions?.stores || []}
                            onChange={(e) => {
                              const stores = Array.from(e.target.selectedOptions, option => option.value);
                              handleUpdateLayer(layer.id, { 
                                conditions: { ...layer.conditions, stores } 
                              });
                            }}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            size={3}
                          >
                            {availableStores.map(store => (
                              <option key={store} value={store}>{store}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs text-gray-600 mb-1">Lead Types</label>
                          <select
                            multiple
                            value={layer.conditions?.leadTypes || []}
                            onChange={(e) => {
                              const leadTypes = Array.from(e.target.selectedOptions, option => option.value);
                              handleUpdateLayer(layer.id, { 
                                conditions: { ...layer.conditions, leadTypes } 
                              });
                            }}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            size={3}
                          >
                            <option value="Customer">Customer</option>
                            <option value="Employee">Employee</option>
                            <option value="Vendor / Other">Vendor / Other</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs text-gray-600 mb-1">Markets</label>
                          <select
                            multiple
                            value={layer.conditions?.markets || []}
                            onChange={(e) => {
                              const markets = Array.from(e.target.selectedOptions, option => option.value);
                              handleUpdateLayer(layer.id, { 
                                conditions: { ...layer.conditions, markets } 
                              });
                            }}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            size={3}
                          >
                            <option value="California">California</option>
                            <option value="Texas">Texas</option>
                            <option value="Virginia">Virginia</option>
                            <option value="Other">Other</option>
                          </select>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Leave empty to apply to all. Hold Ctrl/Cmd to select multiple.
                      </p>
                    </div>
                  </div>
                ))}

                {formRule.layers.length === 0 && (
                  <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                    <Bell className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-gray-500">No notification layers yet</p>
                    <button
                      onClick={handleAddLayer}
                      className="mt-2 bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
                    >
                      Add First Layer
                    </button>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-4 border-t">
                <button
                  onClick={handleSaveRule}
                  className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Rule
                </button>
                <button
                  onClick={() => setShowRuleForm(false)}
                  className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* How It Works */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-4">How Custom Notifications Work</h3>
        <div className="space-y-3 text-sm text-blue-800">
          <div className="flex items-start">
            <div className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
              <span className="text-xs font-bold text-blue-800">1</span>
            </div>
            <div>
              <strong>Create Rules:</strong> Set up notification rules with multiple layers for escalation
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
              <span className="text-xs font-bold text-blue-800">2</span>
            </div>
            <div>
              <strong>Set Timing:</strong> Each layer triggers after a specific number of minutes (0 = immediately)
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
              <span className="text-xs font-bold text-blue-800">3</span>
            </div>
            <div>
              <strong>Add Recipients:</strong> Phone numbers, emails, or webhooks for each layer
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
              <span className="text-xs font-bold text-blue-800">4</span>
            </div>
            <div>
              <strong>Set Conditions:</strong> Filter by stores, lead types, or markets (optional)
            </div>
          </div>
          <div className="flex items-start">
            <div className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
              <span className="text-xs font-bold text-blue-800">5</span>
            </div>
            <div>
              <strong>Automatic Processing:</strong> System checks every few minutes and sends notifications
            </div>
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-blue-100 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Example:</strong> Layer 1 sends immediately to store manager, Layer 2 sends after 15 minutes to regional manager, Layer 3 sends after 45 minutes to district manager.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CustomNotifications;