import React, { useState } from 'react';
import { MessageSquare, Send, TestTube, Check, X, AlertCircle, Phone, Clock, MapPin, Hash, RefreshCw } from 'lucide-react';
import { sendTestSMS } from '../services/aloware';
import { getAllLeads } from '../utils/storage';
import { StoredLead } from '../types';

const AlowareSMSTest: React.FC = () => {
  const [availableLeads, setAvailableLeads] = useState<StoredLead[]>([]);
  const [selectedLead, setSelectedLead] = useState<StoredLead | null>(null);
  const [loadingLeads, setLoadingLeads] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
    error?: string;
    leadData?: any;
  } | null>(null);

  const loadLeads = async () => {
    setLoadingLeads(true);
    try {
      const leads = await getAllLeads();
      // Filter to show recent leads (last 7 days) for testing
      const recentLeads = leads.filter(lead => {
        const leadDate = new Date(lead.createdAt);
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return leadDate >= weekAgo;
      }).slice(0, 10); // Limit to 10 most recent
      
      setAvailableLeads(recentLeads);
      if (recentLeads.length > 0 && !selectedLead) {
        setSelectedLead(recentLeads[0]); // Auto-select first lead
      }
    } catch (error) {
      console.error('Error loading leads:', error);
    } finally {
      setLoadingLeads(false);
    }
  };

  React.useEffect(() => {
    loadLeads();
  }, []);

  const handleSendTestSMS = async () => {
    setIsSending(true);
    setTestResult(null);

    try {
      console.log('🧪 Starting Aloware SMS test...');
      const result = await sendTestSMS(selectedLead);
      setTestResult(result);
      
      if (result.success) {
        console.log('✅ Test SMS sent successfully');
      } else {
        console.error('❌ Test SMS failed:', result.error);
      }
    } catch (error) {
      console.error('🚨 Test SMS error:', error);
      setTestResult({
        success: false,
        message: 'Failed to send test SMS',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      setIsSending(false);
    }
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center">
            <MessageSquare className="w-6 h-6 text-blue-600 mr-3" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Aloware SMS Integration</h2>
              <p className="text-sm text-gray-600 mt-1">
                Test SMS notifications and manage SMS settings
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Configuration Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-blue-900 mb-2">📱 Current Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium text-blue-800">Line ID:</span>
                <span className="text-blue-700 ml-2">8964</span>
              </div>
              <div>
                <span className="font-medium text-blue-800">Test Number:</span>
                <span className="text-blue-700 ml-2">940-765-5834</span>
              </div>
              <div>
                <span className="font-medium text-blue-800">API Status:</span>
                <span className="text-blue-700 ml-2">Ready</span>
              </div>
              <div>
                <span className="font-medium text-blue-800">Message Limit:</span>
                <span className="text-blue-700 ml-2">160 characters</span>
              </div>
            </div>
          </div>

          {/* Lead Selection */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Select Real Lead for Testing</h3>
              <button
                onClick={loadLeads}
                disabled={loadingLeads}
                className="bg-blue-600 text-white py-2 px-3 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 flex items-center text-sm"
              >
                {loadingLeads ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Refresh Leads
              </button>
            </div>

            {availableLeads.length === 0 ? (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800 text-sm">
                  No recent leads found. The system will use sample test data instead.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Choose a lead to test with:
                  </label>
                  <select
                    value={selectedLead?.id || ''}
                    onChange={(e) => {
                      const lead = availableLeads.find(l => l.id === e.target.value);
                      setSelectedLead(lead || null);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {availableLeads.map(lead => (
                      <option key={lead.id} value={lead.id}>
                        {lead.data.licensePlate || 'No License'} - {lead.data.store || 'No Store'} - {formatTimestamp(lead.createdAt)}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedLead && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-blue-900 mb-2">Selected Lead Details:</h4>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div><strong>License:</strong> {selectedLead.data.licensePlate || 'N/A'}</div>
                      <div><strong>Store:</strong> {selectedLead.data.store || 'N/A'}</div>
                        💡 <strong>Note:</strong> {selectedLead ? 'This uses real lead data. The completion link will work and lead to the actual lead completion form.' : 'This is sample test data. The completion link will work but won\'t find an actual lead in the system.'}
                      <div><strong>Status:</strong> {selectedLead.completed ? 'Completed' : 'Pending'}</div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Test Section */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">SMS Test</h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Test Message Preview:</h4>
              <div className="bg-white border border-gray-300 rounded-lg p-3">
                <p className="text-sm text-gray-800 font-mono">
                  🚗 New lead at {selectedLead?.data.store || 'Downtown Branch'} - License: {selectedLead?.data.licensePlate || 'TEST123'} - Time: {selectedLead?.data.time ? formatTimestamp(selectedLead.data.time) : new Date().toLocaleString()}. Complete: {window.location.origin}/complete-lead/{selectedLead?.id || 'test_lead_[timestamp]'}
                </p>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                {selectedLead 
                  ? `This test will send an SMS using the REAL lead data. The completion link will work and take you directly to complete this actual lead: ${selectedLead.id}`
                  : `This test will create sample lead data since no real leads are available.`
                }
              </p>
            </div>

            <button
              onClick={handleSendTestSMS}
              disabled={isSending}
              className="bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {isSending ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Sending Test SMS...
                </>
              ) : (
                <>
                  <TestTube className="w-5 h-5 mr-2" />
                  Send Test SMS
                </>
              )}
            </button>
          </div>

          {/* Test Results */}
          {testResult && (
            <div className={`p-4 rounded-lg border ${
              testResult.success 
                ? 'bg-green-50 border-green-200' 
                : 'bg-red-50 border-red-200'
            }`}>
              <div className="flex items-center mb-3">
                {testResult.success ? (
                  <Check className="w-5 h-5 text-green-600 mr-2" />
                ) : (
                  <X className="w-5 h-5 text-red-600 mr-2" />
                )}
                <span className={`font-medium ${
                  testResult.success ? 'text-green-800' : 'text-red-800'
                }`}>
                  {testResult.success ? 'SMS Sent Successfully!' : 'SMS Failed'}
                </span>
              </div>
              
              <p className={`text-sm mb-3 ${
                testResult.success ? 'text-green-700' : 'text-red-700'
              }`}>
                {testResult.message}
              </p>

              {testResult.error && (
                <div className="bg-red-100 border border-red-300 rounded p-3 mb-3">
                  <p className="text-sm text-red-800">
                    <strong>Error Details:</strong> {testResult.error}
                  </p>
                </div>
              )}

              {testResult.success && testResult.leadData && (
                <div className="bg-white border border-green-300 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-green-900 mb-3">📋 Test Lead Data Created:</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center">
                      <Hash className="w-4 h-4 text-green-600 mr-2" />
                      <span className="font-medium text-green-800">Lead ID:</span>
                      <span className="text-green-700 ml-2 font-mono text-xs">{testResult.leadData.id}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 text-green-600 mr-2" />
                      <span className="font-medium text-green-800">License:</span>
                      <span className="text-green-700 ml-2">{testResult.leadData.licensePlate}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 text-green-600 mr-2" />
                      <span className="font-medium text-green-800">Store:</span>
                      <span className="text-green-700 ml-2">{testResult.leadData.store}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 text-green-600 mr-2" />
                      <span className="font-medium text-green-800">Time:</span>
                      <span className="text-green-700 ml-2">{testResult.leadData.time}</span>
                    </div>
                  </div>
                  
                  <div className="mt-3 pt-3 border-t border-green-200">
                    <p className="text-xs text-green-600">
                      💡 <strong>Note:</strong> {testResult.leadData.id.startsWith('test_lead_') 
                        ? 'This is test data only. The completion link will work but won\'t find an actual lead in the system.'
                        : 'This uses REAL lead data. The completion link will work and take you directly to complete this actual lead in the system.'
                      }
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Integration Info */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-yellow-900 mb-2">🔧 Integration Details</h3>
            <div className="text-sm text-yellow-800 space-y-2">
              <p><strong>API Endpoint:</strong> https://app.aloware.com/api/v1/webhook/sms-gateway/send</p>
              <p><strong>Authentication:</strong> API Token (configured)</p>
              <p><strong>Message Format:</strong> Lead details + completion link</p>
              <p><strong>Custom Fields:</strong> License plate, store, and lead ID are included</p>
              <p><strong>User Context:</strong> Messages sent as company (-1)</p>
              <p><strong>Lead Source:</strong> {availableLeads.length > 0 ? `Using real leads from database (${availableLeads.length} available)` : 'Using sample test data (no recent leads found)'}</p>
            </div>
          </div>

          {/* Future Features */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-purple-900 mb-2">🚀 Future SMS Features</h3>
            <ul className="text-sm text-purple-800 space-y-1">
              <li>• Automatic SMS notifications for overdue leads</li>
              <li>• SMS notifications when new leads arrive</li>
              <li>• Customizable message templates</li>
              <li>• Multiple phone number support</li>
              <li>• SMS delivery status tracking</li>
              <li>• Integration with webhook notifications</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AlowareSMSTest;