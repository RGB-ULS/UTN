import React, { useState, useEffect } from 'react';
import { MapPin, Send, Users, Phone, Bell, Check, X, AlertCircle, TestTube } from 'lucide-react';
import { getUsersByStore, getStoresFromUsers } from '../utils/userManagement';
import { sendLeadNotificationSMS } from '../services/aloware';
import { getAllLeads } from '../utils/storage';
import { User, StoredLead } from '../types';

const StoreNotifications: React.FC = () => {
  const [availableStores, setAvailableStores] = useState<string[]>([]);
  const [selectedStore, setSelectedStore] = useState<string>('');
  const [storeUsers, setStoreUsers] = useState<User[]>([]);
  const [customMessage, setCustomMessage] = useState('🚗 New lead notification from {store}. Please check your dashboard for pending leads.');
  const [isSending, setIsSending] = useState(false);
  const [sendResults, setSendResults] = useState<{
    success: { user: User; message: string }[];
    errors: { user: User; error: string }[];
  } | null>(null);
  const [recentLeads, setRecentLeads] = useState<StoredLead[]>([]);
  const [selectedLead, setSelectedLead] = useState<StoredLead | null>(null);

  useEffect(() => {
    loadStores();
    loadRecentLeads();
  }, []);

  useEffect(() => {
    if (selectedStore) {
      loadStoreUsers();
    } else {
      setStoreUsers([]);
    }
  }, [selectedStore]);

  const loadStores = async () => {
    try {
      // Get stores from user assignments
      const userStores = await getStoresFromUsers();
      
      // Get stores from recent leads
      const leads = await getAllLeads();
      const leadStores = Array.from(new Set(leads.map(lead => lead.data.store).filter(Boolean)));
      
      // Combine and deduplicate
      const allStores = Array.from(new Set([...userStores, ...leadStores])).sort();
      setAvailableStores(allStores);
    } catch (error) {
      console.error('Error loading stores:', error);
    }
  };

  const loadStoreUsers = async () => {
    try {
      const users = await getUsersByStore(selectedStore);
      setStoreUsers(users);
    } catch (error) {
      console.error('Error loading store users:', error);
      setStoreUsers([]);
    }
  };

  const loadRecentLeads = async () => {
    try {
      const leads = await getAllLeads();
      // Get recent incomplete leads from the last 24 hours
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const recent = leads
        .filter(lead => !lead.completed && new Date(lead.createdAt) > oneDayAgo)
        .slice(0, 10);
      setRecentLeads(recent);
    } catch (error) {
      console.error('Error loading recent leads:', error);
    }
  };

  const handleSendNotifications = async () => {
    if (!selectedStore || storeUsers.length === 0) {
      return;
    }

    setIsSending(true);
    setSendResults(null);

    const results = {
      success: [] as { user: User; message: string }[],
      errors: [] as { user: User; error: string }[]
    };

    // Prepare message with store placeholder
    const message = customMessage.replace('{store}', selectedStore);

    for (const user of storeUsers) {
      try {
        console.log(`Sending notification to ${user.name} (${user.phone_number})`);
        
        const result = await sendLeadNotificationSMS(user.phone_number!, {
          id: 'store_notification',
          licensePlate: 'STORE_ALERT',
          store: selectedStore,
          time: new Date().toISOString()
        });

        if (result.success) {
          results.success.push({ user, message: result.message });
        } else {
          results.errors.push({ user, error: result.error || 'Unknown error' });
        }

        // Add delay between messages
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        results.errors.push({ user, error: error.message });
      }
    }

    setSendResults(results);
    setIsSending(false);

    // Clear results after 10 seconds
    setTimeout(() => setSendResults(null), 10000);
  };

  const handleSendLeadSpecificNotification = async (lead: StoredLead) => {
    if (!selectedStore || storeUsers.length === 0) {
      return;
    }

    setIsSending(true);
    setSendResults(null);

    const results = {
      success: [] as { user: User; message: string }[],
      errors: [] as { user: User; error: string }[]
    };

    // Create lead-specific message
    const completionLink = `${window.location.origin}/complete-lead/${lead.id}`;
    const leadMessage = `🚗 Lead at ${lead.data.store} - License: ${lead.data.licensePlate} - ${Math.floor((Date.now() - new Date(lead.createdAt).getTime()) / (1000 * 60))} minutes old. Complete: ${completionLink}`;

    for (const user of storeUsers) {
      try {
        const result = await sendLeadNotificationSMS(user.phone_number!, {
          id: lead.id,
          licensePlate: lead.data.licensePlate || '',
          store: lead.data.store || '',
          time: lead.data.time || lead.createdAt
        });

        if (result.success) {
          results.success.push({ user, message: result.message });
        } else {
          results.errors.push({ user, error: result.error || 'Unknown error' });
        }

        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        results.errors.push({ user, error: error.message });
      }
    }

    setSendResults(results);
    setIsSending(false);
    setTimeout(() => setSendResults(null), 10000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center">
            <MapPin className="w-6 h-6 text-blue-600 mr-3" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Store-Based Notifications</h2>
              <p className="text-sm text-gray-600 mt-1">
                Send SMS notifications to all users assigned to a specific store
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Store Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Store
            </label>
            <select
              value={selectedStore}
              onChange={(e) => setSelectedStore(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Choose a store...</option>
              {availableStores.map(store => (
                <option key={store} value={store}>{store}</option>
              ))}
            </select>
          </div>

          {/* Store Users Display */}
          {selectedStore && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Users Assigned to {selectedStore}
              </h3>
              
              {storeUsers.length === 0 ? (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <AlertCircle className="w-5 h-5 text-yellow-600 mr-2" />
                    <span className="text-yellow-800 font-medium">No users assigned to this store</span>
                  </div>
                  <p className="text-yellow-700 text-sm mt-2">
                    To send notifications to this store, you need to:
                  </p>
                  <ul className="text-yellow-700 text-sm mt-1 list-disc list-inside">
                    <li>Add users in User Management</li>
                    <li>Assign them phone numbers</li>
                    <li>Assign them to this store</li>
                  </ul>
                </div>
              ) : (
                <div className="space-y-3">
                  {storeUsers.map(user => (
                    <div key={user.id} className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium text-blue-900">{user.name}</div>
                          <div className="text-sm text-blue-700">{user.email}</div>
                          <div className="text-sm text-blue-600">📱 {user.phone_number}</div>
                        </div>
                        <div className="text-xs text-blue-600">
                          Stores: {user.assigned_stores?.join(', ')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Custom Message */}
          {selectedStore && storeUsers.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Custom Message
              </label>
              <textarea
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={3}
                placeholder="Enter your custom message..."
              />
              <p className="text-xs text-gray-500 mt-1">
                Use {'{store}'} as a placeholder for the store name
              </p>
              
              {/* Message Preview */}
              <div className="mt-3 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                <p className="text-xs text-gray-600 mb-1">Message Preview:</p>
                <p className="text-sm text-gray-800 font-mono">
                  {customMessage.replace('{store}', selectedStore)}
                </p>
              </div>
            </div>
          )}

          {/* Send Button */}
          {selectedStore && storeUsers.length > 0 && (
            <div>
              <button
                onClick={handleSendNotifications}
                disabled={isSending || !customMessage.trim()}
                className="w-full bg-green-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isSending ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Sending to {storeUsers.length} users...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Send to All {storeUsers.length} Users
                  </>
                )}
              </button>
            </div>
          )}

          {/* Send Results */}
          {sendResults && (
            <div className="space-y-4">
              {sendResults.success.length > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <Check className="w-5 h-5 text-green-600 mr-2" />
                    <span className="font-medium text-green-800">
                      Successfully sent to {sendResults.success.length} users
                    </span>
                  </div>
                  <div className="space-y-2">
                    {sendResults.success.map(({ user, message }, index) => (
                      <div key={index} className="text-sm text-green-700">
                        ✅ {user.name} ({user.phone_number})
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {sendResults.errors.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <X className="w-5 h-5 text-red-600 mr-2" />
                    <span className="font-medium text-red-800">
                      Failed to send to {sendResults.errors.length} users
                    </span>
                  </div>
                  <div className="space-y-2">
                    {sendResults.errors.map(({ user, error }, index) => (
                      <div key={index} className="text-sm text-red-700">
                        ❌ {user.name} ({user.phone_number}): {error}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Recent Leads for Quick Notifications */}
          {selectedStore && storeUsers.length > 0 && recentLeads.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Quick Send for Recent Leads
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Send notifications about specific recent leads to all users at {selectedStore}
              </p>
              
              <div className="space-y-3">
                {recentLeads
                  .filter(lead => lead.data.store === selectedStore)
                  .map(lead => {
                    const ageMinutes = Math.floor((Date.now() - new Date(lead.createdAt).getTime()) / (1000 * 60));
                    return (
                      <div key={lead.id} className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium text-gray-900">
                              License: {lead.data.licensePlate || 'N/A'}
                            </div>
                            <div className="text-sm text-gray-600">
                              {ageMinutes} minutes old • {new Date(lead.createdAt).toLocaleString()}
                            </div>
                          </div>
                          <button
                            onClick={() => handleSendLeadSpecificNotification(lead)}
                            disabled={isSending}
                            className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 flex items-center"
                          >
                            <Bell className="w-4 h-4 mr-2" />
                            Notify All
                          </button>
                        </div>
                      </div>
                    );
                  })}
                
                {recentLeads.filter(lead => lead.data.store === selectedStore).length === 0 && (
                  <div className="text-center py-4 text-gray-500">
                    No recent leads for {selectedStore}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* How It Works */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-900 mb-2">How Store Notifications Work</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Select a store from the dropdown</li>
              <li>• System shows all users assigned to that store with phone numbers</li>
              <li>• Customize your message (use {'{store}'} placeholder)</li>
              <li>• Send to all users at once or send about specific recent leads</li>
              <li>• View delivery status for each user</li>
            </ul>
          </div>

          {/* Setup Instructions */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-yellow-900 mb-2">Setup Requirements</h3>
            <ul className="text-sm text-yellow-800 space-y-1">
              <li>• Users must have phone numbers added in User Management</li>
              <li>• Users must be assigned to specific stores</li>
              <li>• Users must be active to receive notifications</li>
              <li>• Aloware SMS integration must be configured</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoreNotifications;