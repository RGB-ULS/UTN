import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, MapPin, Clock, Users, User, Mail, Phone, Send, Copy, Check, ExternalLink, UserCheck, FileText } from 'lucide-react';
import { LeadData, CustomerData, FormSubmission } from '../types';
import { validateEmail, validatePhoneNumber, formatPhoneNumber, validateZipCode } from '../utils/validation';
import { submitToGoogleSheets } from '../services/googleSheets';
import { storeLead, generateShareableLink } from '../utils/storage';
import { getGoogleDriveImageUrls } from '../utils/imageUtils';
import { getActiveUsers } from '../utils/userManagement';

const MainForm: React.FC = () => {
  const navigate = useNavigate();
  
  const [leadData, setLeadData] = useState<LeadData>({
    image: '',
    licensePlate: '',
    store: '',
    time: '',
    leadType: ''
  });

  const [customerData, setCustomerData] = useState<CustomerData>({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    zipCode: '',
    notes: ''
  });

  const [repEmail, setRepEmail] = useState<string>('');
  const [availableUsers, setAvailableUsers] = useState<any[]>([]);
  const [errors, setErrors] = useState<any>({});
  const [isLoading, setIsLoading] = useState(false);
  const [showLinkGenerator, setShowLinkGenerator] = useState(false);
  const [generatedLink, setGeneratedLink] = useState<string>('');
  const [linkCopied, setLinkCopied] = useState(false);

  // Image loading state
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Load available users
  useEffect(() => {
    const loadUsers = async () => {
      const users = await getActiveUsers();
      setAvailableUsers(users);
      
      // Auto-select sales rep if logged in
      const sessionRepEmail = sessionStorage.getItem('salesRepEmail');
      if (sessionRepEmail && users.some(user => user.email === sessionRepEmail)) {
        setRepEmail(sessionRepEmail);
      }
    };
    loadUsers();
  }, []);

  // Listen for webhook data on component mount
  useEffect(() => {
    const webhookData = sessionStorage.getItem('webhookData');
    if (webhookData) {
      try {
        const data = JSON.parse(webhookData);
        setLeadData(prev => ({
          ...prev,
          ...data,
          time: data.time || new Date().toISOString().slice(0, 16),
          leadType: '' // Always start blank
        }));
        
        // Set up image URLs if image exists
        if (data.image) {
          const urls = getGoogleDriveImageUrls(data.image);
          setImageUrls(urls);
        }
        
        sessionStorage.removeItem('webhookData');
      } catch (error) {
        console.error('Error parsing webhook data:', error);
      }
    } else {
      // Set default time if no webhook data
      setLeadData(prev => ({
        ...prev,
        time: new Date().toISOString().slice(0, 16)
      }));
    }
  }, []);

  const handleImageError = () => {
    if (currentImageIndex < imageUrls.length - 1) {
      setCurrentImageIndex(prev => prev + 1);
    } else {
      setImageLoaded(false);
    }
  };

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  const validateForm = (): boolean => {
    console.log('=== FORM VALIDATION STARTED ===');
    const newErrors: any = {};

    // Lead data validation (always required)
    if (!leadData.licensePlate.trim()) {
      console.log('License plate validation failed');
      newErrors.licensePlate = 'License plate is required';
    }
    if (!leadData.store.trim()) {
      console.log('Store validation failed');
      newErrors.store = 'Store is required';
    }
    if (!leadData.time) {
      console.log('Time validation failed');
      newErrors.time = 'Time is required';
    }
    if (!repEmail.trim()) {
      console.log('Rep email validation failed');
      newErrors.repEmail = 'Sales representative email is required';
    }

    // Lead type validation
    if (!leadData.leadType) {
      console.log('Lead type validation failed');
      newErrors.leadType = 'Lead type is required';
    }

    // Notes validation - required for non-customer leads
    if (leadData.leadType !== 'Customer' && leadData.leadType && !customerData.notes?.trim()) {
      console.log('Notes validation failed for non-customer lead');
      newErrors.notes = 'Notes are required for non-customer leads';
    }

    // Customer data validation (only required if leadType is 'Customer')
    if (leadData.leadType === 'Customer') {
      console.log('Validating customer data...');
      if (!customerData.firstName.trim()) {
        newErrors.firstName = 'First name is required for customers';
      }
      if (!customerData.lastName.trim()) {
        newErrors.lastName = 'Last name is required for customers';
      }
      if (!customerData.email.trim()) {
        newErrors.email = 'Email is required for customers';
      } else if (!validateEmail(customerData.email)) {
        newErrors.email = 'Please enter a valid email address';
      }
      if (!customerData.phoneNumber.trim()) {
        newErrors.phoneNumber = 'Phone number is required for customers';
      } else if (!validatePhoneNumber(customerData.phoneNumber)) {
        newErrors.phoneNumber = 'Please enter a valid US phone number';
      }
      if (!customerData.zipCode.trim()) {
        newErrors.zipCode = 'Zip code is required for customers';
      } else if (!validateZipCode(customerData.zipCode)) {
        newErrors.zipCode = 'Please enter a valid US zip code';
      }
    }

    console.log('Validation errors:', newErrors);
    console.log('Validation result:', Object.keys(newErrors).length === 0 ? 'PASSED' : 'FAILED');
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('=== FORM SUBMISSION STARTED ===');
    console.log('Current leadData:', leadData);
    console.log('Current customerData:', customerData);
    console.log('Current repEmail:', repEmail);
    console.log('Available users:', availableUsers);
    
    console.log('=== FORM SUBMISSION DEBUG ===');
    console.log('Current leadData:', leadData);
    console.log('Current customerData:', customerData);
    console.log('Current repEmail:', repEmail);
    
    if (!validateForm()) {
      console.log('Form validation failed, errors:', errors);
      console.log('Form validation failed, errors:', errors);
      return;
    }

    console.log('Form validation passed, proceeding with submission...');
    setIsLoading(true);

    try {
      const submissionData: FormSubmission = {
        ...leadData,
        repEmail,
        notes: customerData.notes?.trim() || undefined,
        customerData: leadData.leadType === 'Customer' ? {
          ...customerData,
          phoneNumber: formatPhoneNumber(customerData.phoneNumber)
        } : undefined,
        notes: customerData.notes?.trim() || undefined
      };

      console.log('Final submission data:', JSON.stringify(submissionData, null, 2));

      const success = await submitToGoogleSheets(submissionData);
      
      if (success) {
        console.log('Google Sheets submission successful, navigating to confirmation');
        navigate('/confirmation', { state: { submissionData } });
      } else {
        console.error('Google Sheets submission failed');
        setErrors(prev => ({ ...prev, submit: 'Failed to submit to Google Sheets. Please try again.' }));
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setErrors(prev => ({ ...prev, submit: 'An error occurred while submitting. Please try again.' }));
    } finally {
      setIsLoading(false);
    }
  };

  const handleLeadChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setLeadData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev: any) => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const handleCustomerChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCustomerData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev: any) => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const handleRepEmailChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setRepEmail(value);

    // Clear error when user selects
    if (errors.repEmail) {
      setErrors((prev: any) => ({
        ...prev,
        repEmail: undefined
      }));
    }
  };

  const handleGenerateLink = () => {
    if (!leadData.leadType || !leadData.licensePlate || !leadData.store) {
      setErrors({ linkGeneration: 'Please fill in all lead information before generating a link' });
      return;
    }

    const generateLink = async () => {
      try {
        const leadId = await storeLead(leadData);
        const shareableLink = generateShareableLink(leadId);
        setGeneratedLink(shareableLink);
        setShowLinkGenerator(true);
      } catch (error) {
        setErrors({ linkGeneration: 'Failed to generate link. Please try again.' });
      }
    };

    generateLink();
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(generatedLink);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy link:', error);
    }
  };

  const handleOpenLink = () => {
    window.open(generatedLink, '_blank');
  };

  const isCustomerLead = leadData.leadType === 'Customer';
  
  return (
    <div className="min-h-screen ulrich-gradient-light py-6 sm:py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto w-full">
        <div className="text-center mb-6 sm:mb-8">
          <img 
            src="/ulrich-logo.png"
            alt="Ulrich - Built for You. Made for Life." 
            className="h-16 sm:h-24 mx-auto mb-3 sm:mb-4"
          />
          <h1 className="text-2xl sm:text-3xl font-bold mb-2" style={{ color: '#435B75' }}>Lead Management Form</h1>
          <p className="text-sm sm:text-base text-gray-600 px-4">Complete the lead information below</p>
        </div>

        <form onSubmit={handleSubmit} className="ulrich-card rounded-2xl shadow-xl p-4 sm:p-8 space-y-4 sm:space-y-6">
          {/* Image Field */}
          <div className="space-y-2 sm:space-y-2">
            <label className="flex items-center text-sm sm:text-sm font-semibold" style={{ color: '#435B75' }}>
              <Camera className="w-4 h-4 mr-2 flex-shrink-0" style={{ color: '#B8906B' }} />
              Image
            </label>
            {leadData.image && imageUrls.length > 0 ? (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 sm:p-4">
                {imageLoaded || currentImageIndex < imageUrls.length ? (
                  <img 
                    src={imageUrls[currentImageIndex]} 
                    alt="Lead Image" 
                    className="max-w-full h-auto max-h-32 sm:max-h-48 mx-auto rounded-lg shadow-md"
                    onError={handleImageError}
                    onLoad={handleImageLoad}
                    style={{ display: imageLoaded ? 'block' : 'none' }}
                  />
                ) : null}
                
                {!imageLoaded && currentImageIndex >= imageUrls.length && (
                  <div className="text-center text-gray-500 py-4 sm:py-8">
                    <div className="text-2xl sm:text-4xl mb-2">📷</div>
                    <p className="text-sm sm:text-base">Image could not be loaded</p>
                    <p className="text-xs mt-1 sm:mt-2">Google Drive image may require public access</p>
                  </div>
                )}
                
                <details className="mt-2">
                  <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-700">
                    Show image URLs (trying {currentImageIndex + 1} of {imageUrls.length})
                  </summary>
                  <div className="mt-2 space-y-2">
                    <p className="text-xs text-gray-400 break-all bg-gray-50 p-2 rounded">
                      <strong>Original:</strong> {leadData.image}
                    </p>
                    {imageUrls.map((url, index) => (
                      <p key={index} className={`text-xs break-all p-2 rounded ${
                        index === currentImageIndex ? 'bg-blue-50 text-blue-700' : 'bg-gray-50 text-gray-400'
                      }`}>
                        {index === currentImageIndex && ' (current)'}
                      </p>
                    ))}
                  </div>
                </details>
              </div>
            ) : (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 sm:p-8 text-center">
                <Camera className="w-8 h-8 sm:w-12 sm:h-12 mx-auto text-gray-400 mb-2" />
                <p className="text-gray-500 text-sm sm:text-base">No image provided</p>
              </div>
            )}
          </div>

          {/* License Plate */}
          <div className="space-y-2 sm:space-y-2">
            <label htmlFor="licensePlate" className="flex items-center text-sm font-semibold" style={{ color: '#435B75' }}>
              <MapPin className="w-4 h-4 mr-2 flex-shrink-0" style={{ color: '#B8906B' }} />
              License Plate *
            </label>
            <input
              type="text"
              id="licensePlate"
              name="licensePlate"
              value={leadData.licensePlate}
              onChange={handleLeadChange}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                errors.licensePlate ? 'border-red-500' : 'border-gray-300'
              }`}
              style={{ '--tw-ring-color': '#B8906B' }}
              placeholder="Enter license plate number"
            />
            {errors.licensePlate && (
              <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.licensePlate}</p>
            )}
          </div>

          {/* Store */}
          <div className="space-y-2 sm:space-y-2">
            <label htmlFor="store" className="flex items-center text-sm font-semibold text-gray-700">
              <MapPin className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
              Store *
            </label>
            <input
              type="text"
              id="store"
              name="store"
              value={leadData.store}
              onChange={handleLeadChange}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                errors.store ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="Enter store location"
            />
            {errors.store && (
              <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.store}</p>
            )}
          </div>

          {/* Time */}
          <div className="space-y-2 sm:space-y-2">
            <label htmlFor="time" className="flex items-center text-sm font-semibold text-gray-700">
              <Clock className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
              Time *
            </label>
            <input
              type="datetime-local"
              id="time"
              name="time"
              value={leadData.time}
              onChange={handleLeadChange}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                errors.time ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.time && (
              <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.time}</p>
            )}
          </div>

          {/* Sales Representative */}
          <div className="space-y-2 sm:space-y-2">
            <label htmlFor="repEmail" className="flex items-center text-sm font-semibold text-gray-700">
              <UserCheck className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
              Sales Representative *
            </label>
            <select
              id="repEmail"
              name="repEmail"
              value={repEmail}
              onChange={handleRepEmailChange}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                errors.repEmail ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Select Sales Representative</option>
              {availableUsers.map((user) => (
                <option key={user.id} value={user.email}>
                  {user.name} ({user.email})
                </option>
              ))}
            </select>
            {sessionStorage.getItem('salesRepEmail') && (
              <p className="text-xs sm:text-sm text-blue-600 mt-1">
                Auto-selected: You are logged in as {sessionStorage.getItem('salesRepName')}
              </p>
            )}
            {errors.repEmail && (
              <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.repEmail}</p>
            )}
            {availableUsers.length === 0 && (
              <p className="text-amber-600 text-xs sm:text-sm mt-1">
                No sales representatives configured. Please contact your administrator.
              </p>
            )}
          </div>

          {/* Lead Type */}
          <div className="space-y-2 sm:space-y-2">
            <label htmlFor="leadType" className="flex items-center text-sm font-semibold text-gray-700">
              <Users className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
              Lead Type *
            </label>
            <select
              id="leadType"
              name="leadType"
              value={leadData.leadType}
              onChange={handleLeadChange}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                errors.leadType ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Select Lead Type</option>
              <option value="Customer">Customer</option>
              <option value="Vendor">Vendor</option>
              <option value="Employee">Employee</option>
              <option value="Vendor / Other">Vendor / Other</option>
            </select>
            {errors.leadType && (
              <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.leadType}</p>
            )}
            {leadData.leadType && leadData.leadType !== 'Customer' && (
              <p className="text-xs sm:text-sm text-gray-600 mt-2">
                Customer information below is optional for {leadData.leadType} leads
                <br />
                <span className="font-medium text-blue-600 text-xs sm:text-sm">Notes are required for this lead type</span>
              </p>
            )}
          </div>

          {/* Customer Information Section */}
          <div className="border-t pt-4 sm:pt-6">
            <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">Customer Information</h3>
            
            {/* First Name */}
            <div className="space-y-2 mb-3 sm:mb-4">
              <label htmlFor="firstName" className="flex items-center text-sm font-semibold text-gray-700">
                <User className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                First Name {isCustomerLead && '*'}
              </label>
              <input
                type="text"
                id="firstName"
                name="firstName"
                value={customerData.firstName}
                onChange={handleCustomerChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                  errors.firstName ? 'border-red-500' : 'border-gray-300'
                } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                placeholder="Enter first name"
                disabled={!isCustomerLead}
              />
              {errors.firstName && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.firstName}</p>
              )}
            </div>

            {/* Last Name */}
            <div className="space-y-2 mb-3 sm:mb-4">
              <label htmlFor="lastName" className="flex items-center text-sm font-semibold text-gray-700">
                <User className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                Last Name {isCustomerLead && '*'}
              </label>
              <input
                type="text"
                id="lastName"
                name="lastName"
                value={customerData.lastName}
                onChange={handleCustomerChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                  errors.lastName ? 'border-red-500' : 'border-gray-300'
                } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                placeholder="Enter last name"
                disabled={!isCustomerLead}
              />
              {errors.lastName && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.lastName}</p>
              )}
            </div>

            {/* Email */}
            <div className="space-y-2 mb-3 sm:mb-4">
              <label htmlFor="email" className="flex items-center text-sm font-semibold text-gray-700">
                <Mail className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                Email Address {isCustomerLead && '*'}
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={customerData.email}
                onChange={handleCustomerChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                  errors.email ? 'border-red-500' : 'border-gray-300'
                } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                placeholder="customer@example.com"
                disabled={!isCustomerLead}
              />
              {errors.email && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.email}</p>
              )}
            </div>

            {/* Phone Number */}
            <div className="space-y-2 mb-3 sm:mb-4">
              <label htmlFor="phoneNumber" className="flex items-center text-sm font-semibold text-gray-700">
                <Phone className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                Phone Number {isCustomerLead && '*'}
              </label>
              <input
                type="tel"
                id="phoneNumber"
                name="phoneNumber"
                value={customerData.phoneNumber}
                onChange={handleCustomerChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                  errors.phoneNumber ? 'border-red-500' : 'border-gray-300'
                } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                placeholder="(555) 123-4567"
                disabled={!isCustomerLead}
              />
              {errors.phoneNumber && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.phoneNumber}</p>
              )}
            </div>

            {/* Zip Code */}
            <div className="space-y-2 mb-3 sm:mb-4">
              <label htmlFor="zipCode" className="flex items-center text-sm font-semibold text-gray-700">
                <MapPin className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                Zip Code {isCustomerLead && '*'}
              </label>
              <input
                type="text"
                id="zipCode"
                name="zipCode"
                value={customerData.zipCode}
                onChange={handleCustomerChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[48px] text-base ${
                  errors.zipCode ? 'border-red-500' : 'border-gray-300'
                } ${!isCustomerLead ? 'bg-gray-50' : ''}`}
                placeholder="12345"
                disabled={!isCustomerLead}
              />
              {errors.zipCode && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.zipCode}</p>
              )}
            </div>

            {/* Notes Field */}
            <div className="space-y-2 sm:space-y-2">
              <label htmlFor="notes" className="flex items-center text-sm font-semibold text-gray-700">
                <FileText className="w-4 h-4 mr-2 text-blue-600 flex-shrink-0" />
                Notes {leadData.leadType !== 'Customer' && leadData.leadType ? '*' : ''}
              </label>
              <textarea
                id="notes"
                name="notes"
                value={customerData.notes || ''}
                onChange={handleCustomerChange}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-y min-h-[48px] text-base ${
                  errors.notes ? 'border-red-500' : 'border-gray-300'
                }`}
                rows={2}
                placeholder={
                  leadData.leadType !== 'Customer' && leadData.leadType
                    ? "Please provide details about this lead (required for non-customer leads)"
                    : "Optional notes about this lead"
                }
              />
              {errors.notes && (
                <p className="text-red-500 text-xs sm:text-sm mt-1">{errors.notes}</p>
              )}
              {leadData.leadType !== 'Customer' && leadData.leadType && (
                <p className="text-xs sm:text-sm text-blue-600">
                  Notes are required for {leadData.leadType} leads
                </p>
              )}
            </div>
          </div>

          {/* Submit Error */}
          {errors.submit && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4">
              <p className="text-red-600 text-xs sm:text-sm">{errors.submit}</p>
            </div>
          )}

          {/* Link Generation Error */}
          {errors.linkGeneration && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4">
              <p className="text-red-600 text-xs sm:text-sm">{errors.linkGeneration}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-3 sm:space-y-4">
            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              onClick={(e) => {
                console.log('Submit button clicked!');
                console.log('Form element:', e.currentTarget.form);
                console.log('Is loading:', isLoading);
              }}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 px-6 rounded-lg font-semibold hover:from-green-700 hover:to-emerald-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-base min-h-[52px]"
            >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-4 w-4 sm:h-5 sm:w-5 border-b-2 border-white mr-2"></div>
                  Submitting...
                </span>
              ) : (
                <span className="flex items-center justify-center">
                  <Send className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                  Submit Lead
                </span>
              )}
            </button>

            {/* Generate Link Button */}
            {leadData.leadType === 'Customer' && (
              <button
                type="button"
                onClick={handleGenerateLink}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-4 px-6 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition-all duration-200 text-base min-h-[52px]"
              >
                <Send className="w-4 h-4 sm:w-5 sm:h-5 mr-2 inline" />
                Generate Link for Salesperson
              </button>
            )}
          </div>

          {/* Link Generator Section */}
          {showLinkGenerator && generatedLink && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 sm:p-6">
              <h3 className="text-base sm:text-lg font-semibold text-blue-900 mb-3">
                Salesperson Link Generated
              </h3>
              <p className="text-blue-700 text-xs sm:text-sm mb-3 sm:mb-4">
                Share this link with your salesperson to complete the customer details.
              </p>
              
              <div className="bg-white border border-gray-300 rounded-lg p-2 sm:p-3 mb-3 sm:mb-4">
                <p className="text-xs text-gray-500 mb-1">Shareable Link:</p>
                <p className="text-xs sm:text-sm font-mono text-gray-800 break-all">{generatedLink}</p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center min-h-[44px]"
                >
                  {linkCopied ? (
                    <>
                      <Check className="w-4 h-4 mr-2 flex-shrink-0" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2 flex-shrink-0" />
                      Copy Link
                    </>
                  )}
                </button>
                
                <button
                  type="button"
                  onClick={handleOpenLink}
                  className="bg-gray-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center min-h-[44px] sm:w-auto w-full"
                >
                  <ExternalLink className="w-4 h-4 flex-shrink-0" />
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default MainForm;