import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, LogOut, Clock, CheckCircle, Eye, ExternalLink, Camera, MapPin, Users, FileText, AlertCircle } from 'lucide-react';
import { getAllLeads } from '../utils/storage';
import { StoredLead } from '../types';
import { getGoogleDriveImageUrls } from '../utils/imageUtils';

const SalesRepDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [myLeads, setMyLeads] = useState<StoredLead[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<StoredLead | null>(null);
  const [showLeadDetails, setShowLeadDetails] = useState(false);
  const [salesRepEmail, setSalesRepEmail] = useState('');
  const [salesRepName, setSalesRepName] = useState('');

  // Image loading state for modal
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    // Get sales rep info from session
    const email = sessionStorage.getItem('salesRepEmail') || '';
    const name = sessionStorage.getItem('salesRepName') || '';
    setSalesRepEmail(email);
    setSalesRepName(name);

    // Load leads assigned to this sales rep
    const loadMyLeads = async () => {
      try {
        const allLeads = await getAllLeads();
        
        // Filter leads that are either:
        // 1. Not completed yet (pending leads that need completion)
        // 2. Completed by this sales rep
        const myAssignedLeads = allLeads.filter(lead => {
          // Show incomplete leads that don't have a rep assigned yet, or leads assigned to this rep
          if (!lead.completed) {
            return true; // Show all incomplete leads for now
          }
          return false;
        });

        console.log('Sales rep leads:', myAssignedLeads);
        setMyLeads(myAssignedLeads);
      } catch (error) {
        console.error('Error loading leads:', error);
      } finally {
        setLoading(false);
      }
    };

    loadMyLeads();

    // Refresh leads every 30 seconds
    const interval = setInterval(loadMyLeads, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    sessionStorage.removeItem('salesRepAuthenticated');
    sessionStorage.removeItem('salesRepEmail');
    sessionStorage.removeItem('salesRepName');
    navigate('/sales-login');
  };

  const handleViewLead = (lead: StoredLead) => {
    setSelectedLead(lead);
    
    // Set up image URLs if image exists
    if (lead.data.image) {
      const urls = getGoogleDriveImageUrls(lead.data.image);
      setImageUrls(urls);
      setCurrentImageIndex(0);
      setImageLoaded(false);
    } else {
      setImageUrls([]);
    }
    
    setShowLeadDetails(true);
  };

  const handleCompleteLead = (leadId: string) => {
    navigate(`/complete-lead/${leadId}`);
  };

  const handleImageError = () => {
    if (currentImageIndex < imageUrls.length - 1) {
      setCurrentImageIndex(prev => prev + 1);
    } else {
      setImageLoaded(false);
    }
  };

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your leads...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg mb-8">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Sales Rep Dashboard</h1>
                <p className="text-gray-600 mt-1">Welcome back, {salesRepName}</p>
              </div>
              <button
                onClick={handleLogout}
                className="bg-red-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </button>
            </div>
          </div>

          {/* Stats */}
          <div className="p-6 bg-gray-50">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{myLeads.length}</div>
                <div className="text-sm text-gray-600">Pending Leads</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {myLeads.filter(lead => lead.data.leadType === 'Customer' || !lead.data.leadType).length}
                </div>
                <div className="text-sm text-gray-600">Customer Leads</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {myLeads.filter(lead => lead.data.leadType && lead.data.leadType !== 'Customer').length}
                </div>
                <div className="text-sm text-gray-600">Other Leads</div>
              </div>
            </div>
          </div>
        </div>

        {/* Pending Leads */}
        <div className="bg-white rounded-xl shadow-lg">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Your Pending Leads</h2>
            <p className="text-sm text-gray-600 mt-1">
              Complete these leads by adding customer information
            </p>
          </div>

          {myLeads.length === 0 ? (
            <div className="p-12 text-center">
              <Clock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Pending Leads</h3>
              <p className="text-gray-600 mb-4">
                You don't have any pending leads at the moment. New leads will appear here when they're assigned to you.
              </p>
              <button
                onClick={() => navigate('/')}
                className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
              >
                Go to Homepage
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      License Plate
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Store
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Time
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Lead Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Created
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {myLeads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {lead.data.licensePlate || 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {lead.data.store || 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {lead.data.time ? formatTimestamp(lead.data.time) : 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          !lead.data.leadType || lead.data.leadType === 'Customer'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {lead.data.leadType || 'Customer'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {formatTimestamp(lead.createdAt)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleViewLead(lead)}
                            className="text-blue-600 hover:text-blue-700"
                            title="View details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleCompleteLead(lead.id)}
                            className="bg-green-600 text-white py-1 px-3 rounded text-xs font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200"
                          >
                            Complete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Lead Details Modal */}
        {showLeadDetails && selectedLead && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">Lead Details</h3>
                  <button
                    onClick={() => {
                      setShowLeadDetails(false);
                      setSelectedLead(null);
                    }}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <AlertCircle className="w-6 h-6" />
                  </button>
                </div>
              </div>
              
              <div className="p-6 space-y-6">
                {/* Status */}
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-orange-100 text-orange-800">
                    <Clock className="w-4 h-4 mr-1" />
                    Pending Completion
                  </span>
                  <div className="text-sm text-gray-500">
                    ID: {selectedLead.id}
                  </div>
                </div>

                {/* Image */}
                {selectedLead.data.image && imageUrls.length > 0 && (
                  <div>
                    <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                      <Camera className="w-4 h-4 mr-2" />
                      Image
                    </label>
                    <div className="border rounded-lg p-4">
                      {imageLoaded || currentImageIndex < imageUrls.length ? (
                        <img 
                          src={imageUrls[currentImageIndex]} 
                          alt="Lead Image" 
                          className="max-w-full h-auto max-h-64 mx-auto rounded-lg shadow-md"
                          onError={handleImageError}
                          onLoad={handleImageLoad}
                          style={{ display: imageLoaded ? 'block' : 'none' }}
                        />
                      ) : null}
                      
                      {!imageLoaded && currentImageIndex >= imageUrls.length && (
                        <div className="text-center text-gray-500 py-8">
                          <Camera className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                          <p>Image could not be loaded</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Lead Information */}
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Lead Information</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700">
                        <MapPin className="w-4 h-4 mr-1" />
                        License Plate
                      </label>
                      <p className="text-gray-900 mt-1">{selectedLead.data.licensePlate || 'N/A'}</p>
                    </div>
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700">
                        <MapPin className="w-4 h-4 mr-1" />
                        Store
                      </label>
                      <p className="text-gray-900 mt-1">{selectedLead.data.store || 'N/A'}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Time</label>
                      <p className="text-gray-900 mt-1">{formatTimestamp(selectedLead.data.time)}</p>
                    </div>
                    <div>
                      <label className="flex items-center text-sm font-medium text-gray-700">
                        <Users className="w-4 h-4 mr-1" />
                        Lead Type
                      </label>
                      <p className="text-gray-900 mt-1">{selectedLead.data.leadType || 'Not Set'}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Created</label>
                      <p className="text-gray-900 mt-1">{formatTimestamp(selectedLead.createdAt)}</p>
                    </div>
                  </div>
                </div>

                {/* Customer Information (if available) */}
                {selectedLead.customerData && (
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Customer Information</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="flex items-center text-sm font-medium text-gray-700">
                          <User className="w-4 h-4 mr-1" />
                          Name
                        </label>
                        <p className="text-gray-900 mt-1">
                          {selectedLead.customerData.firstName} {selectedLead.customerData.lastName}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700">Email</label>
                        <p className="text-gray-900 mt-1">{selectedLead.customerData.email}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700">Phone</label>
                        <p className="text-gray-900 mt-1">{selectedLead.customerData.phoneNumber}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700">Zip Code</label>
                        <p className="text-gray-900 mt-1">{selectedLead.customerData.zipCode}</p>
                      </div>
                    </div>
                    
                    {selectedLead.customerData.notes && (
                      <div className="mt-4">
                        <label className="flex items-center text-sm font-medium text-gray-700">
                          <FileText className="w-4 h-4 mr-1" />
                          Notes
                        </label>
                        <p className="text-gray-900 mt-1 bg-gray-50 p-3 rounded-lg">
                          {selectedLead.customerData.notes}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-4 border-t">
                  <button
                    onClick={() => handleCompleteLead(selectedLead.id)}
                    className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Complete This Lead
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SalesRepDashboard;