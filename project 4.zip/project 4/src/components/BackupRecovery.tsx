import React, { useState, useEffect } from 'react';
import { Download, Upload, RotateCcw, Save, Trash2, AlertTriangle, CheckCircle, Clock, FileText } from 'lucide-react';
import { 
  createBackup, 
  getBackups, 
  restoreFromBackup, 
  BackupData,
  getSuccessfulSubmissions,
  getFailedSubmissions,
  exportAllData
} from '../utils/backupSystem';

const BackupRecovery: React.FC = () => {
  const [backups, setBackups] = useState<BackupData[]>([]);
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [backupDescription, setBackupDescription] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showRecoveryOptions, setShowRecoveryOptions] = useState(false);

  useEffect(() => {
    loadBackups();
  }, []);

  const loadBackups = () => {
    const allBackups = getBackups();
    setBackups(allBackups);
  };

  const handleCreateBackup = async () => {
    setIsCreatingBackup(true);
    setMessage(null);
    
    try {
      const description = backupDescription.trim() || `Manual backup - ${new Date().toLocaleString()}`;
      await createBackup(description);
      setBackupDescription('');
      loadBackups();
      setMessage({ type: 'success', text: 'Backup created successfully!' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to create backup' });
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const handleRestore = async (backupId: string) => {
    if (!window.confirm('Are you sure you want to restore this backup? This will replace all current leads.')) {
      return;
    }

    setIsRestoring(true);
    setMessage(null);
    
    try {
      const success = await restoreFromBackup(backupId);
      if (success) {
        setMessage({ type: 'success', text: 'Backup restored successfully!' });
        // Refresh the page to show restored data
        setTimeout(() => window.location.reload(), 2000);
      } else {
        setMessage({ type: 'error', text: 'Failed to restore backup' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Error during restore process' });
    } finally {
      setIsRestoring(false);
    }
  };

  const handleExportData = () => {
    const data = exportAllData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `lead-data-export-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  // Check for potential recovery sources
  const successfulSubmissions = getSuccessfulSubmissions();
  const failedSubmissions = getFailedSubmissions();
  const hasRecoveryData = successfulSubmissions.length > 0 || failedSubmissions.length > 0;

  return (
    <div className="space-y-6">
      {/* Emergency Recovery Alert */}
      {hasRecoveryData && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <AlertTriangle className="w-6 h-6 text-amber-600 mr-3" />
            <h3 className="text-lg font-semibold text-amber-900">
              Potential Data Recovery Available
            </h3>
          </div>
          <p className="text-amber-800 mb-4">
            Found {successfulSubmissions.length} successful submissions and {failedSubmissions.length} failed submissions in browser storage that might help recover lost data.
          </p>
          <button
            onClick={() => setShowRecoveryOptions(!showRecoveryOptions)}
            className="bg-amber-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2 transition-all duration-200"
          >
            {showRecoveryOptions ? 'Hide' : 'Show'} Recovery Options
          </button>
        </div>
      )}

      {/* Recovery Options */}
      {showRecoveryOptions && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Emergency Recovery Options</h3>
          
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-2">Successful Submissions ({successfulSubmissions.length})</h4>
              <p className="text-blue-800 text-sm mb-3">
                These are leads that were successfully submitted to Google Sheets. They might still exist in your spreadsheet.
              </p>
              {successfulSubmissions.length > 0 && (
                <button
                  onClick={() => {
                    const data = JSON.stringify(successfulSubmissions, null, 2);
                    const blob = new Blob([data], { type: 'application/json' });
                    const url = window.URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = `successful-submissions-${new Date().toISOString().split('T')[0]}.json`;
                    link.click();
                    window.URL.revokeObjectURL(url);
                  }}
                  className="bg-blue-600 text-white py-1 px-3 rounded text-sm font-medium hover:bg-blue-700"
                >
                  <Download className="w-4 h-4 inline mr-1" />
                  Export Successful Submissions
                </button>
              )}
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="font-medium text-red-900 mb-2">Failed Submissions ({failedSubmissions.length})</h4>
              <p className="text-red-800 text-sm mb-3">
                These are leads that failed to submit to Google Sheets and were stored locally.
              </p>
              {failedSubmissions.length > 0 && (
                <button
                  onClick={() => {
                    const data = JSON.stringify(failedSubmissions, null, 2);
                    const blob = new Blob([data], { type: 'application/json' });
                    const url = window.URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = `failed-submissions-${new Date().toISOString().split('T')[0]}.json`;
                    link.click();
                    window.URL.revokeObjectURL(url);
                  }}
                  className="bg-red-600 text-white py-1 px-3 rounded text-sm font-medium hover:bg-red-700"
                >
                  <Download className="w-4 h-4 inline mr-1" />
                  Export Failed Submissions
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Backup Management */}
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Backup & Recovery</h2>
              <p className="text-sm text-gray-600 mt-1">
                Create backups and restore your lead data
              </p>
            </div>
            <button
              onClick={handleExportData}
              className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
            >
              <FileText className="w-4 h-4 mr-2" />
              Export All Data
            </button>
          </div>
        </div>

        {/* Create Backup */}
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Backup</h3>
          <div className="flex gap-4">
            <input
              type="text"
              value={backupDescription}
              onChange={(e) => setBackupDescription(e.target.value)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Backup description (optional)"
            />
            <button
              onClick={handleCreateBackup}
              disabled={isCreatingBackup}
              className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isCreatingBackup ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              Create Backup
            </button>
          </div>
        </div>

        {/* Message */}
        {message && (
          <div className={`p-4 ${
            message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
          } border-l-4`}>
            <div className="flex items-center">
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
              )}
              <span className={`text-sm font-medium ${
                message.type === 'success' ? 'text-green-800' : 'text-red-800'
              }`}>
                {message.text}
              </span>
            </div>
          </div>
        )}

        {/* Backup List */}
        <div className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Available Backups</h3>
          
          {backups.length === 0 ? (
            <div className="text-center py-8">
              <Clock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Backups Yet</h3>
              <p className="text-gray-600">Create your first backup to protect your lead data.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {backups.map((backup) => (
                <div key={backup.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">{backup.description}</h4>
                      <div className="text-sm text-gray-600 mt-1">
                        <p>{backup.count} leads • {formatTimestamp(backup.timestamp)}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          const data = JSON.stringify(backup, null, 2);
                          const blob = new Blob([data], { type: 'application/json' });
                          const url = window.URL.createObjectURL(blob);
                          const link = document.createElement('a');
                          link.href = url;
                          link.download = `backup-${backup.id}.json`;
                          link.click();
                          window.URL.revokeObjectURL(url);
                        }}
                        className="text-blue-600 hover:text-blue-700 p-2"
                        title="Download backup"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleRestore(backup.id)}
                        disabled={isRestoring}
                        className="bg-blue-600 text-white py-1 px-3 rounded text-sm font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                      >
                        {isRestoring ? (
                          <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white mr-1"></div>
                        ) : (
                          <RotateCcw className="w-3 h-3 mr-1" />
                        )}
                        Restore
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BackupRecovery;