import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Upload, Download, Users, Check, X, AlertCircle, FileText, Key, Bell } from 'lucide-react';
import { getUsers, addUser, updateUser, deleteUser, importUsersFromCSV, exportUsersToCSV, clearAllUsers, getUsersNeedingPasswords, setUserPassword } from '../utils/userManagement';
import { User } from '../types';

const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [csvData, setCsvData] = useState('');
  const [importResults, setImportResults] = useState<{ success: number; errors: string[] } | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Password management states
  const [usersNeedingPasswords, setUsersNeedingPasswords] = useState<User[]>([]);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [selectedUserForPassword, setSelectedUserForPassword] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showCredentials, setShowCredentials] = useState(false);
  const [credentialsCopied, setCredentialsCopied] = useState(false);
  const [newlySetCredentials, setNewlySetCredentials] = useState<{email: string; password: string; name: string} | null>(null);
  
  // Bulk operations states
  const [selectedUsers, setSelectedUsers] = useState<Set<string>>(new Set());
  const [showBulkPasswordModal, setShowBulkPasswordModal] = useState(false);
  const [bulkPassword, setBulkPassword] = useState('');
  const [bulkPasswordError, setBulkPasswordError] = useState('');
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);
  const [bulkResults, setBulkResults] = useState<{ success: string[]; errors: { userId: string; error: string }[] } | null>(null);

  // Form states
  const [formData, setFormData] = useState({ 
    email: '', 
    name: '', 
    active: true, 
    password: '', 
    phone_number: '', 
    assigned_stores: [] as string[] 
  });
  const [formErrors, setFormErrors] = useState<{ email?: string; name?: string }>({});

  // Store management
  const [availableStores, setAvailableStores] = useState<string[]>([]);
  const [newStore, setNewStore] = useState('');

  useEffect(() => {
    const loadUsersAsync = async () => {
      const users = await getUsers();
      setUsers(users);
      
      // Load available stores from leads
      try {
        const { getAllLeads } = await import('../utils/storage');
        const leads = await getAllLeads();
        const stores = Array.from(new Set(leads.map(lead => lead.data.store).filter(Boolean))).sort();
        setAvailableStores(stores);
      } catch (error) {
        console.error('Error loading stores:', error);
      }
    };
    loadUsersAsync();
  }, []);

  const loadUsers = async () => {
    const users = await getUsers();
    setUsers(users);
    
    // Load users needing passwords
    const needingPasswords = await getUsersNeedingPasswords();
    setUsersNeedingPasswords(needingPasswords);
  };

  const validateForm = (): boolean => {
    const errors: { email?: string; name?: string; password?: string } = {};

    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!formData.name.trim()) {
      errors.name = 'Name is required';
    }

    if (showAddForm && !formData.password.trim()) {
      errors.password = 'Password is required for new users';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    try {
      const user = await addUser(formData.email, formData.name, formData.password || '1234');
      
      // Update with phone and store assignments
      if (formData.phone_number || formData.assigned_stores.length > 0) {
        await updateUser(user.id, {
          phone_number: formData.phone_number,
          assigned_stores: formData.assigned_stores
        });
      }
      
      await loadUsers();
      setShowAddForm(false);
      setFormData({ email: '', name: '', active: true, password: '', phone_number: '', assigned_stores: [] });
      setFormErrors({});
    } catch (error) {
      setFormErrors({ email: error.message });
    }
  };

  const handleEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !editingUser) return;

    try {
      await updateUser(editingUser.id, {
        email: formData.email,
        name: formData.name,
        active: formData.active,
        phone_number: formData.phone_number,
        assigned_stores: formData.assigned_stores
      });
      await loadUsers();
      setEditingUser(null);
      setFormData({ email: '', name: '', active: true, password: '', phone_number: '', assigned_stores: [] });
      setFormErrors({});
    } catch (error) {
      setFormErrors({ email: error.message });
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        await deleteUser(userId);
        await loadUsers();
      } catch (error) {
        console.error('Error deleting user:', error);
      }
    }
  };

  const handleImportCSV = async () => {
    if (!csvData.trim()) {
      setImportResults({ success: 0, errors: ['Please enter CSV data'] });
      return;
    }

    try {
      const results = await importUsersFromCSV(csvData);
      setImportResults(results);
      await loadUsers();
      
      if (results.errors.length === 0) {
        setCsvData('');
        setTimeout(() => {
          setShowImportModal(false);
          setImportResults(null);
        }, 2000);
      }
    } catch (error) {
      setImportResults({ success: 0, errors: [error.message] });
    }
  };

  const handleExportCSV = async () => {
    const csvContent = await exportUsersToCSV();
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `users-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  const handleClearAllUsers = async () => {
    await clearAllUsers();
    await loadUsers();
    setShowClearConfirm(false);
  };

  const handleSetPassword = async () => {
    if (!selectedUserForPassword) return;
    
    if (!newPassword.trim()) {
      setPasswordError('Password is required');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      setPasswordError('Passwords do not match');
      return;
    }
    
    if (newPassword.length < 4) {
      setPasswordError('Password must be at least 4 characters');
      return;
    }
    
    try {
      await setUserPassword(selectedUserForPassword.id, newPassword);
      await loadUsers();
      
      // Show the credentials that were just set
      setNewlySetCredentials({
        email: selectedUserForPassword.email,
        password: newPassword,
        name: selectedUserForPassword.name
      });
      setShowCredentials(true);
      
      setShowPasswordModal(false);
      setSelectedUserForPassword(null);
      setNewPassword('');
      setConfirmPassword('');
      setPasswordError('');
    } catch (error) {
      setPasswordError('Failed to set password');
    }
  };

  const handleBulkPasswordSet = async () => {
    if (selectedUsers.size === 0) {
      setBulkPasswordError('Please select at least one user');
      return;
    }
    
    if (!bulkPassword.trim()) {
      setBulkPasswordError('Password is required');
      return;
    }
    
    if (bulkPassword.length < 4) {
      setBulkPasswordError('Password must be at least 4 characters');
      return;
    }
    
    setIsBulkProcessing(true);
    setBulkPasswordError('');
    
    try {
      const { setBulkPasswords } = await import('../utils/userManagement');
      const results = await setBulkPasswords(Array.from(selectedUsers), bulkPassword);
      setBulkResults(results);
      await loadUsers();
      
      if (results.errors.length === 0) {
        // All successful - close modal after a delay
        setTimeout(() => {
          setShowBulkPasswordModal(false);
          setSelectedUsers(new Set());
          setBulkPassword('');
          setBulkResults(null);
        }, 2000);
      }
    } catch (error) {
      setBulkPasswordError('Failed to set passwords');
    } finally {
      setIsBulkProcessing(false);
    }
  };

  const handleUserSelection = (userId: string, checked: boolean) => {
    const newSelection = new Set(selectedUsers);
    if (checked) {
      newSelection.add(userId);
    } else {
      newSelection.delete(userId);
    }
    setSelectedUsers(newSelection);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedUsers(new Set(users.map(user => user.id)));
    } else {
      setSelectedUsers(new Set());
    }
  };

  const startEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      email: user.email,
      name: user.name,
      active: user.active,
      password: '',
      phone_number: user.phone_number || '',
      assigned_stores: user.assigned_stores || []
    });
    setFormErrors({});
  };

  const cancelEdit = () => {
    setEditingUser(null);
    setShowAddForm(false);
    setFormData({ email: '', name: '', active: true, password: '', phone_number: '', assigned_stores: [] });
    setFormErrors({});
  };

  const activeUsers = users.filter(user => user.active);
  const inactiveUsers = users.filter(user => !user.active);

  return (
    <div className="space-y-6">
      {/* Password Notifications */}
      {usersNeedingPasswords.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <Bell className="w-6 h-6 text-amber-600 mr-3" />
            <h3 className="text-lg font-semibold text-amber-900">
              Users Need Passwords ({usersNeedingPasswords.length})
            </h3>
          </div>
          <p className="text-amber-800 mb-4">
            The following users need passwords assigned before they can log into the sales portal:
          </p>
          <div className="space-y-2">
            {usersNeedingPasswords.map(user => (
              <div key={user.id} className="flex items-center justify-between bg-white p-3 rounded-lg">
                <div>
                  <span className="font-medium text-gray-900">{user.name}</span>
                  <span className="text-gray-600 ml-2">({user.email})</span>
                </div>
                <button
                  onClick={() => {
                    setSelectedUserForPassword(user);
                    setShowPasswordModal(true);
                    setPasswordError('');
                    setNewPassword('');
                    setConfirmPassword('');
                  }}
                  className="bg-amber-600 text-white py-1 px-3 rounded text-sm font-medium hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
                >
                  <Key className="w-3 h-3 mr-1" />
                  Set Password
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Header with Actions */}
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">User Management</h2>
              <p className="text-sm text-gray-600 mt-1">
                Manage sales representatives who can be selected in forms
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowAddForm(true)}
                className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add User
              </button>
              <button
                onClick={() => setShowImportModal(true)}
                className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
              >
                <Upload className="w-4 h-4 mr-2" />
                Import CSV
              </button>
              <button
                onClick={handleExportCSV}
                disabled={users.length === 0}
                className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="p-6 bg-gray-50">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{activeUsers.length}</div>
              <div className="text-sm text-gray-600">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-600">{inactiveUsers.length}</div>
              <div className="text-sm text-gray-600">Inactive Users</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{users.length}</div>
              <div className="text-sm text-gray-600">Total Users</div>
            </div>
          </div>
        </div>
      </div>

      {/* Add/Edit Form */}
      {(showAddForm || editingUser) && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            {editingUser ? 'Edit User' : 'Add New User'}
          </h3>
          <form onSubmit={editingUser ? handleEditUser : handleAddUser} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    formErrors.email ? 'border-red-500' : 'border-gray-300'
                  }`}
                  placeholder="user@company.com"
                />
                {formErrors.email && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.email}</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    formErrors.name ? 'border-red-500' : 'border-gray-300'
                  }`}
                  placeholder="John Doe"
                />
                {formErrors.name && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.phone_number}
                  onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="+1234567890"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Required for SMS notifications
                </p>
              </div>
              {showAddForm && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Password *
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                      formErrors.password ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="Enter password for sales rep"
                  />
                  {formErrors.password && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.password}</p>
                  )}
                </div>
              )}
            </div>
            
            {/* Store Assignment */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Assigned Stores
              </label>
              <div className="space-y-3">
                {/* Add new store */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newStore}
                    onChange={(e) => setNewStore(e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Add new store"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (newStore.trim() && !formData.assigned_stores.includes(newStore.trim())) {
                        setFormData({
                          ...formData,
                          assigned_stores: [...formData.assigned_stores, newStore.trim()]
                        });
                        setNewStore('');
                      }
                    }}
                    className="bg-blue-600 text-white py-2 px-3 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
                  >
                    Add
                  </button>
                </div>
                
                {/* Available stores from leads */}
                {availableStores.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-600 mb-2">Quick add from existing stores:</p>
                    <div className="flex flex-wrap gap-1">
                      {availableStores
                        .filter(store => !formData.assigned_stores.includes(store))
                        .map(store => (
                        <button
                          key={store}
                          type="button"
                          onClick={() => {
                            setFormData({
                              ...formData,
                              assigned_stores: [...formData.assigned_stores, store]
                            });
                          }}
                          className="text-xs bg-gray-100 text-gray-700 py-1 px-2 rounded hover:bg-gray-200 transition-colors"
                        >
                          + {store}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Currently assigned stores */}
                {formData.assigned_stores.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-600 mb-2">Assigned stores:</p>
                    <div className="flex flex-wrap gap-1">
                      {formData.assigned_stores.map((store, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded"
                        >
                          {store}
                          <button
                            type="button"
                            onClick={() => {
                              setFormData({
                                ...formData,
                                assigned_stores: formData.assigned_stores.filter((_, i) => i !== index)
                              });
                            }}
                            className="ml-1 text-blue-600 hover:text-blue-800"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.active}
                  onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                  className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <span className="text-sm font-medium text-gray-700">Active (available for selection)</span>
              </label>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200"
              >
                {editingUser ? 'Update User' : 'Add User'}
              </button>
              <button
                type="button"
                onClick={cancelEdit}
                className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Users List */}
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">All Users</h3>
            {users.length > 0 && (
              <div className="flex gap-2">
                {!showClearConfirm ? (
                  <button
                    onClick={() => setShowClearConfirm(true)}
                    className="text-red-600 hover:text-red-700 font-medium text-sm flex items-center"
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Clear All
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button
                      onClick={handleClearAllUsers}
                      className="bg-red-600 text-white py-1 px-3 rounded text-sm font-medium hover:bg-red-700"
                    >
                      Confirm Delete
                    </button>
                    <button
                      onClick={() => setShowClearConfirm(false)}
                      className="bg-gray-600 text-white py-1 px-3 rounded text-sm font-medium hover:bg-gray-700"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {users.length === 0 ? (
          <div className="p-12 text-center">
            <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Users Yet</h3>
            <p className="text-gray-600 mb-4">Add your first sales representative to get started.</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              Add First User
            </button>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {users.map((user) => (
              <div key={user.id} className="p-4 hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-3 h-3 rounded-full ${user.active ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                    <div>
                      <div className="font-medium text-gray-900">{user.name}</div>
                      <div className="text-sm text-gray-600">{user.email}</div>
                      {user.phone_number && (
                        <div className="text-xs text-gray-500">📱 {user.phone_number}</div>
                      )}
                      {user.assigned_stores && user.assigned_stores.length > 0 && (
                        <div className="text-xs text-gray-500">
                          🏪 {user.assigned_stores.join(', ')}
                        </div>
                      )}
                      <div className="text-xs text-gray-500">
                        Added {new Date(user.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      user.active 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.active ? 'Active' : 'Inactive'}
                    </span>
                    {user.needs_password && (
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-amber-100 text-amber-800 ml-2">
                        Needs Password
                      </span>
                    )}
                    <button
                      onClick={() => startEdit(user)}
                      className="text-blue-600 hover:text-blue-700 p-1"
                      title="Edit user"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        setSelectedUserForPassword(user);
                        setShowPasswordModal(true);
                        setPasswordError('');
                        setNewPassword('');
                        setConfirmPassword('');
                      }}
                      className="text-purple-600 hover:text-purple-700 p-1"
                      title="Set password"
                    >
                      <Key className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="text-red-600 hover:text-red-700 p-1"
                      title="Delete user"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    {user.password && !user.needs_password && (
                      <button
                        onClick={() => {
                          setNewlySetCredentials({
                            email: user.email,
                            password: user.password,
                            name: user.name
                          });
                          setShowCredentials(true);
                        }}
                        className="text-green-600 hover:text-green-700 p-1"
                        title="View credentials"
                      >
                        <FileText className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Import Users from CSV</h3>
                <button
                  onClick={() => {
                    setShowImportModal(false);
                    setCsvData('');
                    setImportResults(null);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  CSV Data
                </label>
                <div className="mb-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Format:</strong> Each line should contain: email,name,phone,stores
                  </p>
                  <p className="text-xs text-blue-600 mt-1">
                    Example: john@company.com,John Doe,+1234567890,Store A;Store B
                  </p>
                </div>
                <textarea
                  value={csvData}
                  onChange={(e) => setCsvData(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={8}
                  placeholder="john@company.com,John Doe,+1234567890,Store A;Store B&#10;jane@company.com,Jane Smith,+0987654321,Store C&#10;bob@company.com,Bob Johnson,+1122334455,Store A"
                />
              </div>

              {importResults && (
                <div className={`p-4 rounded-lg ${
                  importResults.errors.length === 0 ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                }`}>
                  <div className="flex items-center mb-2">
                    {importResults.errors.length === 0 ? (
                      <Check className="w-5 h-5 text-green-600 mr-2" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
                    )}
                    <span className={`font-medium ${
                      importResults.errors.length === 0 ? 'text-green-800' : 'text-red-800'
                    }`}>
                      Import Results: {importResults.success} users processed
                    </span>
                  </div>
                  <p className={`text-sm ${
                    importResults.errors.length === 0 ? 'text-green-700' : 'text-red-700'
                  }`}>
                    {importResults.success} users created/updated successfully
                  </p>
                  {importResults.errors.length > 0 && (
                    <div className="mt-2">
                      <p className="text-sm text-red-700 font-medium">Errors:</p>
                      <ul className="text-sm text-red-600 mt-1 space-y-1">
                        {importResults.errors.map((error, index) => (
                          <li key={index}>• {error}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              <div className="flex gap-2">
                <button
                  onClick={handleImportCSV}
                  disabled={!csvData.trim()}
                  className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Import Users
                </button>
                <button
                  onClick={() => {
                    setShowImportModal(false);
                    setCsvData('');
                    setImportResults(null);
                  }}
                  className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Password Setting Modal */}
      {showPasswordModal && selectedUserForPassword && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Set Password</h3>
                <button
                  onClick={() => {
                    setShowPasswordModal(false);
                    setSelectedUserForPassword(null);
                    setNewPassword('');
                    setConfirmPassword('');
                    setPasswordError('');
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-4">
                  Set a password for <strong>{selectedUserForPassword.name}</strong> ({selectedUserForPassword.email})
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter new password"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Confirm new password"
                />
              </div>
              
              {passwordError && (
                <div className="text-red-500 text-sm">{passwordError}</div>
              )}
              
              <div className="flex gap-2 pt-4">
                <button
                  onClick={handleSetPassword}
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
                >
                  Set Password
                </button>
                <button
                  onClick={() => {
                    setShowPasswordModal(false);
                    setSelectedUserForPassword(null);
                    setNewPassword('');
                    setConfirmPassword('');
                    setPasswordError('');
                  }}
                  className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Credentials Display Modal */}
      {showCredentials && newlySetCredentials && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Sales Rep Credentials</h3>
                <button
                  onClick={() => {
                    setShowCredentials(false);
                    setNewlySetCredentials(null);
                    setCredentialsCopied(false);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-800 text-sm font-medium mb-2">
                  📧 Share these credentials with {newlySetCredentials.name}:
                </p>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Sales Rep Name:
                  </label>
                  <p className="text-gray-900 font-medium">{newlySetCredentials.name}</p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email (Username):
                  </label>
                  <p className="text-gray-900 font-mono text-sm bg-white p-2 rounded border">
                    {newlySetCredentials.email}
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Password:
                  </label>
                  <p className="text-gray-900 font-mono text-sm bg-white p-2 rounded border">
                    {newlySetCredentials.password}
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Login URL:
                  </label>
                  <p className="text-gray-900 font-mono text-sm bg-white p-2 rounded border break-all">
                    {window.location.origin}/sales-login
                  </p>
                </div>
              </div>
              
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 text-sm">
                  <strong>Instructions for {newlySetCredentials.name}:</strong>
                </p>
                <ol className="text-green-700 text-sm mt-2 space-y-1 list-decimal list-inside">
                  <li>Go to the homepage and click "Login as Sales Rep"</li>
                  <li>Enter your email and password to log in</li>
                  <li>Click "View My Leads Dashboard" to see pending leads</li>
                  <li>Your name will auto-select in forms when logged in</li>
                </ol>
              </div>
              
              <div className="flex gap-2 pt-4">
                <button
                  onClick={async () => {
                    const credentialsText = `Sales Rep Credentials for ${newlySetCredentials.name}:

Email: ${newlySetCredentials.email}
Password: ${newlySetCredentials.password}

Instructions:
Login URL: ${window.location.origin}
2. Enter your email and password to log in
3. Click "View My Leads Dashboard" to see pending leads
4. Your name will auto-select in forms when logged in`;
                    
                    try {
                      await navigator.clipboard.writeText(credentialsText);
                      setCredentialsCopied(true);
                      setTimeout(() => setCredentialsCopied(false), 2000);
                    } catch (error) {
                      console.error('Failed to copy credentials:', error);
                    }
                  }}
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center"
                >
                  {credentialsCopied ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <FileText className="w-4 h-4 mr-2" />
                      Copy All Info
                    </>
                  )}
                </button>
                <button
                  onClick={() => {
                    setShowCredentials(false);
                    setNewlySetCredentials(null);
                    setCredentialsCopied(false);
                  }}
                  className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement;