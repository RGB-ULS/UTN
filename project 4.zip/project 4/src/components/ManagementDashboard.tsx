import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Calendar, MapPin, Filter, X, Eye, Clock, Users, BarChart3, TrendingUp, ExternalLink, CheckCircle, ArrowLeft, Trash2, Download, Upload, Bell, Send, Copy } from 'lucide-react';
import { getAllLeads } from '../utils/storage';
import { StoredLead } from '../types';
import { getGoogleDriveImageUrls } from '../utils/imageUtils';
import { sendOverdueLeadNotification, getWebhookConfig } from '../utils/webhookNotifications';
import { sendLeadNotificationSMS } from '../services/aloware';

const ManagementDashboard: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [allLeads, setAllLeads] = useState<StoredLead[]>([]);
  const [filteredLeads, setFilteredLeads] = useState<StoredLead[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<StoredLead | null>(null);
  const [showLeadDetails, setShowLeadDetails] = useState(false);
  const [selectedLeads, setSelectedLeads] = useState<Set<string>>(new Set());
  const [activeView, setActiveView] = useState<'all' | 'california' | 'texas' | 'virginia' | 'other'>(
    (searchParams.get('market') as any) || 'all'
  );
  
  // Filter states
  const [dateRangeType, setDateRangeType] = useState<'today' | 'yesterday' | 'this-week' | 'last-week' | 'last-month' | 'custom'>(
    (searchParams.get('period') as any) || 'today'
  );
  const [fromDate, setFromDate] = useState<string>('');
  const [toDate, setToDate] = useState<string>('');
  const [storeFilter, setStoreFilter] = useState<string>(searchParams.get('store') || 'all');

  // Completion status filter
  const [completionFilter, setCompletionFilter] = useState<'all' | 'complete' | 'incomplete'>('incomplete');
  // Image loading state for modal
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);
  
  // Notification states
  const [testNotificationResult, setTestNotificationResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isTestingNotification, setIsTestingNotification] = useState(false);
  const [linkCopied, setLinkCopied] = useState<string | null>(null);

  useEffect(() => {
    loadLeads();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [allLeads, dateRangeType, fromDate, toDate, storeFilter, activeView, completionFilter]);

  const loadLeads = async () => {
    try {
      setLoading(true);
      const leads = await getAllLeads();
      setAllLeads(leads);
    } catch (error) {
      console.error('Error loading leads:', error);
      setAllLeads([]);
    } finally {
      setLoading(false);
    }
  };

  // Helper function to determine market from store
  const getMarketFromStore = (store: string): string => {
    if (!store) return 'Unknown';
    const upperStore = store.toUpperCase();
    // Check for state codes at the beginning of the store name first
    if (upperStore.startsWith('TX ') || upperStore.startsWith('TX_') || upperStore === 'TX') return 'Texas';
    if (upperStore.startsWith('CA ') || upperStore.startsWith('CA_') || upperStore === 'CA') return 'California';
    if (upperStore.startsWith('VA ') || upperStore.startsWith('VA_') || upperStore === 'VA') return 'Virginia';
    
    // Fallback to anywhere in the string, but prioritize TX over CA since CA can appear in words
    if (upperStore.includes('TX')) return 'Texas';
    if (upperStore.includes('VA')) return 'Virginia';
    if (upperStore.includes('CA')) return 'California';
    
    return 'Other';
  };

  // Helper function to get date range based on selection
  const getDateRange = (type: string) => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    switch (type) {
      case 'today':
        return {
          from: today.toISOString().split('T')[0],
          to: today.toISOString().split('T')[0]
        };
      case 'yesterday':
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        return {
          from: yesterday.toISOString().split('T')[0],
          to: yesterday.toISOString().split('T')[0]
        };
      case 'this-week':
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - today.getDay()); // Sunday
        return {
          from: startOfWeek.toISOString().split('T')[0],
          to: today.toISOString().split('T')[0]
        };
      case 'last-week':
        const lastWeekEnd = new Date(today);
        lastWeekEnd.setDate(today.getDate() - today.getDay() - 1); // Last Saturday
        const lastWeekStart = new Date(lastWeekEnd);
        lastWeekStart.setDate(lastWeekEnd.getDate() - 6); // Last Sunday
        return {
          from: lastWeekStart.toISOString().split('T')[0],
          to: lastWeekEnd.toISOString().split('T')[0]
        };
      case 'last-month':
        const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);
        return {
          from: lastMonth.toISOString().split('T')[0],
          to: lastMonthEnd.toISOString().split('T')[0]
        };
      default:
        return { from: '', to: '' };
    }
  };
  const applyFilters = () => {
    let filtered = [...allLeads];

    // Get effective date range
    let effectiveFromDate = fromDate;
    let effectiveToDate = toDate;
    
    if (dateRangeType !== 'custom') {
      const range = getDateRange(dateRangeType);
      effectiveFromDate = range.from;
      effectiveToDate = range.to;
    }

    // Apply date filters
    if (effectiveFromDate) {
      const fromDateTime = new Date(effectiveFromDate).getTime();
      filtered = filtered.filter(lead => new Date(lead.createdAt).getTime() >= fromDateTime);
    }
    if (effectiveToDate) {
      const toDateTime = new Date(effectiveToDate + 'T23:59:59').getTime();
      filtered = filtered.filter(lead => new Date(lead.createdAt).getTime() <= toDateTime);
    }

    // Apply store filter
    if (storeFilter !== 'all') {
      filtered = filtered.filter(lead => lead.data.store === storeFilter);
    }

    // Apply completion status filter
    if (completionFilter === 'complete') {
      filtered = filtered.filter(lead => lead.completed);
    } else if (completionFilter === 'incomplete') {
      filtered = filtered.filter(lead => !lead.completed);
    }
    // 'all' shows both complete and incomplete

    // Apply market filter based on active view
    if (activeView !== 'all') {
      const marketMap = {
        california: 'California',
        texas: 'Texas',
        virginia: 'Virginia',
        other: 'Other'
      };
      const targetMarket = marketMap[activeView];
      filtered = filtered.filter(lead => getMarketFromStore(lead.data.store || '') === targetMarket);
    }

    setFilteredLeads(filtered);
  };

  const clearFilters = () => {
    setDateRangeType('today');
    setFromDate('');
    setToDate('');
    setStoreFilter('all');
    setCompletionFilter('incomplete');
    setActiveView('all');
  };

  const handleViewLead = (lead: StoredLead) => {
    setSelectedLead(lead);
    
    if (lead.data.image) {
      const urls = getGoogleDriveImageUrls(lead.data.image);
      setImageUrls(urls);
      setCurrentImageIndex(0);
      setImageLoaded(false);
    } else {
      setImageUrls([]);
    }
    
    setShowLeadDetails(true);
  };

  const handleImageError = () => {
    if (currentImageIndex < imageUrls.length - 1) {
      setCurrentImageIndex(prev => prev + 1);
    } else {
      setImageLoaded(false);
    }
  };

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  const handleTestNotification = async (lead: StoredLead) => {
    setIsTestingNotification(true);
    setTestNotificationResult(null);
    
    try {
      const config = getWebhookConfig();
      if (!config.enabled || !config.managerWebhookUrl) {
        setTestNotificationResult({
          success: false,
          message: 'Webhook notifications not configured. Please set up in Admin > Webhook Settings.'
        });
        return;
      }
      
      const success = await sendOverdueLeadNotification(lead, config);
      setTestNotificationResult({
        success,
        message: success 
          ? 'Test notification sent successfully!' 
          : 'Failed to send test notification. Check webhook configuration.'
      });
    } catch (error) {
      setTestNotificationResult({
        success: false,
        message: `Error sending notification: ${error.message}`
      });
    } finally {
      setIsTestingNotification(false);
      
      // Clear result after 5 seconds
      setTimeout(() => setTestNotificationResult(null), 5000);
    }
  };
  
  const handleCopyLink = async (leadId: string) => {
    const link = `${window.location.origin}/complete-lead/${leadId}`;
    try {
      await navigator.clipboard.writeText(link);
      setLinkCopied(leadId);
      setTimeout(() => setLinkCopied(null), 2000);
    } catch (error) {
      console.error('Failed to copy link:', error);
    }
  };
  
  const handleLaunchLink = (leadId: string) => {
    const link = `${window.location.origin}/complete-lead/${leadId}`;
    window.open(link, '_blank');
  };

  const handleLeadSelection = (leadId: string, checked: boolean) => {
    const newSelection = new Set(selectedLeads);
    if (checked) {
      newSelection.add(leadId);
    } else {
      newSelection.delete(leadId);
    }
    setSelectedLeads(newSelection);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedLeads(new Set(filteredLeads.map(lead => lead.id)));
    } else {
      setSelectedLeads(new Set());
    }
  };

  const handleBulkDelete = async () => {
    if (selectedLeads.size === 0) return;
    
    if (window.confirm(`Are you sure you want to delete ${selectedLeads.size} selected leads? This action cannot be undone.`)) {
      try {
        const { clearAllLeads } = await import('../utils/storage');
        await clearAllLeads(Array.from(selectedLeads));
        await loadLeads();
        setSelectedLeads(new Set());
      } catch (error) {
        console.error('Error deleting leads:', error);
      }
    }
  };

  const exportSelectedLeads = () => {
    const leadsToExport = selectedLeads.size > 0 
      ? filteredLeads.filter(lead => selectedLeads.has(lead.id))
      : filteredLeads;
    
    const csvContent = [
      'License Plate,Store,Market,Lead Type,Time,Created,Age (Minutes),Status,Customer Name,Email,Phone,Zip Code,Notes',
      ...leadsToExport.map(lead => {
        const ageMinutes = Math.floor((Date.now() - new Date(lead.createdAt).getTime()) / (1000 * 60));
        const customerName = lead.customerData ? `${lead.customerData.firstName} ${lead.customerData.lastName}` : '';
        return [
          lead.data.licensePlate || '',
          lead.data.store || '',
          getMarketFromStore(lead.data.store || ''),
          lead.data.leadType || 'Customer',
          lead.data.time ? new Date(lead.data.time).toLocaleString() : '',
          new Date(lead.createdAt).toLocaleString(),
          ageMinutes.toString(),
          lead.completed ? 'Complete' : 'Incomplete',
          customerName,
          lead.customerData?.email || '',
          lead.customerData?.phoneNumber || '',
          lead.customerData?.zipCode || '',
          lead.customerData?.notes || ''
        ].map(field => `"${field}"`).join(',');
      })
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `leads-export-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
  };
  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  // Get unique stores for filter dropdown
  const uniqueStores = Array.from(new Set(allLeads.map(lead => lead.data.store).filter(Boolean))).sort();

  // Calculate market stats
  const marketStats = {
    california: filteredLeads.filter(lead => getMarketFromStore(lead.data.store || '') === 'California').length,
    texas: filteredLeads.filter(lead => getMarketFromStore(lead.data.store || '') === 'Texas').length,
    virginia: filteredLeads.filter(lead => getMarketFromStore(lead.data.store || '') === 'Virginia').length,
    other: filteredLeads.filter(lead => getMarketFromStore(lead.data.store || '') === 'Other').length,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading management dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="ulrich-card rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/admin')}
                className="mr-4 p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
                title="Back to Admin Dashboard"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <img 
                src="/ulrich-logo.png" 
                alt="Ulrich" 
                className="h-10 mr-3"
              />
              <div>
                <h2 className="text-xl font-semibold" style={{ color: '#435B75' }}>Management Dashboard</h2>
                <p className="text-sm text-gray-600 mt-1">
                  Current leads across all markets
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={exportSelectedLeads}
                className="py-2 px-4 rounded-lg font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 flex items-center text-white"
                style={{ backgroundColor: '#748B89', '--tw-ring-color': '#748B89' }}
              >
                <Download className="w-4 h-4 mr-2" />
                Export {selectedLeads.size > 0 ? `(${selectedLeads.size})` : 'All'}
              </button>
              {selectedLeads.size > 0 && (
                <button
                  onClick={handleBulkDelete}
                  className="bg-red-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete ({selectedLeads.size})
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="p-6 border-b border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
              <select
                value={dateRangeType}
                onChange={(e) => setDateRangeType(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="this-week">This Week</option>
                <option value="last-week">Last Week</option>
                <option value="last-month">Last Month</option>
                <option value="custom">Custom Range</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={completionFilter}
                onChange={(e) => setCompletionFilter(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Leads</option>
                <option value="incomplete">Incomplete</option>
                <option value="complete">Complete</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Market</label>
              <select
                value={activeView}
                onChange={(e) => setActiveView(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Markets</option>
                <option value="california">California</option>
                <option value="texas">Texas</option>
                <option value="virginia">Virginia</option>
                <option value="other">Other</option>
              </select>
            </div>
            {dateRangeType === 'custom' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                  <input
                    type="date"
                    value={fromDate}
                    onChange={(e) => setFromDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                  <input
                    type="date"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Store Filter</label>
              <select
                value={storeFilter}
                onChange={(e) => setStoreFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Stores</option>
                {uniqueStores.map(store => (
                  <option key={store} value={store}>{store}</option>
                ))}
              </select>
            </div>
            <div className={`flex items-end ${dateRangeType === 'custom' ? 'md:col-span-1' : 'md:col-span-1'}`}>
              <button
                onClick={clearFilters}
                className="w-full bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center"
              >
                <X className="w-4 h-4 mr-2" />
                Clear Filters
              </button>
            </div>
          </div>
        </div>

        {/* Market Tabs */}
        <div className="flex border-b border-gray-200 overflow-x-auto">
          <button
            onClick={() => setActiveView('all')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors whitespace-nowrap ${
              activeView === 'all'
                ? 'text-white'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
            style={activeView === 'all' ? { borderColor: '#B8906B', color: '#B8906B' } : {}}
          >
            All Markets ({filteredLeads.length})
          </button>
          <button
            onClick={() => setActiveView('california')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors whitespace-nowrap ${
              activeView === 'california'
                ? 'text-white'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
            style={activeView === 'california' ? { borderColor: '#B8906B', color: '#B8906B' } : {}}
          >
            California ({marketStats.california})
          </button>
          <button
            onClick={() => setActiveView('texas')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors whitespace-nowrap ${
              activeView === 'texas'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Texas ({marketStats.texas})
          </button>
          <button
            onClick={() => setActiveView('virginia')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors whitespace-nowrap ${
              activeView === 'virginia'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Virginia ({marketStats.virginia})
          </button>
          <button
            onClick={() => setActiveView('other')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors whitespace-nowrap ${
              activeView === 'other'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Other ({marketStats.other})
          </button>
        </div>

        {/* Stats Summary */}
        <div className="p-6 bg-gray-50">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{filteredLeads.length}</div>
              <div className="text-sm text-gray-600">
                {completionFilter === 'complete' ? 'Complete Leads' : 
                 completionFilter === 'incomplete' ? 'Incomplete Leads' : 'Total Leads'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {filteredLeads.filter(lead => lead.data.leadType === 'Customer' || !lead.data.leadType).length}
              </div>
              <div className="text-sm text-gray-600">Customer Leads</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {filteredLeads.filter(lead => lead.data.leadType && lead.data.leadType !== 'Customer').length}
              </div>
              <div className="text-sm text-gray-600">Other Leads</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {Array.from(new Set(filteredLeads.map(lead => lead.data.store))).length}
              </div>
              <div className="text-sm text-gray-600">Active Stores</div>
            </div>
          </div>
        </div>
      </div>

      {/* Leads Table */}
      <div className="ulrich-card rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold" style={{ color: '#435B75' }}>
            {activeView === 'all' ? 'All Current Leads' : 
             activeView === 'california' ? 'California Leads' :
             activeView === 'texas' ? 'Texas Leads' :
             activeView === 'virginia' ? 'Virginia Leads' : 'Other Market Leads'}
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Showing {filteredLeads.length} {completionFilter === 'all' ? '' : completionFilter} leads
          </p>
        </div>

        {filteredLeads.length === 0 ? (
          <div className="p-12 text-center">
            <Clock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No {completionFilter === 'all' ? '' : completionFilter.charAt(0).toUpperCase() + completionFilter.slice(1)} Leads
            </h3>
            <p className="text-gray-600">
              {allLeads.length === 0 
                ? "No leads found." 
                : "No leads match your current filters."}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <input
                      type="checkbox"
                      checked={selectedLeads.size === filteredLeads.length && filteredLeads.length > 0}
                      onChange={(e) => handleSelectAll(e.target.checked)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    UIN
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Market
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Store
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Lead Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Created
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Age (Minutes)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Notifications
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredLeads.map((lead) => {
                  const ageMinutes = Math.floor((Date.now() - new Date(lead.createdAt).getTime()) / (1000 * 60));
                  const isOverdue = ageMinutes > 45;
                  
                  return (
                    <tr key={lead.id} className={`hover:bg-gray-50 ${isOverdue ? 'bg-red-50' : ''}`}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <input
                          type="checkbox"
                          checked={selectedLeads.has(lead.id)}
                          onChange={(e) => handleLeadSelection(lead.id, e.target.checked)}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium cursor-pointer transition-colors duration-200 hover:underline" 
                             style={{ color: '#435B75' }}
                             onClick={() => handleViewLead(lead)}>
                          {lead.data.licensePlate || 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          getMarketFromStore(lead.data.store || '') === 'California' ? 'text-white' :
                          getMarketFromStore(lead.data.store || '') === 'Texas' ? 'text-white' :
                          getMarketFromStore(lead.data.store || '') === 'Virginia' ? 'text-white' :
                          'bg-gray-100 text-gray-800'
                        }`}
                        style={
                          getMarketFromStore(lead.data.store || '') === 'California' ? { backgroundColor: '#435B75' } :
                          getMarketFromStore(lead.data.store || '') === 'Texas' ? { backgroundColor: '#B8906B' } :
                          getMarketFromStore(lead.data.store || '') === 'Virginia' ? { backgroundColor: '#748B89' } : {}
                        }
                        >
                          {getMarketFromStore(lead.data.store || '')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm cursor-pointer transition-colors duration-200 hover:underline" 
                             style={{ color: '#435B75' }}
                             onClick={() => handleViewLead(lead)}>
                          {lead.data.store || 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          lead.data.leadType === 'Customer' || !lead.data.leadType
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {lead.data.leadType || 'Customer'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-blue-600 hover:text-blue-800 cursor-pointer" onClick={() => handleViewLead(lead)}>
                          {lead.data.time ? formatTimestamp(lead.data.time) : 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-blue-600 hover:text-blue-800 cursor-pointer" onClick={() => handleViewLead(lead)}>
                          {formatTimestamp(lead.createdAt)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className={`text-sm font-medium ${isOverdue ? 'text-red-600' : 'text-gray-900'}`}>
                          {ageMinutes} {isOverdue && '⚠️'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleTestNotification(lead)}
                            disabled={isTestingNotification}
                            className="hover:scale-110 disabled:opacity-50 transition-all duration-200"
                            style={{ color: '#B8906B' }}
                            title="Send test notification"
                          >
                            <Bell className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleCopyLink(lead.id)}
                            className="hover:scale-110 transition-all duration-200"
                            style={{ color: '#435B75' }}
                            title="Copy completion link"
                          >
                            {linkCopied === lead.id ? (
                              <CheckCircle className="w-4 h-4" style={{ color: '#748B89' }} />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                          <button
                            onClick={() => handleLaunchLink(lead.id)}
                            className="hover:scale-110 transition-all duration-200"
                            style={{ color: '#B8906B' }}
                            title="Launch completion link"
                          >
                            <Send className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleViewLead(lead)}
                            className="hover:scale-110 transition-all duration-200"
                            style={{ color: '#435B75' }}
                            title="View details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          {!lead.completed && (
                            <a
                              href={`/complete-lead/${lead.id}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-white py-1 px-3 rounded text-xs font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 flex items-center hover:scale-105"
                              style={{ backgroundColor: '#748B89', '--tw-ring-color': '#748B89' }}
                              title="Complete this lead"
                            >
                              <ExternalLink className="w-3 h-3 mr-1" />
                              Complete
                            </a>
                          )}
                          {lead.completed && (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium text-white"
                                  style={{ backgroundColor: '#748B89' }}>
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Complete
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Test Notification Result */}
      {testNotificationResult && (
        <div className={`fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
          testNotificationResult.success 
            ? 'bg-green-50 border border-green-200' 
            : 'bg-red-50 border border-red-200'
        }`}>
          <div className="flex items-center">
            {testNotificationResult.success ? (
              <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
            ) : (
              <X className="w-5 h-5 text-red-600 mr-2" />
            )}
            <span className={`text-sm font-medium ${
              testNotificationResult.success ? 'text-green-800' : 'text-red-800'
            }`}>
              {testNotificationResult.message}
            </span>
          </div>
        </div>
      )}

      {/* Lead Details Modal */}
      {showLeadDetails && selectedLead && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Lead Details</h3>
                <button
                  onClick={() => {
                    setShowLeadDetails(false);
                    setSelectedLead(null);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Status and Age */}
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-orange-100 text-orange-800">
                  <Clock className="w-4 h-4 mr-1" />
                  Incomplete
                </span>
                <div className="text-sm text-gray-500">
                  Age: {Math.floor((Date.now() - new Date(selectedLead.createdAt).getTime()) / (1000 * 60))} minutes
                </div>
              </div>

              {/* Image */}
              {selectedLead.data.image && imageUrls.length > 0 && (
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Image</h4>
                  <div className="border rounded-lg p-4">
                    {imageLoaded || currentImageIndex < imageUrls.length ? (
                      <img 
                        src={imageUrls[currentImageIndex]} 
                        alt="Lead Image" 
                        className="max-w-full h-auto max-h-64 mx-auto rounded-lg shadow-md"
                        onError={handleImageError}
                        onLoad={handleImageLoad}
                        style={{ display: imageLoaded ? 'block' : 'none' }}
                      />
                    ) : null}
                    
                    {!imageLoaded && currentImageIndex >= imageUrls.length && (
                      <div className="text-center text-gray-500 py-8">
                        <div className="text-4xl mb-2">📷</div>
                        <p>Image could not be loaded</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Lead Information */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Lead Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">License Plate</label>
                    <p className="text-gray-900 mt-1">{selectedLead.data.licensePlate || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Store</label>
                    <p className="text-gray-900 mt-1">{selectedLead.data.store || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Market</label>
                    <p className="text-gray-900 mt-1">{getMarketFromStore(selectedLead.data.store || '')}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Lead Type</label>
                    <p className="text-gray-900 mt-1">{selectedLead.data.leadType || 'Customer'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Time</label>
                    <p className="text-gray-900 mt-1">{formatTimestamp(selectedLead.data.time)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Created</label>
                    <p className="text-gray-900 mt-1">{formatTimestamp(selectedLead.createdAt)}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagementDashboard;