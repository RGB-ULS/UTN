import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Webhook, AlertCircle, FileText, ExternalLink, Activity, User, LogIn, BarChart3 } from 'lucide-react';
import { getActiveUsers } from '../utils/userManagement';
import { safeCheckAndNotifyOverdueLeads } from '../utils/webhookNotifications';
import { processCustomNotifications } from '../utils/customNotifications';
import { getAllLeads } from '../utils/storage';

const WebhookReceiver: React.FC = () => {
  const navigate = useNavigate();
  const [isListening, setIsListening] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastWebhookTime, setLastWebhookTime] = useState<string | null>(null);
  const [showQuickLogin, setShowQuickLogin] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Check if already logged in
  const isLoggedIn = sessionStorage.getItem('salesRepAuthenticated') === 'true';
  const loggedInName = sessionStorage.getItem('salesRepName');

  useEffect(() => {
    // Load available users for quick login
    const loadUsers = async () => {
      const users = await getActiveUsers();
      setAvailableUsers(users);
    };
    loadUsers();

    // Check for webhook data immediately
    const checkForWebhookData = () => {
      try {
        const webhookData = sessionStorage.getItem('webhookData');
        if (webhookData) {
          console.log('Webhook data found, redirecting to form');
          navigate('/lead-form');
          return;
        }
      } catch (err) {
        console.error('Error processing webhook data:', err);
        setError('Error processing webhook data');
      }
    };

    // Check immediately
    checkForWebhookData();

    // Set up polling for webhook data
    const interval = setInterval(() => {
      checkForWebhookData();
      
      // Update last webhook time if available
      const logs = localStorage.getItem('webhookLogs');
      if (logs) {
        try {
          const parsedLogs = JSON.parse(logs);
          if (parsedLogs.length > 0) {
            setLastWebhookTime(parsedLogs[0].timestamp);
          }
        } catch (e) {
          // Ignore parsing errors
        }
      }
    }, 2000);

    // Set up periodic check for overdue leads (every 5 minutes)
    // Periodic overdue lead checking (every 2 minutes for testing)
    const overdueCheckInterval = setInterval(async () => {
      try {
        console.log('Starting periodic overdue lead check...');
        const leads = await getAllLeads();
        console.log(`Retrieved ${leads.length} leads for overdue check`);
        await safeCheckAndNotifyOverdueLeads(leads);
        
        // Also process custom notifications
        console.log('Processing custom notifications...');
        await processCustomNotifications(leads);
        
        console.log('Completed periodic overdue lead check');
      } catch (error) {
        console.error('Error checking for overdue leads:', error);
      }
    }, 2 * 60 * 1000); // 2 minutes for testing

    return () => {
      clearInterval(interval);
      clearInterval(overdueCheckInterval);
    };
  }, [navigate]);

  const handleQuickLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !password) return;

    setIsLoggingIn(true);
    setLoginError('');

    try {
      const { authenticateSalesRep } = await import('../utils/userManagement');
      const result = await authenticateSalesRep(selectedUser.email, password);
      
      if (result.success && result.user) {
        sessionStorage.setItem('salesRepAuthenticated', 'true');
        sessionStorage.setItem('salesRepEmail', result.user.email);
        sessionStorage.setItem('salesRepName', result.user.name);
        setShowQuickLogin(false);
        setPassword('');
        setSelectedUser(null);
      } else {
        setLoginError(result.error || 'Login failed');
      }
    } catch (error) {
      setLoginError('Login error occurred');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('salesRepAuthenticated');
    sessionStorage.removeItem('salesRepEmail');
    sessionStorage.removeItem('salesRepName');
    setShowQuickLogin(false);
  };

  const handleManualEntry = () => {
    navigate('/lead-form');
  };

  const handleAdminDashboard = () => {
    navigate('/admin');
  };

  const handleSalesPortal = () => {
    navigate('/sales-login');
  };

  return (
    <div className="min-h-screen ulrich-gradient-light flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto text-center w-full">
        <div className="ulrich-card rounded-2xl shadow-xl p-6 sm:p-8">
          {/* Ulrich Logo */}
          <div className="mb-4 sm:mb-6">
            <img 
              src="/ulrich-logo.png"
              alt="Ulrich - Built for You. Made for Life." 
              className="h-24 sm:h-32 mx-auto mb-3 sm:mb-4"
            />
            <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-full mb-2" style={{ backgroundColor: 'rgba(184, 144, 107, 0.1)' }}>
              <Webhook className="w-6 h-6 sm:w-8 sm:h-8" style={{ color: '#B8906B' }} />
            </div>
          </div>
          
          <h1 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4" style={{ color: '#435B75' }}>Lead Management System</h1>

          {/* Login Status */}
          {isLoggedIn ? (
            <div className="mb-4 sm:mb-6 p-3 sm:p-4 rounded-lg" style={{ backgroundColor: 'rgba(116, 139, 137, 0.1)', border: '1px solid rgba(116, 139, 137, 0.2)' }}>
              <div className="flex items-center justify-center mb-2 flex-wrap">
                <User className="w-4 h-4 sm:w-5 sm:h-5 mr-2" style={{ color: '#748B89' }} />
                <span className="font-medium text-sm sm:text-base text-center" style={{ color: '#435B75' }}>Logged in as {loggedInName}</span>
              </div>
              <button
                onClick={handleLogout}
                className="text-xs sm:text-sm underline hover:no-underline transition-all duration-200"
                style={{ color: '#748B89' }}
              >
                Logout
              </button>
            </div>
          ) : (
            <div className="mb-4 sm:mb-6 p-3 sm:p-4 rounded-lg" style={{ backgroundColor: 'rgba(67, 91, 117, 0.1)', border: '1px solid rgba(67, 91, 117, 0.2)' }}>
              <div className="flex items-center justify-center mb-3 flex-wrap">
                <LogIn className="w-4 h-4 sm:w-5 sm:h-5 mr-2" style={{ color: '#435B75' }} />
                <span className="font-medium text-sm sm:text-base" style={{ color: '#435B75' }}>Sales Rep Quick Login</span>
              </div>
              {!showQuickLogin ? (
                <button
                  onClick={() => setShowQuickLogin(true)}
                  className="btn-ulrich-secondary py-2 px-4 rounded-lg font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 text-sm sm:text-base w-full sm:w-auto"
                  style={{ '--tw-ring-color': '#435B75' }}
                >
                  Login as Sales Rep
                </button>
              ) : (
                <form onSubmit={handleQuickLogin} className="space-y-2 sm:space-y-3">
                  <select
                    value={selectedUser?.id || ''}
                    onChange={(e) => {
                      const user = availableUsers.find(u => u.id === e.target.value);
                      setSelectedUser(user || null);
                      setLoginError('');
                    }}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:border-transparent text-sm transition-all duration-200 min-h-[44px]"
                    style={{ borderColor: 'rgba(67, 91, 117, 0.3)', '--tw-ring-color': '#435B75' }}
                    required
                  >
                    <option value="">Select your name</option>
                    {availableUsers.map(user => (
                      <option key={user.id} value={user.id}>
                        {user.name}
                      </option>
                    ))}
                  </select>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setLoginError('');
                    }}
                    placeholder="Password"
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:border-transparent text-sm transition-all duration-200 min-h-[44px]"
                    style={{ borderColor: 'rgba(67, 91, 117, 0.3)', '--tw-ring-color': '#435B75' }}
                    required
                  />
                  {loginError && (
                    <p className="text-red-600 text-xs sm:text-sm">{loginError}</p>
                  )}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      type="submit"
                      disabled={isLoggingIn || !selectedUser || !password}
                      className="flex-1 py-3 px-3 rounded-lg font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 text-sm text-white min-h-[44px]"
                      style={{ backgroundColor: '#748B89', '--tw-ring-color': '#748B89' }}
                    >
                      {isLoggingIn ? 'Logging in...' : 'Login'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowQuickLogin(false);
                        setPassword('');
                        setSelectedUser(null);
                        setLoginError('');
                      }}
                      className="bg-gray-600 text-white py-3 px-3 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 text-sm min-h-[44px]"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
          
          {error ? (
            <div className="mb-4 sm:mb-6 p-3 sm:p-4 bg-red-50 rounded-lg border border-red-200">
              <div className="flex items-center justify-center text-red-700 mb-2 flex-wrap">
                <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                Error
              </div>
              <p className="text-xs sm:text-sm text-red-600">{error}</p>
            </div>
          ) : (
            <>
              {isListening ? (
                <div className="mb-4 sm:mb-6">
                  <div className="flex items-center justify-center mb-2 flex-wrap">
                    <div className="animate-pulse w-2 h-2 sm:w-3 sm:h-3 rounded-full mr-2" style={{ backgroundColor: '#748B89' }}></div>
                    <span className="font-medium text-sm sm:text-base" style={{ color: '#748B89' }}>Listening for webhooks...</span>
                  </div>
                  <p className="text-gray-600 text-xs sm:text-sm mb-3 sm:mb-4 px-2">
                    Waiting for data from your n8n workflow. The form will automatically populate when data is received.
                  </p>
                  {lastWebhookTime && (
                    <p className="text-xs text-gray-500 px-2">
                      Last webhook: {new Date(lastWebhookTime).toLocaleString()}
                    </p>
                  )}
                </div>
              ) : (
                <div className="mb-3 sm:mb-4">
                  <p className="text-gray-600 text-sm sm:text-base">Ready to receive webhook data</p>
                </div>
              )}
            </>
          )}

          <div className="space-y-2 sm:space-y-3">
            <button
              onClick={handleManualEntry}
              className="w-full btn-ulrich-primary py-4 px-6 rounded-lg font-semibold focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center text-sm sm:text-base min-h-[48px]"
              style={{ '--tw-ring-color': '#B8906B' }}
            >
              <FileText className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
              Fill Out Lead Form
            </button>
            
            {isLoggedIn && (
              <button
                onClick={() => navigate('/sales-dashboard')}
                className="w-full btn-ulrich-secondary py-3 px-6 rounded-lg font-semibold focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center text-sm sm:text-base min-h-[44px]"
                style={{ '--tw-ring-color': '#435B75' }}
              >
                <User className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                View My Leads Dashboard
              </button>
            )}
            
            <p className="text-xs text-gray-500 text-center px-2">
              {isLoggedIn ? 'You can now fill forms with your name auto-selected' : 'Login as a sales rep to see your assigned leads'}
            </p>
          </div>

          <div className="mt-4 sm:mt-6 pt-3 sm:pt-4 border-t border-gray-200">
            <div className="flex justify-center space-x-4 sm:space-x-6 flex-wrap gap-y-2">
              {!isLoggedIn && (
                <button
                  onClick={handleSalesPortal}
                  className="inline-flex items-center text-xs sm:text-sm underline hover:no-underline transition-all duration-200"
                  style={{ color: '#748B89' }}
                >
                  <User className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                  Sales Rep Portal
                </button>
              )}
              <button
                onClick={handleAdminDashboard}
                className="inline-flex items-center text-xs sm:text-sm underline hover:no-underline transition-all duration-200"
                style={{ color: '#435B75' }}
              >
                <Activity className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                Admin Dashboard
              </button>
            </div>
          </div>

          <div className="mt-6 sm:mt-8 p-3 sm:p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-gray-700 mb-2 text-sm sm:text-base">For Developers:</h3>
            <div className="space-y-2 text-left">
              <div>
                <p className="text-xs text-gray-600 mb-1">Webhook Endpoint:</p>
                <code className="text-xs bg-white p-2 rounded border block break-all leading-relaxed">
                  POST https://nrzfuqikeuyhmdhaagpo.supabase.co/functions/v1/webhook
                </code>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Test Page:</p>
                <a 
                  href="/webhook-test.html" 
                  target="_blank"
                  className="text-xs underline hover:no-underline transition-all duration-200 break-all"
                  style={{ color: '#435B75' }}
                >
                  Open Webhook Test Page
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WebhookReceiver;