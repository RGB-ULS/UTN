import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SalesRepLogin from './SalesRepLogin';

interface ProtectedSalesRouteProps {
  children: React.ReactNode;
}

const ProtectedSalesRoute: React.FC<ProtectedSalesRouteProps> = ({ children }) => {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAuth = () => {
      const authenticated = sessionStorage.getItem('salesRepAuthenticated') === 'true';
      const email = sessionStorage.getItem('salesRepEmail');
      
      if (authenticated && email) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }
      setIsLoading(false);
    };

    checkAuth();
  }, []);

  const handleLogin = (userEmail: string, userName: string) => {
    setIsAuthenticated(true);
    navigate('/sales-dashboard');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <SalesRepLogin onLogin={handleLogin} />;
  }

  return <>{children}</>;
};

export default ProtectedSalesRoute;