import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle, RotateCcw, Home } from 'lucide-react';
import { FormSubmission } from '../types';
import { getGoogleDriveImageUrls } from '../utils/imageUtils';

const ConfirmationPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const submissionData = location.state?.submissionData as FormSubmission;

  // Image loading state
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    console.log('ConfirmationPage received submissionData:', submissionData);
    if (submissionData?.image) {
      const urls = getGoogleDriveImageUrls(submissionData.image);
      setImageUrls(urls);
    }
  }, [submissionData]);

  const handleImageError = () => {
    if (currentImageIndex < imageUrls.length - 1) {
      setCurrentImageIndex(prev => prev + 1);
    } else {
      setImageLoaded(false);
    }
  };

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  if (!submissionData) {
    console.error('No submission data found, redirecting to home');
    navigate('/');
    return null;
  }

  const handleNewSubmission = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Submission Complete!
          </h1>
          <p className="text-gray-600">
            Your lead has been successfully recorded and saved to Google Sheets.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 space-y-6">
          {/* Success Status */}
          <div className="text-center p-4 rounded-lg bg-green-50">
            <div className="flex items-center justify-center text-green-600">
              <CheckCircle className="w-5 h-5 mr-2" />
              Successfully saved to Google Sheets
            </div>
          </div>

          {/* Lead Information Summary */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Submission Summary</h3>
            
            {/* Image */}
            {submissionData.image && imageUrls.length > 0 && (
              <div className="mb-4">
                <p className="text-sm font-medium text-gray-700 mb-2">Image:</p>
                <div className="border rounded-lg p-2">
                  {imageLoaded || currentImageIndex < imageUrls.length ? (
                    <img 
                      src={imageUrls[currentImageIndex]} 
                      alt="Lead Image" 
                      className="max-w-full h-auto max-h-48 mx-auto rounded-lg shadow-md"
                      onError={handleImageError}
                      onLoad={handleImageLoad}
                      style={{ display: imageLoaded ? 'block' : 'none' }}
                    />
                  ) : null}
                  
                  {!imageLoaded && currentImageIndex >= imageUrls.length && (
                    <div className="text-center text-gray-500 py-8">
                      <div className="text-4xl mb-2">📷</div>
                      <p>Image could not be loaded</p>
                      <p className="text-xs mt-2">Google Drive image may require public access</p>
                    </div>
                  )}
                  
                  <details className="mt-2">
                    <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-700">
                      Show image URLs (trying {currentImageIndex + 1} of {imageUrls.length})
                    </summary>
                    <div className="mt-2 space-y-2">
                      <p className="text-xs text-gray-400 break-all bg-gray-50 p-2 rounded">
                        <strong>Original:</strong> {submissionData.image}
                      </p>
                      {imageUrls.map((url, index) => (
                        <p key={index} className={`text-xs break-all p-2 rounded ${
                          index === currentImageIndex ? 'bg-blue-50 text-blue-700' : 'bg-gray-50 text-gray-400'
                        }`}>
                          <strong>URL {index + 1}:</strong> {url}
                          {index === currentImageIndex && ' (current)'}
                        </p>
                      ))}
                    </div>
                  </details>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-gray-700">License Plate:</p>
                <p className="text-gray-900">{submissionData.licensePlate}</p>
              </div>
              <div>
                <p className="font-medium text-gray-700">Store:</p>
                <p className="text-gray-900">{submissionData.store}</p>
              </div>
              <div>
                <p className="font-medium text-gray-700">Time:</p>
                <p className="text-gray-900">{new Date(submissionData.time).toLocaleString()}</p>
              </div>
              <div>
                <p className="font-medium text-gray-700">Lead Type:</p>
                <p className="text-gray-900">{submissionData.leadType}</p>
              </div>
              {submissionData.repEmail && (
                <div>
                  <p className="font-medium text-gray-700">Sales Rep:</p>
                  <p className="text-gray-900">{submissionData.repEmail}</p>
                </div>
              )}
            </div>

            {/* Customer Details */}
            {submissionData.customerData && (
              <div className="mt-6 pt-4 border-t">
                <h4 className="font-semibold text-gray-900 mb-3">Customer Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium text-gray-700">Name:</p>
                    <p className="text-gray-900">
                      {submissionData.customerData.firstName} {submissionData.customerData.lastName}
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700">Email:</p>
                    <p className="text-gray-900">{submissionData.customerData.email}</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700">Phone:</p>
                    <p className="text-gray-900">{submissionData.customerData.phoneNumber}</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700">Zip Code:</p>
                    <p className="text-gray-900">{submissionData.customerData.zipCode}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t">
            <button
              onClick={handleNewSubmission}
              className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 flex items-center justify-center"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              New Submission
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationPage;