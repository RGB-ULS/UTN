import React, { useState, useEffect } from 'react';
import { Bell, Save, TestTube, Check, X, AlertCircle, Settings, Clock, Link } from 'lucide-react';
import { getWebhookConfig, saveWebhookConfig, WebhookConfig, checkAndNotifyOverdueLeads, clearNotificationHistory, emergencyStopWebhooks, isEmergencyStopActive, clearEmergencyStop } from '../utils/webhookNotifications';
import { getAllLeads } from '../utils/storage';

const WebhookSettings: React.FC = () => {
  const [config, setConfig] = useState<WebhookConfig>({
    managerWebhookUrl: '',
    overdueThresholdMinutes: 45,
    enabled: false
  });
  
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [saveResult, setSaveResult] = useState<{ success: boolean; message: string } | null>(null);
  const [emergencyStopActive, setEmergencyStopActive] = useState(false);

  useEffect(() => {
    const loadedConfig = getWebhookConfig();
    setConfig(loadedConfig);
    setEmergencyStopActive(isEmergencyStopActive());
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    setSaveResult(null);
    
    try {
      console.log('Saving webhook config:', config);
      
      // If enabling notifications for the first time or re-enabling, set monitoring start time
      const currentConfig = getWebhookConfig();
      const updatedConfig = {
        ...config,
        monitoringStartTime: config.enabled && !currentConfig.enabled 
          ? new Date().toISOString() 
          : currentConfig.monitoringStartTime
      };
      
      console.log('Final config to save:', updatedConfig);
      saveWebhookConfig(updatedConfig);
      
      // Update local state to match what was saved
      setConfig(updatedConfig);
      
      setSaveResult({ success: true, message: 'Webhook settings saved successfully!' });
      
      // Clear the success message after 3 seconds
      setTimeout(() => setSaveResult(null), 3000);
    } catch (error) {
      console.error('Error saving webhook settings:', error);
      setSaveResult({ success: false, message: 'Failed to save webhook settings' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleTest = async () => {
    if (!config.managerWebhookUrl.trim()) {
      setTestResult({ success: false, message: 'Please enter a webhook URL first' });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    const testPayload = {
      type: 'lead_overdue',
      leadId: 'test_lead_123',
      licensePlate: 'TEST123',
      store: 'Test Store',
      createdAt: new Date().toISOString(),
      minutesOverdue: config.overdueThresholdMinutes + 5,
      shareableLink: `${window.location.origin}/complete-lead/test_lead_123`
    };

    try {
      console.log('Testing webhook URL:', config.managerWebhookUrl);
      console.log('Test payload:', testPayload);
      
      // Try with different fetch modes to handle CORS
      let response;
      let errorMessage = '';
      
      try {
        // First try with CORS mode
        response = await fetch(config.managerWebhookUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(testPayload),
          mode: 'cors'
        });
      } catch (corsError) {
        console.log('CORS mode failed, trying no-cors mode:', corsError);
        errorMessage = corsError.message;
        
        try {
          // Try with no-cors mode (for services that don't support CORS)
          response = await fetch(config.managerWebhookUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(testPayload),
            mode: 'no-cors'
          });
        } catch (noCorsError) {
          console.log('No-cors mode also failed:', noCorsError);
          throw new Error(`Network error: ${corsError.message}. This might be due to CORS restrictions or the webhook URL being unreachable.`);
        }
      }

      // Handle response based on mode
      if (response.type === 'opaque') {
        // no-cors mode - we can't read the response but no error means it likely worked
        setTestResult({ 
          success: true, 
          message: 'Test webhook sent successfully! (Note: Response details unavailable due to CORS restrictions, but the request was sent)' 
        });
      } else if (response.ok) {
        // cors mode - we can read the response
        setTestResult({ success: true, message: 'Test webhook sent successfully!' });
      } else {
        // cors mode with error
        const responseText = await response.text().catch(() => 'Unable to read response');
        setTestResult({ 
          success: false, 
          message: `Test failed: ${response.status} ${response.statusText}. Response: ${responseText}` 
        });
      }
    } catch (error) {
      console.error('Webhook test error:', error);
      
      let errorMsg = error.message;
      
      // Provide helpful error messages for common issues
      if (errorMsg.includes('Failed to fetch')) {
        errorMsg = `Failed to reach webhook URL. This could be due to:
        • CORS restrictions (the webhook service needs to allow cross-origin requests)
        • Network connectivity issues
        • Invalid or unreachable URL
        • The webhook service is down
        
        For Zapier webhooks, this is normal - Zapier doesn't support CORS for security, but the webhook will still work in production.`;
      } else if (errorMsg.includes('NetworkError')) {
        errorMsg = 'Network error - check if the webhook URL is correct and reachable';
      }
      
      setTestResult({ success: false, message: errorMsg });
    } finally {
      setIsTesting(false);
    }
  };

  const handleCheckNow = async () => {
    try {
      console.log('Manual check triggered with current config:', config);
      const leads = await getAllLeads();
      console.log(`Manually checking ${leads.length} leads for overdue notifications`);
      await checkAndNotifyOverdueLeads(leads);
      setTestResult({ success: true, message: 'Checked for overdue leads and sent notifications if needed' });
    } catch (error) {
      console.error('Error in manual check:', error);
      setTestResult({ success: false, message: `Error checking leads: ${error.message}` });
    }
  };

  const handleClearHistory = () => {
    clearNotificationHistory();
    setTestResult({ success: true, message: 'Notification history cleared - all leads can be notified again' });
  };

  const handleEmergencyStop = () => {
    console.log('🚨 EMERGENCY STOP BUTTON CLICKED');
    emergencyStopWebhooks();
    setEmergencyStopActive(true);
    
    // Also disable the config immediately in state
    setConfig(prev => ({ ...prev, enabled: false }));
    
    setTestResult({ 
      success: true, 
      message: '🚨 EMERGENCY STOP ACTIVATED - All webhook notifications stopped immediately! Page will refresh in 2 seconds...' 
    });
    
    // Force page refresh to ensure new state takes effect
    setTimeout(() => {
      window.location.reload();
    }, 2000);
  };

  const handleClearEmergencyStop = () => {
    clearEmergencyStop();
    setEmergencyStopActive(false);
    setTestResult({ success: true, message: '✅ Emergency stop cleared - webhooks can be re-enabled' });
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center">
            <Bell className="w-6 h-6 text-blue-600 mr-3" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Webhook Notifications</h2>
              <p className="text-sm text-gray-600 mt-1">
                Configure automatic notifications for overdue leads
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Enable/Disable Toggle */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <h3 className="font-medium text-gray-900">Enable Notifications</h3>
              <p className="text-sm text-gray-600">
                Turn on automatic webhook notifications for overdue leads
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={config.enabled}
                onChange={(e) => setConfig({ ...config, enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          {/* Webhook URL */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Link className="w-4 h-4 mr-2" />
              Manager Webhook URL *
            </label>
            <input
              type="url"
              value={config.managerWebhookUrl}
              onChange={(e) => setConfig({ ...config, managerWebhookUrl: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="https://your-webhook-endpoint.com/notifications"
            />
            <p className="text-xs text-gray-500 mt-1">
              The webhook URL where overdue lead notifications will be sent
            </p>
          </div>

          {/* Threshold Minutes */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Clock className="w-4 h-4 mr-2" />
              Overdue Threshold (Minutes)
            </label>
            <input
              type="number"
              min="1"
              max="1440"
              value={config.overdueThresholdMinutes}
              onChange={(e) => {
                const value = parseInt(e.target.value);
                if (!isNaN(value) && value > 0) {
                  setConfig({ ...config, overdueThresholdMinutes: value });
                }
              }}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <p className="text-xs text-gray-500 mt-1">
              Send notification when a lead has been unfilled for this many minutes
            </p>
          </div>

          {/* Webhook Payload Example */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Webhook Payload Example</h3>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
              <pre className="text-xs text-gray-600 overflow-x-auto">
{`{
  "type": "lead_overdue",
  "leadId": "lead_1234567890_abc123",
  "licensePlate": "ABC123",
  "store": "Downtown Branch",
  "createdAt": "2025-01-08T10:30:00Z",
  "minutesOverdue": 47,
  "shareableLink": "https://your-app.com/complete-lead/lead_1234567890_abc123"
}`}
              </pre>
            </div>
            <div className="mt-4 space-y-3">
              <h4 className="text-sm font-medium text-gray-700">Payload Field Descriptions:</h4>
              <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div>
                    <code className="bg-gray-100 px-2 py-1 rounded">type</code>
                    <p className="text-gray-600 mt-1">Always "lead_overdue" for these notifications</p>
                  </div>
                  <div>
                    <code className="bg-gray-100 px-2 py-1 rounded">leadId</code>
                    <p className="text-gray-600 mt-1">Unique identifier for the lead</p>
                  </div>
                  <div>
                    <code className="bg-gray-100 px-2 py-1 rounded">licensePlate</code>
                    <p className="text-gray-600 mt-1">Vehicle license plate number</p>
                  </div>
                  <div>
                    <code className="bg-gray-100 px-2 py-1 rounded">store</code>
                    <p className="text-gray-600 mt-1">Store location where lead originated</p>
                  </div>
                  <div>
                    <code className="bg-gray-100 px-2 py-1 rounded">createdAt</code>
                    <p className="text-gray-600 mt-1">ISO timestamp when lead was created</p>
                  </div>
                  <div>
                    <code className="bg-gray-100 px-2 py-1 rounded">minutesOverdue</code>
                    <p className="text-gray-600 mt-1">How many minutes past the threshold</p>
                  </div>
                </div>
                <div className="pt-2 border-t">
                  <code className="bg-blue-100 px-2 py-1 rounded text-blue-800">shareableLink</code>
                  <p className="text-gray-600 mt-1">
                    Turn on automatic webhook notifications for overdue leads (only monitors new leads from this point forward)
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Integration Examples */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Integration Examples</h3>
            <div className="space-y-4">
              
              {/* Slack Example */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="text-sm font-semibold text-green-800 mb-2">📱 Slack Integration</h4>
                <p className="text-sm text-green-700 mb-2">
                  Use Slack's Incoming Webhooks to send alerts to a channel:
                </p>
                <pre className="text-xs bg-white p-3 rounded border overflow-x-auto">
{`// Slack webhook endpoint processes the payload
{
  "text": "🚨 Overdue Lead Alert",
  "blocks": [
    {
      "type": "section",
      "text": {
        "type": "mrkdwn",
        "text": "*Lead ABC123* at Downtown Branch is overdue by 47 minutes"
      }
    },
    {
      "type": "actions",
      "elements": [
        {
          "type": "button",
          "text": { "type": "plain_text", "text": "Complete Lead" },
          "url": "https://your-app.com/complete-lead/lead_123"
        }
      ]
    }
  ]
}`}
                </pre>
              </div>

              {/* Email Example */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="text-sm font-semibold text-blue-800 mb-2">📧 Email Integration</h4>
                <p className="text-sm text-blue-700 mb-2">
                  Send email alerts using services like SendGrid, Mailgun, or SMTP:
                </p>
                <pre className="text-xs bg-white p-3 rounded border overflow-x-auto">
{`// Email service processes webhook
{
  "to": "manager@dealership.com",
  "subject": "Overdue Lead: ABC123",
  "html": "<p>Lead <strong>ABC123</strong> at Downtown Branch has been waiting for 47 minutes.</p><a href='https://your-app.com/complete-lead/lead_123'>Complete Lead Now</a>"
}`}
                </pre>
              </div>

              {/* Teams Example */}
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <h4 className="text-sm font-semibold text-purple-800 mb-2">💬 Microsoft Teams Integration</h4>
                <p className="text-sm text-purple-700 mb-2">
                  Send adaptive cards to Teams channels:
                </p>
                <pre className="text-xs bg-white p-3 rounded border overflow-x-auto">
{`// Teams webhook processes payload
{
  "@type": "MessageCard",
  "summary": "Overdue Lead Alert",
  "themeColor": "FF6B35",
  "sections": [{
    "activityTitle": "🚨 Lead Overdue",
    "activitySubtitle": "ABC123 at Downtown Branch",
    "facts": [
      { "name": "Minutes Overdue:", "value": "47" },
      { "name": "Created:", "value": "2025-01-08T10:30:00Z" }
    ]
  }],
  "potentialAction": [{
    "@type": "OpenUri",
    "name": "Complete Lead",
    "targets": [{ "os": "default", "uri": "https://your-app.com/complete-lead/lead_123" }]
  }]
}`}
                </pre>
              </div>

              {/* Custom API Example */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <h4 className="text-sm font-semibold text-orange-800 mb-2">🔧 Custom API Integration</h4>
                <p className="text-sm text-orange-700 mb-2">
                  Process the webhook in your own system:
                </p>
                <pre className="text-xs bg-white p-3 rounded border overflow-x-auto">
{`// Your API endpoint receives the webhook
app.post('/webhook/overdue-leads', (req, res) => {
  const { leadId, licensePlate, store, minutesOverdue, shareableLink } = req.body;
  
  // Log to your system
  console.log(\`Lead \${licensePlate} at \${store} is \${minutesOverdue} minutes overdue\`);
  
  // Send to your notification system
  notificationService.send({
    type: 'overdue_lead',
    message: \`Lead \${licensePlate} needs attention\`,
    link: shareableLink
  });
  
  res.status(200).send('OK');
});`}
                </pre>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSaving ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              Save Settings
            </button>

            <button
              onClick={handleTest}
              disabled={isTesting || !config.managerWebhookUrl.trim()}
              className="bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isTesting ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <TestTube className="w-4 h-4 mr-2" />
              )}
              Send Test
            </button>

            <button
              onClick={handleCheckNow}
              disabled={!config.enabled || emergencyStopActive}
              className="bg-orange-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Bell className="w-4 h-4 mr-2" />
              Check Now
            </button>

            <button
              onClick={handleClearHistory}
              className="bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
            >
              <X className="w-4 h-4 mr-2" />
              Clear Notification History
            </button>

            {!emergencyStopActive ? (
              <button
                onClick={handleEmergencyStop}
                className="bg-red-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
              >
                <AlertCircle className="w-4 h-4 mr-2" />
                🚨 EMERGENCY STOP
              </button>
            ) : (
              <button
                onClick={handleClearEmergencyStop}
                className="bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
              >
                <AlertCircle className="w-4 h-4 mr-2" />
                ✅ Clear Emergency Stop
              </button>
            )}
          </div>

          {/* Results */}
          {saveResult && (
            <div className={`p-4 rounded-lg ${
              saveResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
            }`}>
              <div className="flex items-center">
                {saveResult.success ? (
                  <Check className="w-5 h-5 text-green-600 mr-2" />
                ) : (
                  <X className="w-5 h-5 text-red-600 mr-2" />
                )}
                <span className={`text-sm font-medium ${
                  saveResult.success ? 'text-green-800' : 'text-red-800'
                }`}>
                  {saveResult.message}
                </span>
              </div>
            </div>
          )}

          {testResult && (
            <div className={`p-4 rounded-lg ${
              testResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
            }`}>
              <div className="flex items-center">
                {testResult.success ? (
                  <Check className="w-5 h-5 text-green-600 mr-2" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
                )}
                <span className={`text-sm font-medium ${
                  testResult.success ? 'text-green-800' : 'text-red-800'
                }`}>
                  {testResult.message}
                </span>
              </div>
            </div>
          )}

          {/* How it Works */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-900 mb-2">How It Works</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• System automatically checks for overdue leads every few minutes</li>
              <li>• Only monitors leads created AFTER you enable notifications</li>
              <li>• When a lead exceeds the threshold time, a webhook notification is sent</li>
              <li>• Each lead is only notified once to avoid spam (until history is cleared)</li>
              <li>• Notifications include lead details and a direct link to complete the lead</li>
              <li>• Use "Check Now" to manually trigger a check for testing</li>
              <li>• Use "Clear Notification History" to reset and allow re-notifications</li>
            </ul>
          </div>
          
          {/* Troubleshooting */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 className="text-sm font-medium text-yellow-900 mb-2">⚠️ Testing Limitations</h3>
            <div className="text-sm text-yellow-800 space-y-2">
              <p><strong>If "Send Test" fails with "Failed to fetch":</strong></p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><strong>Zapier webhooks:</strong> This is normal! Zapier blocks browser tests for security, but production webhooks work fine</li>
                <li><strong>Other services:</strong> The webhook service may need to enable CORS (cross-origin requests)</li>
                <li><strong>Local testing:</strong> Use tools like ngrok to expose local servers</li>
              </ul>
              <p className="mt-2"><strong>✅ Production webhooks will work even if tests fail!</strong></p>
              <p>The automatic overdue notifications bypass browser restrictions and will reach your webhook successfully.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WebhookSettings;