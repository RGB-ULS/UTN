import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import WebhookReceiver from './components/WebhookReceiver';
import MainForm from './components/MainForm';
import ConfirmationPage from './components/ConfirmationPage';
import AdminDashboard from './components/AdminDashboard';
import LeadCompletion from './components/LeadCompletion';
import LeadCompleted from './components/LeadCompleted';
import SalesRepLogin from './components/SalesRepLogin';
import SalesRepDashboard from './components/SalesRepDashboard';
import ProtectedSalesRoute from './components/ProtectedSalesRoute';
import ManagementDashboard from './components/ManagementDashboard';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<WebhookReceiver />} />
        <Route path="/lead-form" element={<MainForm />} />
        <Route path="/confirmation" element={<ConfirmationPage />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/complete-lead/:leadId" element={<LeadCompletion />} />
        <Route path="/lead-completed" element={<LeadCompleted />} />
        <Route path="/sales-login" element={<SalesRepLogin onLogin={() => {}} />} />
        <Route path="/sales-dashboard" element={
          <ProtectedSalesRoute>
            <SalesRepDashboard />
          </ProtectedSalesRoute>
        } />
        <Route path="/admin/management" element={<ManagementDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;