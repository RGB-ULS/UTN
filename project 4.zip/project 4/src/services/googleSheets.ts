import { FormSubmission } from '../types';

// Google Sheets configuration
const GOOGLE_SHEETS_CONFIG = {
  WEB_APP_URL: 'https://script.google.com/macros/s/AKfycbzGAE8L1PW3HzEXu_EYHPkfgIM9n1YKqa5csiAIT0982qLUt2ZUed6JoXuYHM1LrB2j6g/exec',
  SPREADSHEET_ID: '1f9ASKmDLoJNTAs85NMUL896IMFLm5m5MycZ5Pz199Bc',
  SHEET_NAME: 'Leads',
  API_KEY: '',
};

// Submit via Google Apps Script Web App (Primary method)
const submitViaWebApp = async (data: FormSubmission): Promise<{ success: boolean; error?: string }> => {
  try {
    const webAppUrl = GOOGLE_SHEETS_CONFIG.WEB_APP_URL;
    
    if (!webAppUrl) {
      console.warn('Google Web App URL not configured');
      return { success: false, error: 'Google Web App URL not configured' };
    }

    const payload = {
      licensePlate: data.licensePlate,
      store: data.store,
      time: data.time,
      leadType: data.leadType,
      repEmail: data.repEmail || '',
      firstName: data.customerData?.firstName || '',
      lastName: data.customerData?.lastName || '',
      email: data.customerData?.email || '',
      phoneNumber: data.customerData?.phoneNumber || '',
      zipCode: data.customerData?.zipCode || '',
      imageUrl: data.image || '',
      notes: data.notes || '',
      timestamp: new Date().toISOString()
    };

    console.log('Google Sheets payload:', JSON.stringify(payload, null, 2));
    console.log('Submitting to URL:', webAppUrl);
    
    // Also store locally for backup
    const existingSubmissions = JSON.parse(localStorage.getItem('successfulSubmissions') || '[]');
    existingSubmissions.push({
      ...data,
      submittedAt: new Date().toISOString(),
      status: 'submitted',
      payload: payload
    });
    localStorage.setItem('successfulSubmissions', JSON.stringify(existingSubmissions));
    console.log('Stored submission locally as backup:', existingSubmissions.length, 'total submissions');
    
    // Use no-cors mode directly with JSON payload
    const response = await fetch(webAppUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      mode: 'no-cors'
    });

    console.log('Google Sheets no-cors response sent');
    console.log('Response type:', response.type);
    
    // With no-cors mode, we can't read the response, but if no error was thrown, it likely succeeded
    console.log('Google Sheets submission completed (no-cors mode)');
    
    // Wait a moment for processing
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return { success: true };
  } catch (error) {
    console.error('Error submitting to Google Sheets Web App:', error);
    return { success: false, error: error.message };
  }
};

// Alternative method using Google Sheets API directly
const submitViaAPI = async (data: FormSubmission): Promise<{ success: boolean; error?: string }> => {
  try {
    const { SPREADSHEET_ID, SHEET_NAME, API_KEY } = GOOGLE_SHEETS_CONFIG;
    
    if (!SPREADSHEET_ID || !API_KEY) {
      return { success: false, error: 'Google Sheets API credentials not configured' };
    }

    const values = [[
      data.licensePlate,
      data.store,
      data.time,
      data.leadType,
      data.customerData?.firstName || '',
      data.customerData?.lastName || '',
      data.customerData?.email || '',
      data.customerData?.phoneNumber || '',
      data.customerData?.zipCode || '',
      data.image || '',
      data.notes || '',
      new Date().toISOString()
    ]];

    const url = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${SHEET_NAME}:append?valueInputOption=RAW&key=${API_KEY}`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values: values
      })
    });

    if (response.ok) {
      console.log('Successfully submitted via Google Sheets API');
      return { success: true };
    } else {
      const errorText = await response.text();
      console.error('Google Sheets API error:', errorText);
      return { success: false, error: `API Error: ${response.status} - ${errorText}` };
    }
  } catch (error) {
    console.error('Error submitting via API:', error);
    return { success: false, error: error.message };
  }
};

// Fallback: Store in localStorage for manual processing
const storeForManualProcessing = (data: FormSubmission): void => {
  const existingData = localStorage.getItem('failedSubmissions') || '[]';
  const failedSubmissions = JSON.parse(existingData);
  
  failedSubmissions.push({
    ...data,
    timestamp: new Date().toISOString(),
    status: 'pending_manual_processing'
  });
  
  localStorage.setItem('failedSubmissions', JSON.stringify(failedSubmissions));
  console.log('Stored submission for manual processing:', data);
};

export const submitToGoogleSheets = async (data: FormSubmission): Promise<boolean> => {
  try {
    console.log('=== GOOGLE SHEETS SUBMISSION ===');
    console.log('Input data:', JSON.stringify(data, null, 2));
    
    // Try Web App approach first
    const webAppResult = await submitViaWebApp(data);
    if (webAppResult.success) {
      console.log('Successfully submitted via Web App');
      return true;
    }
    
    console.warn('Web App submission failed:', webAppResult.error);
    
    // Try Google Sheets API as fallback
    const apiResult = await submitViaAPI(data);
    if (apiResult.success) {
      console.log('Successfully submitted via Google Sheets API');
      return true;
    }
    
    console.warn('API submission also failed:', apiResult.error);
    
    // If both methods fail, store for manual processing
    console.warn('All submission methods failed, storing for manual processing');
    storeForManualProcessing(data);
    
    // Return true since we've stored it for processing
    return true;
  } catch (error) {
    console.error('Error in submitToGoogleSheets:', error);
    storeForManualProcessing(data);
    return true; // Still return true since we stored it
  }
};

// Function to get failed submissions for admin review
export const getFailedSubmissions = (): any[] => {
  try {
    const stored = localStorage.getItem('failedSubmissions');
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading failed submissions:', error);
    return [];
  }
};

// Function to clear failed submissions
export const clearFailedSubmissions = (): void => {
  localStorage.removeItem('failedSubmissions');
};