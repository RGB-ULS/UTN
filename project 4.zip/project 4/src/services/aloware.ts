// Aloware SMS Service Integration
export interface AlowareSMSRequest {
  api_token: string;
  line_id?: number;
  from?: string;
  to: string;
  message: string;
  image_url?: string;
  force_random?: 0 | 1;
  custom_fields?: {
    custom_field_1?: string;
    custom_field_2?: string;
    custom_field_3?: string;
  };
  user_id?: number;
}

export interface AlowareSMSResponse {
  message: string;
}

export interface AlowareErrorResponse {
  message: string;
  errors?: {
    [key: string]: string[];
  };
}

// Aloware configuration
const ALOWARE_CONFIG = {
  API_URL: 'https://app.aloware.com/api/v1/webhook/sms-gateway/send',
  API_TOKEN: '95DCC169',
  LINE_ID: 8964,
  TEST_NUMBER: '+19407655834' // 940 765 5834 formatted for API
};

export const sendAlowareSMS = async (
  to: string,
  message: string,
  options?: {
    imageUrl?: string;
    customFields?: AlowareSMSRequest['custom_fields'];
    userId?: number;
  }
): Promise<{ success: boolean; message: string; error?: string }> => {
  try {
    console.log('🔔 Sending Aloware SMS...');
    console.log('To:', to);
    console.log('Message:', message);
    console.log('Options:', options);

    const payload: AlowareSMSRequest = {
      api_token: ALOWARE_CONFIG.API_TOKEN,
      line_id: ALOWARE_CONFIG.LINE_ID,
      to: to,
      message: message.substring(0, 160), // Limit to 160 characters
      ...(options?.imageUrl && { image_url: options.imageUrl }),
      ...(options?.customFields && { custom_fields: options.customFields }),
      ...(options?.userId !== undefined && { user_id: options.userId })
    };

    console.log('📤 Aloware API Payload:', JSON.stringify(payload, null, 2));

    const response = await fetch(ALOWARE_CONFIG.API_URL, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    console.log('📥 Aloware API Response Status:', response.status);

    if (response.status === 202) {
      const result: AlowareSMSResponse = await response.json();
      console.log('✅ SMS sent successfully:', result);
      return {
        success: true,
        message: result.message || 'SMS sent successfully'
      };
    } else {
      const errorResult: AlowareErrorResponse = await response.json();
      console.error('❌ SMS failed:', errorResult);
      
      let errorMessage = errorResult.message || 'Failed to send SMS';
      if (errorResult.errors) {
        const errorDetails = Object.values(errorResult.errors).flat().join(', ');
        errorMessage += `: ${errorDetails}`;
      }
      
      return {
        success: false,
        message: 'Failed to send SMS',
        error: errorMessage
      };
    }
  } catch (error) {
    console.error('🚨 Aloware SMS Error:', error);
    return {
      success: false,
      message: 'Network error while sending SMS',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
};

// Test SMS function with real lead data
export const sendTestSMS = async (leadData?: any): Promise<{ success: boolean; message: string; error?: string; leadData?: any }> => {
  let testLead;
  
  if (leadData) {
    // Use provided real lead data
    testLead = {
      id: leadData.id, // Use the REAL lead ID for the completion link
      licensePlate: leadData.data?.licensePlate || leadData.licensePlate || 'N/A',
      store: leadData.data?.store || leadData.store || 'Unknown Store',
      time: leadData.data?.time || leadData.time || leadData.createdAt,
      createdAt: leadData.createdAt
    };
  } else {
    // Fallback to sample data if no real lead provided
    testLead = {
      id: `test_lead_${Date.now()}`,
      licensePlate: 'TEST123',
      store: 'Downtown Branch',
      time: new Date().toLocaleString(),
      createdAt: new Date().toISOString()
    };
  }

  // Generate completion link using the REAL lead ID (not a new test ID)
  const completionLink = `${window.location.origin}/complete-lead/${testLead.id}`;

  // Create SMS message with proper time formatting
  const timeFormatted = testLead.time ? new Date(testLead.time).toLocaleString() : 'Unknown';
  const message = `🚗 New lead at ${testLead.store} - License: ${testLead.licensePlate} - Time: ${timeFormatted}. Complete: ${completionLink}`;

  console.log('🧪 Sending test SMS with REAL lead data and completion link:', testLead);
  console.log('🔗 Completion link will be:', completionLink);

  const result = await sendAlowareSMS(
    ALOWARE_CONFIG.TEST_NUMBER,
    message,
    {
      customFields: {
        custom_field_1: `License: ${testLead.licensePlate}`,
        custom_field_2: `Store: ${testLead.store}`,
        custom_field_3: `Lead ID: ${testLead.id}`
      },
      userId: -1 // Send as company
    }
  );

  return {
    ...result,
    leadData: testLead
  };
};

// Function to send SMS for actual leads
export const sendLeadNotificationSMS = async (
  phoneNumber: string,
  leadData: {
    id: string;
    licensePlate: string;
    store: string;
    time: string;
  }
): Promise<{ success: boolean; message: string; error?: string }> => {
  const completionLink = `${window.location.origin}/complete-lead/${leadData.id}`;
  
  const message = `🚗 New lead at ${leadData.store} - License: ${leadData.licensePlate} - Time: ${new Date(leadData.time).toLocaleString()}. Complete: ${completionLink}`;

  return await sendAlowareSMS(
    phoneNumber,
    message,
    {
      customFields: {
        custom_field_1: `License: ${leadData.licensePlate}`,
        custom_field_2: `Store: ${leadData.store}`,
        custom_field_3: `Lead ID: ${leadData.id}`
      },
      userId: -1 // Send as company
    }
  );
};