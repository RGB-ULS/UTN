export interface LeadData {
  image?: string;
  licensePlate: string;
  store: string;
  time: string;
  leadType: 'Customer' | 'Vendor / Other' | 'Employee' | '';
}

export interface CustomerData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  zipCode: string;
  notes?: string;
  notes?: string;
}

export interface FormSubmission extends LeadData {
  customerData?: CustomerData;
  repEmail?: string;
  notes?: string;
  notes?: string;
}

export interface StoredLead {
  id: string;
  data: LeadData;
  customerData?: CustomerData;
  createdAt: string;
  completed: boolean;
  completedAt?: string;
}

export interface WebhookLog {
  id: string;
  timestamp: string;
  payload: any;
  status: 'success' | 'error';
  error?: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  active: boolean;
  created_at: string;
  password?: string;
  needs_password?: boolean;
  phone_number?: string;
  assigned_stores?: string[];
}

export interface NotificationRule {
  id: string;
  name: string;
  enabled: boolean;
  layers: NotificationLayer[];
  createdAt: string;
  updatedAt: string;
}

export interface NotificationLayer {
  id: string;
  delayMinutes: number;
  recipients: NotificationRecipient[];
  message: string;
  conditions?: NotificationConditions;
}

export interface NotificationRecipient {
  type: 'phone' | 'email' | 'webhook';
  value: string;
  name?: string;
}

export interface NotificationConditions {
  stores?: string[];
  leadTypes?: string[];
  markets?: string[];
}

export interface NotificationLog {
  id: string;
  ruleId: string;
  layerId: string;
  leadId: string;
  recipient: NotificationRecipient;
  status: 'sent' | 'failed' | 'pending';
  sentAt: string;
  error?: string;
}